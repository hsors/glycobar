export interface BadgeProps {
  children?: React.ReactNode;
  /** a / b / plasma / universal are the domain tones used in blood-group figures. */
  tone?: "brand" | "neutral" | "a" | "b" | "plasma" | "universal";
  style?: React.CSSProperties;
}
export declare function Badge(props: BadgeProps): JSX.Element;
