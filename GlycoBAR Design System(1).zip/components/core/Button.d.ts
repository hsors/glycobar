/**
 * GlycoBAR primary action. Uppercase, letterspaced, 6px radius.
 * @startingPoint section="Core" subtitle="Buttons, icon buttons, badges and tags" viewport="700x300"
 */
export interface ButtonProps {
  children?: React.ReactNode;
  /** primary = bronze fill; secondary = outlined; ghost = text only; inverse = white on photo/dark. */
  variant?: "primary" | "secondary" | "ghost" | "inverse";
  size?: "sm" | "md" | "lg";
  /** Lucide icon name rendered before the label. */
  iconLeft?: string;
  /** Lucide icon name rendered after the label. */
  iconRight?: string;
  fullWidth?: boolean;
  disabled?: boolean;
  /** Renders an <a> instead of a <button>. */
  href?: string;
  onClick?: (e: React.MouseEvent) => void;
  type?: "button" | "submit" | "reset";
  style?: React.CSSProperties;
}
export declare function Button(props: ButtonProps): JSX.Element;
