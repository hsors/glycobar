import React from "react";
import { Icon } from "./Icon.jsx";

export function Tag({ children, onRemove, selected = false, onClick, style, ...rest }) {
  return (
    <span {...rest} onClick={onClick} style={{
      display: "inline-flex", alignItems: "center", gap: "var(--space-3)",
      padding: "5px var(--space-5)", borderRadius: "var(--radius-control)",
      font: "var(--type-small)",
      background: selected ? "var(--clay-600)" : "var(--stone-0)",
      color: selected ? "var(--text-onbrand)" : "var(--stone-700)",
      border: "1px solid " + (selected ? "var(--clay-600)" : "var(--border-hairline)"),
      cursor: onClick ? "pointer" : "default", transition: "var(--transition-control)", ...style,
    }}>
      {children}
      {onRemove ? (
        <button onClick={(e) => { e.stopPropagation(); onRemove(); }} aria-label="Remove"
          style={{ display: "inline-flex", border: 0, background: "transparent", padding: 0, cursor: "pointer", color: "inherit" }}>
          <Icon name="x" size={13} />
        </button>
      ) : null}
    </span>
  );
}
