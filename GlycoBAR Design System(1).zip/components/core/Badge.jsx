import React from "react";

const TONES = {
  brand: { background: "var(--clay-100)", color: "var(--clay-800)" },
  neutral: { background: "var(--stone-100)", color: "var(--stone-700)" },
  a: { background: "var(--antigen-a-soft)", color: "var(--antigen-a)" },
  b: { background: "var(--antigen-b-soft)", color: "var(--antigen-b)" },
  plasma: { background: "var(--plasma-soft)", color: "#8A6910" },
  universal: { background: "var(--universal-soft)", color: "var(--universal)" },
};

export function Badge({ children, tone = "brand", style, ...rest }) {
  return (
    <span {...rest} style={{
      display: "inline-flex", alignItems: "center", gap: "var(--space-2)",
      padding: "3px var(--space-4)", borderRadius: "var(--radius-pill)",
      font: "var(--weight-semibold) var(--text-2xs)/1.4 var(--font-body)",
      letterSpacing: "var(--tracking-wide)", textTransform: "uppercase",
      ...TONES[tone], ...style,
    }}>{children}</span>
  );
}
