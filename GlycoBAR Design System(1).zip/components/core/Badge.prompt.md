Tiny uppercase status pill. Domain tones map to the blood-group figures: a (red), b (blue), plasma (straw), universal (green).

\`\`\`jsx
<Badge tone="a">Antigen A</Badge>
<Badge tone="universal">Universal</Badge>
\`\`\`
