export interface CalloutProps {
  title?: string;
  children?: React.ReactNode;
  tone?: "info" | "note" | "warning" | "danger";
  style?: React.CSSProperties;
}
export declare function Callout(props: CalloutProps): JSX.Element;
