Colorable Lucide glyph — the only icon primitive in the system; never inline hand-drawn SVG.

\`\`\`jsx
<Icon name="flask-conical" size={20} color="var(--brand)" />
\`\`\`

Uses CSS masking so \`color\` works like text color. Names are Lucide kebab-case. Lucide is a flagged substitution for the site's Font Awesome set.
