export interface CardProps {
  children?: React.ReactNode;
  /** plain = white; tint = clay-50; inverse = cacao. */
  tone?: "plain" | "tint" | "inverse";
  /** Adds hover lift + deeper shadow. */
  interactive?: boolean;
  /** Any CSS length; defaults to var(--card-pad). */
  padding?: string;
  style?: React.CSSProperties;
}
export declare function Card(props: CardProps): JSX.Element;
