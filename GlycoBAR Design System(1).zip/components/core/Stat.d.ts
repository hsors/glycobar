export interface StatProps {
  /** Big number or short string. */
  value: React.ReactNode;
  label: string;
  /** Small suffix rendered at heading size (e.g. "%", "kg"). */
  unit?: string;
  tone?: "brand" | "inverse";
  align?: "left" | "center";
  style?: React.CSSProperties;
}
export declare function Stat(props: StatProps): JSX.Element;
