Boxed scientific aside. Accent is a 3px rule on the TOP edge — this is the one place an accent rule is allowed.

\`\`\`jsx
<Callout tone="warning" title="Hemolysis risk">
  Plasma antibodies meeting matching antigens can destroy red blood cells.
</Callout>
\`\`\`
