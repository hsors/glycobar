import React from "react";

export function Card({ children, tone = "plain", interactive = false, padding = "var(--card-pad)", style, ...rest }) {
  const [hover, setHover] = React.useState(false);
  const tones = {
    plain: { background: "var(--surface-card)", border: "1px solid var(--border-hairline)" },
    tint: { background: "var(--surface-alt)", border: "1px solid var(--clay-200)" },
    inverse: { background: "var(--surface-inverse)", border: "1px solid var(--clay-800)", color: "var(--clay-100)" },
  };
  return (
    <div
      {...rest}
      onMouseEnter={() => setHover(true)} onMouseLeave={() => setHover(false)}
      style={{
        borderRadius: "var(--radius-card)", padding,
        boxShadow: interactive && hover ? "var(--shadow-lg)" : "var(--shadow-sm)",
        transform: interactive && hover ? "var(--lift-hover)" : "none",
        transition: "var(--transition-lift)",
        cursor: interactive ? "pointer" : undefined,
        ...tones[tone], ...style,
      }}
    >
      {children}
    </div>
  );
}
