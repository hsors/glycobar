export interface TagProps {
  children?: React.ReactNode;
  /** Shows a trailing remove affordance. */
  onRemove?: () => void;
  selected?: boolean;
  onClick?: () => void;
  style?: React.CSSProperties;
}
export declare function Tag(props: TagProps): JSX.Element;
