import React from "react";
import { Icon } from "./Icon.jsx";

const SIZES = {
  sm: { padding: "0 var(--space-5)", height: 34, font: "var(--type-small)", icon: 15 },
  md: { padding: "0 var(--space-7)", height: 44, font: "var(--type-label)", icon: 17 },
  lg: { padding: "0 var(--space-9)", height: 54, font: "var(--weight-medium) var(--text-md)/1.2 var(--font-body)", icon: 19 },
};

const VARIANTS = {
  primary: { background: "var(--surface-brand)", color: "var(--text-onbrand)", border: "1px solid var(--clay-600)", boxShadow: "var(--shadow-brand)" },
  secondary: { background: "var(--stone-0)", color: "var(--clay-700)", border: "1px solid var(--border-brand)", boxShadow: "var(--shadow-xs)" },
  ghost: { background: "transparent", color: "var(--clay-700)", border: "1px solid transparent", boxShadow: "none" },
  inverse: { background: "var(--stone-0)", color: "var(--clay-800)", border: "1px solid transparent", boxShadow: "var(--shadow-md)" },
};

const HOVER = {
  primary: { background: "var(--clay-700)" },
  secondary: { background: "var(--clay-50)", borderColor: "var(--clay-400)" },
  ghost: { background: "var(--clay-100)" },
  inverse: { background: "var(--clay-50)" },
};

export function Button({
  children, variant = "primary", size = "md", iconLeft, iconRight,
  fullWidth = false, disabled = false, href, onClick, type = "button", style, ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const [press, setPress] = React.useState(false);
  const s = SIZES[size] || SIZES.md;
  const v = VARIANTS[variant] || VARIANTS.primary;
  const Tag = href ? "a" : "button";
  const css = {
    display: "inline-flex", alignItems: "center", justifyContent: "center",
    gap: "var(--space-4)", height: s.height, padding: s.padding, font: s.font,
    letterSpacing: "var(--tracking-wide)", textTransform: "uppercase",
    borderRadius: "var(--radius-control)", cursor: disabled ? "not-allowed" : "pointer",
    width: fullWidth ? "100%" : undefined, textDecoration: "none",
    transition: "var(--transition-control), transform var(--dur-fast) var(--ease-out)",
    opacity: disabled ? 0.45 : 1,
    transform: press && !disabled ? "scale(var(--press-scale))" : "none",
    ...v,
    ...(hover && !disabled ? HOVER[variant] : null),
    ...style,
  };
  return (
    <Tag
      {...rest} type={href ? undefined : type} href={href} onClick={disabled ? undefined : onClick}
      disabled={href ? undefined : disabled} style={css}
      onMouseEnter={() => setHover(true)} onMouseLeave={() => { setHover(false); setPress(false); }}
      onMouseDown={() => setPress(true)} onMouseUp={() => setPress(false)}
    >
      {iconLeft ? <Icon name={iconLeft} size={s.icon} /> : null}
      {children}
      {iconRight ? <Icon name={iconRight} size={s.icon} /> : null}
    </Tag>
  );
}
