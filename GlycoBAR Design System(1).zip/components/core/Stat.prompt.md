Large light-weight display number over an uppercase label, for market and capacity figures.

\`\`\`jsx
<Stat value="4" label="Blood groups covered" />
<Stat value="1/10" unit="th" label="Of competitor price" tone="inverse" />
\`\`\`
