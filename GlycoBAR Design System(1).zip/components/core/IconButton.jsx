import React from "react";
import { Icon } from "./Icon.jsx";

const SIZES = { sm: 32, md: 40, lg: 48 };

export function IconButton({ icon, label, variant = "secondary", size = "md", disabled = false, onClick, href, style, ...rest }) {
  const [hover, setHover] = React.useState(false);
  const d = SIZES[size] || SIZES.md;
  const solid = variant === "primary";
  const Tag = href ? "a" : "button";
  return (
    <Tag
      {...rest} href={href} aria-label={label} title={label} disabled={href ? undefined : disabled}
      onClick={disabled ? undefined : onClick}
      onMouseEnter={() => setHover(true)} onMouseLeave={() => setHover(false)}
      style={{
        display: "inline-flex", alignItems: "center", justifyContent: "center",
        width: d, height: d, borderRadius: "var(--radius-control)", cursor: disabled ? "not-allowed" : "pointer",
        border: solid ? "1px solid var(--clay-600)" : "1px solid " + (variant === "ghost" ? "transparent" : "var(--border-brand)"),
        background: solid ? (hover ? "var(--clay-700)" : "var(--surface-brand)") : hover ? "var(--clay-100)" : variant === "ghost" ? "transparent" : "var(--stone-0)",
        color: solid ? "var(--text-onbrand)" : "var(--clay-700)",
        opacity: disabled ? 0.45 : 1, transition: "var(--transition-control)", ...style,
      }}
    >
      <Icon name={icon} size={Math.round(d * 0.45)} />
    </Tag>
  );
}
