The container for every panel, process step and product tile: 12px radius, hairline border, warm shadow.

\`\`\`jsx
<Card tone="tint" interactive>
  <h3>Universal plasma</h3>
  <p>Low-cost antigen ligands make it economically viable.</p>
</Card>
\`\`\`

Set \`interactive\` only when the whole card is a link. Never stack a border-left accent on a card — use Callout for that.
