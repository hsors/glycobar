Square icon-only control for toolbars, close buttons and social links. \`label\` is required.

\`\`\`jsx
<IconButton icon="search" label="Search" variant="ghost" />
\`\`\`
