import React from "react";
import { Icon } from "./Icon.jsx";

const TONES = {
  info: { accent: "var(--info)", background: "var(--antigen-b-soft)", icon: "info" },
  note: { accent: "var(--clay-600)", background: "var(--clay-50)", icon: "flask-conical" },
  warning: { accent: "var(--warning)", background: "var(--plasma-soft)", icon: "triangle-alert" },
  danger: { accent: "var(--danger)", background: "var(--antigen-a-soft)", icon: "octagon-alert" },
};

export function Callout({ title, children, tone = "note", style, ...rest }) {
  const t = TONES[tone] || TONES.note;
  return (
    <div {...rest} style={{
      display: "flex", gap: "var(--space-5)", padding: "var(--space-6) var(--space-7)",
      background: t.background, borderRadius: "var(--radius-card)",
      borderTop: "var(--rule-accent) solid " + t.accent, ...style,
    }}>
      <Icon name={t.icon} size={20} color={t.accent} style={{ marginTop: 2 }} />
      <div>
        {title ? <div style={{ font: "var(--weight-semibold) var(--text-sm)/1.4 var(--font-body)", color: "var(--text-heading)", marginBottom: "var(--space-2)" }}>{title}</div> : null}
        <div style={{ font: "var(--type-small)", color: "var(--text-body)" }}>{children}</div>
      </div>
    </div>
  );
}
