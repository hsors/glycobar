export interface IconProps {
  /** Lucide icon name, kebab-case (e.g. "flask-conical", "arrow-right"). */
  name: string;
  /** Pixel box. Default 20. */
  size?: number;
  /** Any CSS color; defaults to currentColor. */
  color?: string;
  style?: React.CSSProperties;
}
export declare function Icon(props: IconProps): JSX.Element;
