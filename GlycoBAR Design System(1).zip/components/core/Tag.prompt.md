Selectable / removable filter chip, used on Products and R&D listings.

\`\`\`jsx
<Tag selected onClick={pick}>Tetraose</Tag>
<Tag onRemove={clear}>Amine termination</Tag>
\`\`\`
