import React from "react";

export function Stat({ value, label, unit, tone = "brand", align = "left", style, ...rest }) {
  const color = tone === "inverse" ? "var(--clay-200)" : "var(--brand)";
  return (
    <div {...rest} style={{ textAlign: align, ...style }}>
      <div style={{ font: "var(--weight-light) var(--text-5xl)/1 var(--font-display)", color, letterSpacing: "var(--tracking-tight)" }}>
        {value}
        {unit ? <span style={{ fontSize: "var(--text-2xl)", marginLeft: 2 }}>{unit}</span> : null}
      </div>
      <div style={{ marginTop: "var(--space-4)", font: "var(--type-eyebrow)", letterSpacing: "var(--tracking-label)", textTransform: "uppercase", color: tone === "inverse" ? "var(--clay-300)" : "var(--text-muted)" }}>{label}</div>
    </div>
  );
}
