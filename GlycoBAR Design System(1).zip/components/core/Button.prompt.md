The action primitive: uppercase label, 0.04em tracking, 6px radius, warm shadow on the primary fill.

\`\`\`jsx
<Button variant="primary" size="lg" iconRight="arrow-right">Discover more</Button>
<Button variant="secondary">Request a quote</Button>
<Button variant="inverse" href="/contact">Contact us</Button>
\`\`\`

Variants: primary (bronze), secondary (outlined on white), ghost (in toolbars), inverse (over photography). Sizes sm/md/lg = 34/44/54px. Hover darkens one clay step; press scales to 0.985.
