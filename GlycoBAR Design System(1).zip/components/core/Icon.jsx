import React from "react";

const CDN = "https://unpkg.com/lucide-static@0.462.0/icons/";

/* Lucide is a documented substitution: GlycoBAR's site ships Elementor's
   inline Font Awesome SVGs, which are not redistributable here. Lucide's
   1.5px-stroke outline set is the closest free match. */
export function Icon({ name, size = 20, color = "currentColor", strokeAlign, style, ...rest }) {
  const url = "url(" + CDN + name + ".svg)";
  return (
    <span
      aria-hidden="true"
      {...rest}
      style={{
        display: "inline-block",
        width: size,
        height: size,
        flex: "0 0 auto",
        backgroundColor: color,
        WebkitMaskImage: url,
        maskImage: url,
        WebkitMaskRepeat: "no-repeat",
        maskRepeat: "no-repeat",
        WebkitMaskSize: "contain",
        maskSize: "contain",
        WebkitMaskPosition: "center",
        maskPosition: "center",
        ...style,
      }}
    />
  );
}
