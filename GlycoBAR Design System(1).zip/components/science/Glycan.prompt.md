Draws a glycan structure in SNFG — the notation any glycoscientist reads instantly. Use it wherever a structure is stated in prose, and never redraw structures by hand.

\`\`\`jsx
<Glycan residues={GLYCOBAR_A} reducingEnd="NH₂ linker arm" />
<Glycan residues={GLYCOBAR_B} tone="outline" showLinks={false} size={16} />
\`\`\`

\`GLYCOBAR_A\` and \`GLYCOBAR_B\` are the two core products. \`tone="outline"\` gives the motif form for decorative use; keep \`tone="colour"\` any time the drawing makes a scientific claim.
