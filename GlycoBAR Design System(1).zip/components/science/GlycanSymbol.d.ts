export interface GlycanSymbolProps {
  /** SNFG residue name: Glc, Gal, Man, GlcNAc, GalNAc, Fuc, Neu5Ac, GlcA, Xyl. */
  residue?: "Glc" | "Gal" | "Man" | "GlcNAc" | "GalNAc" | "Fuc" | "Neu5Ac" | "GlcA" | "Xyl";
  size?: number;
  /** "colour" = true SNFG fill; "outline" = cacao line only (brand motif use). */
  tone?: "colour" | "outline";
  x?: number;
  y?: number;
  title?: string;
}
/** Must be rendered inside an <svg>. */
export declare function GlycanSymbol(props: GlycanSymbolProps): JSX.Element;
export declare const SNFG: Record<string, { shape: string; fill: string }>;
