export interface GlycanTrailProps {
  /** Geometry only — circle | square | triangle | diamond. */
  shapes?: Array<"circle" | "square" | "triangle" | "diamond">;
  size?: number;
  gap?: number;
  /** Index of the current step; earlier steps stay solid, later ones fade. -1 = decorative. */
  active?: number;
  /** Optional uppercase captions under each node. */
  labels?: string[];
  vertical?: boolean;
  style?: React.CSSProperties;
}
export declare function GlycanTrail(props: GlycanTrailProps): JSX.Element;
