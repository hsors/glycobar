A single SNFG residue. Renders an SVG \`<g>\`, so it must sit inside an \`<svg>\` — for standalone structures use \`Glycan\`.

\`\`\`jsx
<svg viewBox="0 0 40 40"><GlycanSymbol residue="Fuc" x={20} y={20} /></svg>
\`\`\`

Shapes and fills follow the published SNFG table exactly; only the outline colour is brand-adjusted (cacao, not black).
