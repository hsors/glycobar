import React from "react";
import { GlycanSymbol } from "./GlycanSymbol.jsx";

/**
 * The motif form of SNFG: an outlined residue trail used as a rule, a section
 * divider or a milestone track. Carries no scientific claim — geometry only,
 * which is why it is always tone="outline" and never coloured.
 */
export function GlycanTrail({
  shapes = ["circle", "square", "circle", "diamond"],
  size = 14, gap = 28, active = -1, labels, vertical = false, style, ...rest
}) {
  const RES = { circle: "Glc", square: "GlcNAc", triangle: "Fuc", diamond: "Neu5Ac" };
  const n = shapes.length;
  const len = gap * (n - 1) + size + 4;
  const w = vertical ? size + 4 : len;
  const h = vertical ? len : size + (labels ? 24 : 4);
  return (
    <svg {...rest} viewBox={"0 0 " + w + " " + h} width={vertical ? size + 4 : "100%"} height={h}
      style={{ display: "block", overflow: "visible", ...style }} aria-hidden="true">
      {shapes.map((s, i) => {
        const c = size / 2 + 2 + i * gap;
        const x = vertical ? size / 2 + 2 : c;
        const y = vertical ? c : size / 2 + 2;
        const nx = vertical ? x : size / 2 + 2 + (i + 1) * gap;
        const ny = vertical ? size / 2 + 2 + (i + 1) * gap : y;
        return (
          <g key={i}>
            {i < n - 1 ? (
              <line x1={vertical ? x : x + size / 2} y1={vertical ? y + size / 2 : y}
                x2={vertical ? nx : nx - size / 2} y2={vertical ? ny - size / 2 : ny}
                stroke="var(--snfg-connector)" strokeWidth="1.25" opacity={i < active ? 1 : 0.4} />
            ) : null}
            <g opacity={active < 0 || i <= active ? 1 : 0.4}>
              <GlycanSymbol residue={RES[s] || "Glc"} size={size} tone={i === active ? "colour" : "outline"} x={x} y={y} />
            </g>
            {labels && labels[i] ? (
              <text x={x} y={size + 18} textAnchor="middle"
                style={{ font: "var(--weight-medium) 9px/1 var(--font-body)", letterSpacing: ".1em", textTransform: "uppercase", fill: i <= active ? "var(--brand)" : "var(--text-faint)" }}>{labels[i]}</text>
            ) : null}
          </g>
        );
      })}
    </svg>
  );
}
