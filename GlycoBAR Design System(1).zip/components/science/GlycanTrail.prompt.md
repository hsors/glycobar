The motif, not the science: an outlined residue trail for section dividers, process steps and milestone tracks. Always outline — colouring it would imply a real structure.

\`\`\`jsx
<GlycanTrail shapes={["square","circle","circle","diamond"]} active={1}
  labels={["Strain","Ferment","Purify","Ship"]} />
<GlycanTrail vertical size={10} gap={22} />
\`\`\`
