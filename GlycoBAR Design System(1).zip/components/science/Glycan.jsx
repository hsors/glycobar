import React from "react";
import { GlycanSymbol } from "./GlycanSymbol.jsx";

/**
 * SNFG glycan structure. Residues read left to right; the reducing end is the
 * last item, matching how the field draws sequences. A residue may carry a
 * `branch` (an array drawn above it, connected by a vertical link).
 * tone="outline" strips the colours and gives the brand's motif form.
 */
export function Glycan({
  residues = [], size = 22, gap = 34, tone = "colour",
  showLinks = true, reducingEnd, style, ...rest
}) {
  const rowH = size + 26;
  const hasBranch = residues.some((r) => r.branch && r.branch.length);
  const width = gap * Math.max(residues.length - 1, 0) + size + (reducingEnd ? 64 : 24) + 20;
  const height = hasBranch ? rowH * 2 + 12 : rowH + 8;
  const baseY = hasBranch ? rowH + 12 : rowH / 2 + 4;
  const x0 = size / 2 + 10;

  return (
    <svg {...rest} viewBox={"0 0 " + width + " " + height} width="100%" height={height}
      style={{ display: "block", overflow: "visible", ...style }} role="img">
      {residues.map((r, i) => {
        const x = x0 + i * gap;
        const nextX = x0 + (i + 1) * gap;
        return (
          <g key={i}>
            {i < residues.length - 1 ? (
              <line x1={x + size / 2} y1={baseY} x2={nextX - size / 2} y2={baseY}
                stroke="var(--snfg-connector)" strokeWidth="1.25" />
            ) : null}
            {showLinks && r.link && i < residues.length - 1 ? (
              <text x={(x + nextX) / 2} y={baseY - 8} textAnchor="middle"
                style={{ font: "var(--weight-regular) 9px/1 var(--font-mono)", fill: "var(--snfg-label)" }}>{r.link}</text>
            ) : null}
            {r.branch && r.branch.length ? (
              <g>
                <line x1={x} y1={baseY - size / 2} x2={x} y2={baseY - rowH + size / 2}
                  stroke="var(--snfg-connector)" strokeWidth="1.25" />
                {r.branchLink ? (
                  <text x={x + 7} y={baseY - rowH / 2 - 2}
                    style={{ font: "var(--weight-regular) 9px/1 var(--font-mono)", fill: "var(--snfg-label)" }}>{r.branchLink}</text>
                ) : null}
                {r.branch.map((b, j) => (
                  <GlycanSymbol key={j} residue={b.residue} size={size} tone={tone}
                    x={x - j * gap} y={baseY - rowH} title={b.residue} />
                ))}
              </g>
            ) : null}
            <GlycanSymbol residue={r.residue} size={size} tone={tone} x={x} y={baseY} title={r.residue} />
          </g>
        );
      })}
      {reducingEnd ? (
        <g>
          <line x1={x0 + (residues.length - 1) * gap + size / 2} y1={baseY}
            x2={x0 + (residues.length - 1) * gap + size / 2 + 18} y2={baseY}
            stroke="var(--snfg-connector)" strokeWidth="1.25" strokeDasharray="3 3" />
          <text x={x0 + (residues.length - 1) * gap + size / 2 + 24} y={baseY + 4}
            style={{ font: "var(--weight-regular) 11px/1 var(--font-mono)", fill: "var(--text-muted)" }}>{reducingEnd}</text>
        </g>
      ) : null}
    </svg>
  );
}

/** The two GlycoBAR core products, as SNFG. */
export const GLYCOBAR_A = [
  { residue: "GalNAc", link: "α1-3", branch: [{ residue: "Fuc" }], branchLink: "α1-2" },
  { residue: "Gal", link: "β1-4" },
  { residue: "GlcNAc" },
];
export const GLYCOBAR_B = [
  { residue: "Gal", link: "α1-3", branch: [{ residue: "Fuc" }], branchLink: "α1-2" },
  { residue: "Gal", link: "β1-4" },
  { residue: "GlcNAc" },
];
