export interface GlycanResidue {
  residue: "Glc" | "Gal" | "Man" | "GlcNAc" | "GalNAc" | "Fuc" | "Neu5Ac" | "GlcA" | "Xyl";
  /** Linkage label drawn on the connector to the next residue, e.g. "β1-4". */
  link?: string;
  /** Residues drawn on a branch above this one. */
  branch?: Array<{ residue: GlycanResidue["residue"] }>;
  /** Linkage label for the branch connector. */
  branchLink?: string;
}
export interface GlycanProps {
  residues?: GlycanResidue[];
  size?: number;
  gap?: number;
  tone?: "colour" | "outline";
  showLinks?: boolean;
  /** Trailing annotation after a dashed link, e.g. "NH₂ linker arm". */
  reducingEnd?: string;
  style?: React.CSSProperties;
}
export declare function Glycan(props: GlycanProps): JSX.Element;
/** GlycoBAR's blood group A tetraose, ready to pass as `residues`. */
export declare const GLYCOBAR_A: GlycanResidue[];
/** GlycoBAR's blood group B tetraose. */
export declare const GLYCOBAR_B: GlycanResidue[];
