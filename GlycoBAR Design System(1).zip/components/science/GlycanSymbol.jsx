import React from "react";

/** SNFG residue table: shape + fill. Outlines are cacao, never pure black. */
export const SNFG = {
  Glc:     { shape: "circle",   fill: "var(--snfg-glc)" },
  Gal:     { shape: "circle",   fill: "var(--snfg-gal)" },
  Man:     { shape: "circle",   fill: "var(--snfg-man)" },
  GlcNAc:  { shape: "square",   fill: "var(--snfg-glcnac)" },
  GalNAc:  { shape: "square",   fill: "var(--snfg-galnac)" },
  Fuc:     { shape: "triangle", fill: "var(--snfg-fuc)" },
  Neu5Ac:  { shape: "diamond",  fill: "var(--snfg-neu5ac)" },
  GlcA:    { shape: "diamond",  fill: "var(--snfg-glca)" },
  Xyl:     { shape: "star",     fill: "var(--snfg-xyl)" },
};

function shapePath(shape, s) {
  const h = s / 2;
  if (shape === "square") return { tag: "rect", props: { x: -h, y: -h, width: s, height: s } };
  if (shape === "triangle") return { tag: "polygon", props: { points: [0, -h, h, h, -h, h].join(" ") } };
  if (shape === "diamond") return { tag: "polygon", props: { points: [0, -h, h, 0, 0, h, -h, 0].join(" ") } };
  if (shape === "star") {
    const pts = [];
    for (let i = 0; i < 10; i++) {
      const r = i % 2 ? h * 0.45 : h;
      const a = (Math.PI / 5) * i - Math.PI / 2;
      pts.push((Math.cos(a) * r).toFixed(2), (Math.sin(a) * r).toFixed(2));
    }
    return { tag: "polygon", props: { points: pts.join(" ") } };
  }
  return { tag: "circle", props: { r: h } };
}

/** One residue, drawn at the SVG origin. Use inside <Glycan>, or standalone. */
export function GlycanSymbol({ residue = "Gal", size = 22, tone = "colour", x = 0, y = 0, title }) {
  const def = SNFG[residue] || SNFG.Gal;
  const { tag, props } = shapePath(def.shape, size);
  const El = tag;
  return (
    <g transform={"translate(" + x + "," + y + ")"}>
      {title ? <title>{title || residue}</title> : null}
      <El {...props}
        fill={tone === "outline" ? "none" : def.fill}
        stroke={tone === "outline" ? "var(--snfg-connector)" : "var(--snfg-stroke)"}
        strokeWidth={tone === "outline" ? 1.25 : 1.5}
        vectorEffect="non-scaling-stroke" />
    </g>
  );
}
