Hover label for abbreviations and molecular shorthand.

\`\`\`jsx
<Tooltip label="Tetrasaccharide with amine termination"><Badge tone="a">A4</Badge></Tooltip>
\`\`\`
