import React from "react";

export function Tooltip({ label, children, placement = "top", style, ...rest }) {
  const [open, setOpen] = React.useState(false);
  const pos = placement === "bottom"
    ? { top: "calc(100% + 8px)", left: "50%", transform: "translateX(-50%)" }
    : { bottom: "calc(100% + 8px)", left: "50%", transform: "translateX(-50%)" };
  return (
    <span {...rest} onMouseEnter={() => setOpen(true)} onMouseLeave={() => setOpen(false)}
      style={{ position: "relative", display: "inline-flex", ...style }}>
      {children}
      {open ? (
        <span role="tooltip" style={{
          position: "absolute", ...pos, whiteSpace: "nowrap", zIndex: 40,
          background: "var(--clay-900)", color: "var(--clay-100)",
          font: "var(--weight-regular) var(--text-xs)/1.3 var(--font-body)",
          padding: "6px var(--space-5)", borderRadius: "var(--radius-xs)", boxShadow: "var(--shadow-md)",
        }}>{label}</span>
      ) : null}
    </span>
  );
}
