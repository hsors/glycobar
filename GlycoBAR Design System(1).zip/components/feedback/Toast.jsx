import React from "react";
import { Icon } from "../core/Icon.jsx";

const TONES = {
  success: { icon: "check", color: "var(--success)" },
  error: { icon: "octagon-alert", color: "var(--danger)" },
  info: { icon: "info", color: "var(--info)" },
};

export function Toast({ message, tone = "success", onDismiss, style, ...rest }) {
  const t = TONES[tone] || TONES.info;
  return (
    <div {...rest} role="status" style={{
      display: "inline-flex", alignItems: "center", gap: "var(--space-5)",
      background: "var(--surface-inverse)", color: "var(--clay-100)",
      padding: "var(--space-5) var(--space-7)", borderRadius: "var(--radius-control)",
      boxShadow: "var(--shadow-lg)", font: "var(--type-small)", ...style,
    }}>
      <Icon name={t.icon} size={17} color={t.color} />
      <span>{message}</span>
      {onDismiss ? (
        <button onClick={onDismiss} aria-label="Dismiss" style={{ background: "transparent", border: 0, cursor: "pointer", color: "var(--clay-400)", display: "inline-flex", padding: 0, marginLeft: "var(--space-4)" }}>
          <Icon name="x" size={15} />
        </button>
      ) : null}
    </div>
  );
}
