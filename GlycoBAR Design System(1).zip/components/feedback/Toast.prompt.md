Dark confirmation strip, bottom-centered by the page, dismissible.

\`\`\`jsx
<Toast tone="success" message="Your request has been sent." onDismiss={hide} />
\`\`\`
