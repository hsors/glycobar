export interface ToastProps {
  message: string;
  tone?: "success" | "error" | "info";
  onDismiss?: () => void;
  style?: React.CSSProperties;
}
export declare function Toast(props: ToastProps): JSX.Element;
