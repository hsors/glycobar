export interface DialogProps {
  open?: boolean;
  title?: string;
  children?: React.ReactNode;
  /** Usually two Buttons. */
  footer?: React.ReactNode;
  onClose?: () => void;
  width?: number;
  style?: React.CSSProperties;
}
export declare function Dialog(props: DialogProps): JSX.Element;
