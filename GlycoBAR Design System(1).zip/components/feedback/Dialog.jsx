import React from "react";
import { IconButton } from "../core/IconButton.jsx";

export function Dialog({ open = false, title, children, footer, onClose, width = 520, style, ...rest }) {
  if (!open) return null;
  return (
    <div style={{ position: "fixed", inset: 0, zIndex: 60, display: "flex", alignItems: "center", justifyContent: "center", padding: "var(--space-9)" }}>
      <div onClick={onClose} style={{ position: "absolute", inset: 0, background: "var(--veil-dark)", backdropFilter: "var(--blur-veil)" }} />
      <div {...rest} role="dialog" aria-modal="true" style={{
        position: "relative", width: "100%", maxWidth: width, background: "var(--surface-card)",
        borderRadius: "var(--radius-card)", boxShadow: "var(--shadow-lg)", padding: "var(--card-pad-lg)",
        animation: "none", ...style,
      }}>
        <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", gap: "var(--space-6)" }}>
          <h3 style={{ font: "var(--type-h3)", color: "var(--text-heading)" }}>{title}</h3>
          <IconButton icon="x" label="Close" variant="ghost" size="sm" onClick={onClose} />
        </div>
        <div style={{ marginTop: "var(--space-6)", font: "var(--type-body)", color: "var(--text-body)" }}>{children}</div>
        {footer ? <div style={{ marginTop: "var(--space-9)", display: "flex", gap: "var(--space-5)", justifyContent: "flex-end" }}>{footer}</div> : null}
      </div>
    </div>
  );
}
