Centered modal over a cacao veil with blur. Used for quote requests and contact forms.

\`\`\`jsx
<Dialog open={open} title="Request a quote" onClose={close}
  footer={<><Button variant="ghost" onClick={close}>Cancel</Button><Button>Send</Button></>}>
  ...
</Dialog>
\`\`\`
