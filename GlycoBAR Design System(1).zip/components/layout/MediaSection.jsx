import React from "react";

export function MediaSection({ image, imageAlt = "", reverse = false, ratio = "1fr 1fr", tone = "page", children, style, ...rest }) {
  const bg = tone === "alt" ? "var(--surface-alt)" : tone === "inverse" ? "var(--surface-inverse)" : "var(--surface-page)";
  return (
    <section {...rest} style={{ background: bg, padding: "var(--section-y) 0", ...style }}>
      <div style={{ maxWidth: "var(--container-max)", margin: "0 auto", padding: "0 var(--gutter)", display: "grid", gridTemplateColumns: ratio, gap: "var(--space-12)", alignItems: "center" }}>
        <div style={{ order: reverse ? 2 : 1 }}>{children}</div>
        <div style={{ order: reverse ? 1 : 2 }}>
          <img src={image} alt={imageAlt} style={{ width: "100%", display: "block", borderRadius: "var(--radius-image)", boxShadow: "var(--shadow-md)", objectFit: "cover" }} />
        </div>
      </div>
    </section>
  );
}
