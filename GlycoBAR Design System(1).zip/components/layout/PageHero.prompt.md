Full-bleed photographic hero with the protection gradient and bottom-aligned display type.

\`\`\`jsx
<PageHero eyebrow="Innovative" title="Blood group antigens ligands for an ABO antibody-free World"
  image="assets/photography/plant-exterior.png">
  <Button variant="inverse" iconRight="arrow-right">Discover more</Button>
</PageHero>
\`\`\`
