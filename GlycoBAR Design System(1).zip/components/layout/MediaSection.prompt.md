Two-column text/photograph band. Alternate \`reverse\` down a page and vary \`tone\` between page and alt.

\`\`\`jsx
<MediaSection image="assets/photography/plant-exterior.png" tone="alt" reverse>
  <SectionHeader eyebrow="About GlycoBAR" title="An industrial demonstrator, today" />
</MediaSection>
\`\`\`
