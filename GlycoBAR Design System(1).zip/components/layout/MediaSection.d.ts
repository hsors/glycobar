export interface MediaSectionProps {
  image: string;
  imageAlt?: string;
  /** Puts the image on the left. */
  reverse?: boolean;
  /** CSS grid-template-columns, default "1fr 1fr". */
  ratio?: string;
  tone?: "page" | "alt" | "inverse";
  children?: React.ReactNode;
  style?: React.CSSProperties;
}
export declare function MediaSection(props: MediaSectionProps): JSX.Element;
