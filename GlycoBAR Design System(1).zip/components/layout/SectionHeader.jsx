import React from "react";

export function SectionHeader({ eyebrow, title, lead, align = "left", tone = "light", maxWidth = 640, children, style, ...rest }) {
  const inverse = tone === "inverse";
  return (
    <div {...rest} style={{ textAlign: align, maxWidth, marginLeft: align === "center" ? "auto" : 0, marginRight: align === "center" ? "auto" : 0, ...style }}>
      {eyebrow ? (
        <div style={{ font: "var(--type-eyebrow)", letterSpacing: "var(--tracking-label)", textTransform: "uppercase", color: inverse ? "var(--clay-400)" : "var(--brand)" }}>{eyebrow}</div>
      ) : null}
      {title ? (
        <h2 style={{ marginTop: "var(--space-5)", font: "var(--type-h2)", color: inverse ? "var(--stone-0)" : "var(--text-heading)" }}>{title}</h2>
      ) : null}
      {lead ? (
        <p style={{ marginTop: "var(--space-6)", font: "var(--type-lead)", color: inverse ? "var(--clay-200)" : "var(--text-body)" }}>{lead}</p>
      ) : null}
      {children ? <div style={{ marginTop: "var(--space-7)" }}>{children}</div> : null}
    </div>
  );
}
