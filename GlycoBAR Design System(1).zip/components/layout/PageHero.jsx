import React from "react";

export function PageHero({ eyebrow, title, lead, image, imageAlt = "", height = 420, children, style, ...rest }) {
  return (
    <section {...rest} style={{ position: "relative", minHeight: height, display: "flex", alignItems: "flex-end", background: "var(--clay-900)", overflow: "hidden", ...style }}>
      {image ? <img src={image} alt={imageAlt} style={{ position: "absolute", inset: 0, width: "100%", height: "100%", objectFit: "cover", filter: "saturate(.92)" }} /> : null}
      <div style={{ position: "absolute", inset: 0, background: "var(--grad-protect)" }} />
      <div style={{ position: "relative", maxWidth: "var(--container-max)", width: "100%", margin: "0 auto", padding: "var(--space-12) var(--gutter)" }}>
        {eyebrow ? <div style={{ font: "var(--type-eyebrow)", letterSpacing: "var(--tracking-label)", textTransform: "uppercase", color: "var(--clay-300)" }}>{eyebrow}</div> : null}
        <h1 style={{ marginTop: "var(--space-5)", font: "var(--weight-light) var(--text-6xl)/var(--leading-tight) var(--font-display)", color: "var(--stone-0)", letterSpacing: "var(--tracking-tight)", maxWidth: 900 }}>{title}</h1>
        {lead ? <p style={{ marginTop: "var(--space-6)", font: "var(--type-lead)", color: "var(--clay-100)", maxWidth: 620 }}>{lead}</p> : null}
        {children ? <div style={{ marginTop: "var(--space-8)", display: "flex", gap: "var(--space-5)" }}>{children}</div> : null}
      </div>
    </section>
  );
}
