export interface PageHeroProps {
  eyebrow?: string;
  title?: string;
  lead?: string;
  /** Full-bleed photograph; darkened by the protection gradient. */
  image?: string;
  imageAlt?: string;
  height?: number;
  children?: React.ReactNode;
  style?: React.CSSProperties;
}
export declare function PageHero(props: PageHeroProps): JSX.Element;
