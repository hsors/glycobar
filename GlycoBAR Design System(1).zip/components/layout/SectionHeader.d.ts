/**
 * @startingPoint section="Layout" subtitle="Eyebrow / heading / lead section opener" viewport="700x260"
 */
export interface SectionHeaderProps {
  /** Small uppercase kicker, e.g. "Biofermentation process". */
  eyebrow?: string;
  title?: string;
  lead?: string;
  align?: "left" | "center";
  tone?: "light" | "inverse";
  maxWidth?: number;
  children?: React.ReactNode;
  style?: React.CSSProperties;
}
export declare function SectionHeader(props: SectionHeaderProps): JSX.Element;
