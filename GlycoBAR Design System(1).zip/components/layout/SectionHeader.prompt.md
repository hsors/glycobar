The site's section opener: bronze uppercase eyebrow, display heading, light lead paragraph. Every section on glycobar.com starts this way.

\`\`\`jsx
<SectionHeader eyebrow="Impacts" title="Leading innovation"
  lead="GlycoBAR contributes to the achievement of the United Nations Sustainable Development Goals." />
\`\`\`
