Cacao footer: about column, two link columns, newsletter. Address line sits in the bottom rule.

\`\`\`jsx
<Footer about="Glycosciences serving medical innovation."
  columns={[{title:"Company",links:["Home","About Us","Legals"]},{title:"Services",links:["Process","Products","R&D"]}]} />
\`\`\`
