import React from "react";

export function Tabs({ items = [], active, onChange, style, ...rest }) {
  return (
    <div {...rest} role="tablist" style={{ display: "flex", gap: "var(--space-8)", borderBottom: "1px solid var(--border-hairline)", ...style }}>
      {items.map((it) => {
        const on = it.id === active;
        return (
          <button key={it.id} role="tab" aria-selected={on} onClick={() => onChange && onChange(it.id)}
            style={{
              background: "transparent", border: 0, cursor: "pointer", padding: "0 0 var(--space-5)",
              font: "var(--weight-medium) var(--text-sm)/1 var(--font-body)",
              letterSpacing: "var(--tracking-wide)", textTransform: "uppercase",
              color: on ? "var(--clay-800)" : "var(--stone-500)",
              boxShadow: on ? "inset 0 -2px 0 var(--clay-600)" : "none",
              transition: "var(--transition-control)",
            }}>{it.label}</button>
        );
      })}
    </div>
  );
}
