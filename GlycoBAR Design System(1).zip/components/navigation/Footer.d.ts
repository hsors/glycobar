export interface FooterProps {
  columns?: Array<{ title: string; links: string[] }>;
  about?: string;
  logoSrc?: string;
  style?: React.CSSProperties;
}
export declare function Footer(props: FooterProps): JSX.Element;
