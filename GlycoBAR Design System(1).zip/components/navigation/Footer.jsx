import React from "react";
import { Icon } from "../core/Icon.jsx";
import { Input } from "../forms/Input.jsx";
import { Button } from "../core/Button.jsx";

export function Footer({ columns = [], about, logoSrc, style, ...rest }) {
  return (
    <footer {...rest} style={{ background: "var(--surface-inverse)", color: "var(--clay-200)", paddingTop: "var(--space-13)", ...style }}>
      <div style={{ maxWidth: "var(--container-max)", margin: "0 auto", padding: "0 var(--gutter)", display: "grid", gridTemplateColumns: "1.6fr repeat(2, .8fr) 1.2fr", gap: "var(--space-11)" }}>
        <div>
          {logoSrc
            ? <img src={logoSrc} alt="GlycoBAR" style={{ height: 54, width: "auto", filter: "brightness(1.6)" }} />
            : <div style={{ font: "var(--weight-medium) var(--text-xl)/1 var(--font-display)", color: "var(--clay-300)" }}>GlycoBAR</div>}
          <p style={{ marginTop: "var(--space-6)", font: "var(--type-small)", color: "var(--clay-300)", maxWidth: 300 }}>{about}</p>
          <div style={{ marginTop: "var(--space-6)", display: "flex", gap: "var(--space-5)" }}>
            <Icon name="linkedin" size={18} color="var(--clay-400)" />
            <Icon name="mail" size={18} color="var(--clay-400)" />
            <Icon name="phone" size={18} color="var(--clay-400)" />
          </div>
        </div>
        {columns.map((col) => (
          <div key={col.title}>
            <div style={{ font: "var(--type-eyebrow)", letterSpacing: "var(--tracking-label)", textTransform: "uppercase", color: "var(--clay-400)" }}>{col.title}</div>
            <ul style={{ listStyle: "none", margin: "var(--space-6) 0 0", padding: 0, display: "flex", flexDirection: "column", gap: "var(--space-4)" }}>
              {col.links.map((l) => (
                <li key={l}><a href="#" style={{ font: "var(--type-small)", color: "var(--clay-200)", borderBottom: 0 }}>{l}</a></li>
              ))}
            </ul>
          </div>
        ))}
        <div>
          <div style={{ font: "var(--type-eyebrow)", letterSpacing: "var(--tracking-label)", textTransform: "uppercase", color: "var(--clay-400)" }}>Newsletter</div>
          <div style={{ marginTop: "var(--space-6)", display: "flex", flexDirection: "column", gap: "var(--space-4)" }}>
            <Input placeholder="E-mail" style={{ background: "rgba(255,255,255,.06)", borderColor: "var(--clay-700)", color: "var(--clay-100)" }} />
            <Button size="sm" variant="secondary" iconRight="send">Envoyer</Button>
          </div>
        </div>
      </div>
      <div style={{ marginTop: "var(--space-12)", borderTop: "1px solid var(--clay-800)", padding: "var(--space-6) var(--gutter)" }}>
        <div style={{ maxWidth: "var(--container-max)", margin: "0 auto", display: "flex", justifyContent: "space-between", font: "var(--weight-regular) var(--text-xs)/1.4 var(--font-body)", color: "var(--clay-400)" }}>
          <span>19 Rue Casimir Julhiet, 38420 Domene, France</span>
          <span>&copy; GlycoBAR</span>
        </div>
      </div>
    </footer>
  );
}
