import React from "react";
import { Icon } from "../core/Icon.jsx";
import { Button } from "../core/Button.jsx";

/** Pass logoSrc (assets/glycobar-logo.png) from the consuming page; without it
 *  the wordmark is set in display type — never redraw the mark. */
export function NavBar({ items = [], active, onNavigate, logoSrc, welcome = "Welcome at GlycoBAR", cta = "Contact us", onCta, style, ...rest }) {
  return (
    <header {...rest} style={{ background: "var(--stone-0)", borderBottom: "1px solid var(--border-hairline)", ...style }}>
      <div style={{ background: "var(--clay-800)", color: "var(--clay-200)", font: "var(--weight-regular) var(--text-xs)/1 var(--font-body)", letterSpacing: "var(--tracking-wide)" }}>
        <div style={{ maxWidth: "var(--container-max)", margin: "0 auto", padding: "10px var(--gutter)", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <span style={{ display: "inline-flex", alignItems: "center", gap: "var(--space-4)" }}>
            <Icon name="dna" size={14} color="var(--clay-400)" />{welcome}
          </span>
          <span style={{ display: "inline-flex", alignItems: "center", gap: "var(--space-6)" }}>
            <a href="mailto:contact@glycobar.com" style={{ color: "var(--clay-200)", borderBottom: 0, display: "inline-flex", alignItems: "center", gap: 6 }}>
              <Icon name="mail" size={14} />contact@glycobar.com
            </a>
            <Icon name="linkedin" size={14} color="var(--clay-300)" />
          </span>
        </div>
      </div>
      <div style={{ maxWidth: "var(--container-max)", margin: "0 auto", padding: "var(--space-5) var(--gutter)", display: "flex", alignItems: "center", gap: "var(--space-9)" }}>
        <a href="#" onClick={(e) => { e.preventDefault(); onNavigate && onNavigate(items[0] && items[0].id); }}
           style={{ display: "inline-flex", alignItems: "center", gap: "var(--space-4)", borderBottom: 0 }}>
          {logoSrc
            ? <img src={logoSrc} alt="GlycoBAR" style={{ height: 46, width: "auto", display: "block" }} />
            : <span style={{ font: "var(--weight-medium) var(--text-xl)/1 var(--font-display)", color: "var(--clay-600)", letterSpacing: "0.01em" }}>GlycoBAR</span>}
        </a>
        <nav style={{ display: "flex", gap: "var(--space-7)", marginLeft: "auto" }}>
          {items.map((it) => {
            const on = it.id === active;
            return (
              <a key={it.id} href="#" onClick={(e) => { e.preventDefault(); onNavigate && onNavigate(it.id); }}
                style={{
                  font: "var(--weight-medium) var(--text-sm)/1 var(--font-body)",
                  letterSpacing: "var(--tracking-wide)", textTransform: "uppercase",
                  color: on ? "var(--clay-800)" : "var(--stone-600)",
                  borderBottom: "2px solid " + (on ? "var(--clay-600)" : "transparent"),
                  paddingBottom: 4, transition: "var(--transition-control)",
                }}>{it.label}</a>
            );
          })}
        </nav>
        <Button size="sm" variant="primary" onClick={onCta}>{cta}</Button>
      </div>
    </header>
  );
}
