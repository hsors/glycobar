export interface TabsProps {
  items?: Array<{ id: string; label: string }>;
  active?: string;
  onChange?: (id: string) => void;
  style?: React.CSSProperties;
}
export declare function Tabs(props: TabsProps): JSX.Element;
