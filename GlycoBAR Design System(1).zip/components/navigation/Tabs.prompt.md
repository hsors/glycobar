Underlined uppercase tab row for switching product families or market views.

\`\`\`jsx
<Tabs active={t} onChange={setT} items={[{id:"a",label:"Group A"},{id:"b",label:"Group B"}]} />
\`\`\`
