/**
 * @startingPoint section="Navigation" subtitle="Site header with contact bar, nav and CTA" viewport="1180x160"
 */
export interface NavBarProps {
  items?: Array<{ id: string; label: string }>;
  active?: string;
  onNavigate?: (id: string) => void;
  /** Path to assets/glycobar-logo.png. Omitted = wordmark set in Jost. */
  logoSrc?: string;
  /** Contact-bar greeting; site uses "Welcome at GlycoBAR". */
  welcome?: string;
  cta?: string;
  onCta?: () => void;
  style?: React.CSSProperties;
}
export declare function NavBar(props: NavBarProps): JSX.Element;
