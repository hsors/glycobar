Site header: cacao contact bar, then white bar with logo, uppercase nav and a primary CTA.

\`\`\`jsx
<NavBar logoSrc="assets/glycobar-logo.png" active="home" onNavigate={go}
  items={[{id:"home",label:"Home"},{id:"about",label:"About Us"},{id:"products",label:"Products"}]} />
\`\`\`
