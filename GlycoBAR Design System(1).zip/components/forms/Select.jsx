import React from "react";
import { Icon } from "../core/Icon.jsx";

export function Select({ value, onChange, options = [], placeholder, invalid = false, disabled = false, id, style, ...rest }) {
  const [focus, setFocus] = React.useState(false);
  const box = {
    width: "100%", font: "var(--type-body)", color: "var(--text-body)",
    background: "var(--stone-0)", borderRadius: "var(--radius-control)",
    border: "1px solid " + (invalid ? "var(--danger)" : focus ? "var(--clay-500)" : "var(--border-strong)"),
    boxShadow: focus ? "0 0 0 3px rgba(140,97,56,.14)" : "none",
    outline: "none", transition: "var(--transition-control)",
    opacity: disabled ? 0.55 : 1,
  };
  return (
    <div style={{ position: "relative", display: "flex", alignItems: "center" }}>
      <select
        {...rest} id={id} value={value} onChange={onChange} disabled={disabled}
        onFocus={() => setFocus(true)} onBlur={() => setFocus(false)}
        style={{ ...box, height: 44, padding: "0 38px 0 var(--space-5)", appearance: "none", cursor: disabled ? "not-allowed" : "pointer", ...style }}
      >
        {placeholder ? <option value="">{placeholder}</option> : null}
        {options.map((o) => {
          const val = typeof o === "string" ? o : o.value;
          const lab = typeof o === "string" ? o : o.label;
          return <option key={val} value={val}>{lab}</option>;
        })}
      </select>
      <Icon name="chevron-down" size={16} color="var(--clay-600)" style={{ position: "absolute", right: 12, pointerEvents: "none" }} />
    </div>
  );
}
