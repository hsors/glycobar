Immediate-effect toggle (42x24). Use for view options, not for form submission values.

\`\`\`jsx
<Switch checked={on} onChange={setOn} label="Show antibody layer" />
\`\`\`
