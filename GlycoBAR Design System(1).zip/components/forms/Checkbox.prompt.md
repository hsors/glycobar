Square 20px box, 3px radius, bronze when checked.

\`\`\`jsx
<Checkbox checked={ok} onChange={setOk} label="Subscribe to the newsletter" />
\`\`\`
