import React from "react";
import { Icon } from "../core/Icon.jsx";

export function Checkbox({ checked = false, onChange, label, disabled = false, style, ...rest }) {
  return (
    <label {...rest} style={{ display: "inline-flex", alignItems: "center", gap: "var(--space-4)", cursor: disabled ? "not-allowed" : "pointer", opacity: disabled ? 0.55 : 1, ...style }}>
      <span
        onClick={() => !disabled && onChange && onChange(!checked)}
        style={{
          width: 20, height: 20, display: "inline-flex", alignItems: "center", justifyContent: "center",
          borderRadius: "var(--radius-xs)", flex: "0 0 auto",
          background: checked ? "var(--clay-600)" : "var(--stone-0)",
          border: "1px solid " + (checked ? "var(--clay-600)" : "var(--border-strong)"),
          transition: "var(--transition-control)",
        }}
      >
        {checked ? <Icon name="check" size={14} color="#fff" /> : null}
      </span>
      {label ? <span style={{ font: "var(--type-small)", color: "var(--text-body)" }}>{label}</span> : null}
    </label>
  );
}
