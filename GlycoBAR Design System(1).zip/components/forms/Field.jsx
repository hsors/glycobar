import React from "react";

export function Field({ label, hint, error, required = false, htmlFor, children, style, ...rest }) {
  return (
    <div {...rest} style={{ display: "flex", flexDirection: "column", gap: "var(--space-3)", ...style }}>
      {label ? (
        <label htmlFor={htmlFor} style={{ font: "var(--type-label)", color: "var(--text-heading)" }}>
          {label}
          {required ? <span style={{ color: "var(--danger)", marginLeft: 3 }}>*</span> : null}
        </label>
      ) : null}
      {children}
      {error ? (
        <span style={{ font: "var(--weight-regular) var(--text-xs)/1.4 var(--font-body)", color: "var(--danger)" }}>{error}</span>
      ) : hint ? (
        <span style={{ font: "var(--weight-regular) var(--text-xs)/1.4 var(--font-body)", color: "var(--text-muted)" }}>{hint}</span>
      ) : null}
    </div>
  );
}
