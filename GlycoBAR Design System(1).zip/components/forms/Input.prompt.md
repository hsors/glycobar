44px text control, 6px radius, clay focus ring (3px, 14% bronze).

\`\`\`jsx
<Input icon="search" placeholder="Search antigens" />
<Input invalid value="abc" />
\`\`\`
