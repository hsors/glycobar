Single-choice dot. Pass the same \`name\` to a group and compare \`value\`.

\`\`\`jsx
<Radio name="grade" value="research" checked={g === "research"} onChange={setG} label="Research grade" />
\`\`\`
