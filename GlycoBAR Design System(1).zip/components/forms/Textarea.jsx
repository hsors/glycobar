import React from "react";

export function Textarea({ value, onChange, placeholder, rows = 4, invalid = false, disabled = false, id, style, ...rest }) {
  const [focus, setFocus] = React.useState(false);
  const box = {
    width: "100%", font: "var(--type-body)", color: "var(--text-body)",
    background: "var(--stone-0)", borderRadius: "var(--radius-control)",
    border: "1px solid " + (invalid ? "var(--danger)" : focus ? "var(--clay-500)" : "var(--border-strong)"),
    boxShadow: focus ? "0 0 0 3px rgba(140,97,56,.14)" : "none",
    outline: "none", transition: "var(--transition-control)",
    opacity: disabled ? 0.55 : 1,
  };
  return (
    <textarea
      {...rest} id={id} rows={rows} value={value} onChange={onChange} placeholder={placeholder} disabled={disabled}
      onFocus={() => setFocus(true)} onBlur={() => setFocus(false)}
      style={{ ...box, padding: "var(--space-5)", resize: "vertical", fontFamily: "var(--font-body)", ...style }}
    />
  );
}
