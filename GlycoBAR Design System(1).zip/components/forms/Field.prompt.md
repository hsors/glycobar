Label + hint/error wrapper for any control. Always wrap form controls in it rather than hand-rolling labels.

\`\`\`jsx
<Field label="Work email" required hint="We reply within two working days" htmlFor="email">
  <Input id="email" type="email" placeholder="you@lab.org" />
</Field>
\`\`\`
