import React from "react";
import { Icon } from "../core/Icon.jsx";

export function Input({ value, onChange, placeholder, type = "text", icon, invalid = false, disabled = false, id, style, ...rest }) {
  const [focus, setFocus] = React.useState(false);
  const box = {
    width: "100%", font: "var(--type-body)", color: "var(--text-body)",
    background: "var(--stone-0)", borderRadius: "var(--radius-control)",
    border: "1px solid " + (invalid ? "var(--danger)" : focus ? "var(--clay-500)" : "var(--border-strong)"),
    boxShadow: focus ? "0 0 0 3px rgba(140,97,56,.14)" : "none",
    outline: "none", transition: "var(--transition-control)",
    opacity: disabled ? 0.55 : 1,
  };
  return (
    <div style={{ position: "relative", display: "flex", alignItems: "center" }}>
      {icon ? <Icon name={icon} size={17} color="var(--text-muted)" style={{ position: "absolute", left: 12 }} /> : null}
      <input
        {...rest} id={id} type={type} value={value} onChange={onChange} placeholder={placeholder} disabled={disabled}
        onFocus={() => setFocus(true)} onBlur={() => setFocus(false)}
        style={{ ...box, height: 44, padding: icon ? "0 var(--space-5) 0 38px" : "0 var(--space-5)", ...style }}
      />
    </div>
  );
}
