import React from "react";

export function Switch({ checked = false, onChange, label, disabled = false, style, ...rest }) {
  return (
    <label {...rest} style={{ display: "inline-flex", alignItems: "center", gap: "var(--space-5)", cursor: disabled ? "not-allowed" : "pointer", opacity: disabled ? 0.55 : 1, ...style }}>
      <span
        role="switch" aria-checked={checked}
        onClick={() => !disabled && onChange && onChange(!checked)}
        style={{
          width: 42, height: 24, borderRadius: "var(--radius-pill)", padding: 2, flex: "0 0 auto",
          background: checked ? "var(--clay-600)" : "var(--stone-300)",
          transition: "background-color var(--dur-base) var(--ease-out)",
          display: "inline-flex", alignItems: "center",
        }}
      >
        <span style={{
          width: 20, height: 20, borderRadius: "var(--radius-round)", background: "var(--stone-0)",
          boxShadow: "var(--shadow-xs)",
          transform: checked ? "translateX(18px)" : "translateX(0)",
          transition: "transform var(--dur-base) var(--ease-out)",
        }} />
      </span>
      {label ? <span style={{ font: "var(--type-small)", color: "var(--text-body)" }}>{label}</span> : null}
    </label>
  );
}
