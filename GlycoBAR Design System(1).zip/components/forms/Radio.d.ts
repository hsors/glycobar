export interface RadioProps {
  checked?: boolean;
  /** Receives `value`. */
  onChange?: (value?: string) => void;
  label?: string;
  disabled?: boolean;
  name?: string;
  value?: string;
  style?: React.CSSProperties;
}
export declare function Radio(props: RadioProps): JSX.Element;
