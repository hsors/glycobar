import React from "react";

export function Radio({ checked = false, onChange, label, disabled = false, name, value, style, ...rest }) {
  return (
    <label {...rest} style={{ display: "inline-flex", alignItems: "center", gap: "var(--space-4)", cursor: disabled ? "not-allowed" : "pointer", opacity: disabled ? 0.55 : 1, ...style }}>
      <span
        role="radio" aria-checked={checked} data-name={name} data-value={value}
        onClick={() => !disabled && onChange && onChange(value)}
        style={{
          width: 20, height: 20, borderRadius: "var(--radius-round)", flex: "0 0 auto",
          display: "inline-flex", alignItems: "center", justifyContent: "center",
          background: "var(--stone-0)",
          border: "1px solid " + (checked ? "var(--clay-600)" : "var(--border-strong)"),
          transition: "var(--transition-control)",
        }}
      >
        {checked ? <span style={{ width: 10, height: 10, borderRadius: "var(--radius-round)", background: "var(--clay-600)" }} /> : null}
      </span>
      {label ? <span style={{ font: "var(--type-small)", color: "var(--text-body)" }}>{label}</span> : null}
    </label>
  );
}
