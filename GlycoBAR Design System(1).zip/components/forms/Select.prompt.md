Native select with a chevron Icon; matches Input's box exactly.

\`\`\`jsx
<Select placeholder="Choose a product" options={["A tetraose", "B tetraose", "A hexasaccharide"]} />
\`\`\`
