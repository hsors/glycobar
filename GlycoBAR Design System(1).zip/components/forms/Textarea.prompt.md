Multi-line variant of Input for quote requests and scientific enquiries.

\`\`\`jsx
<Textarea rows={5} placeholder="Describe your application" />
\`\`\`
