export interface FieldProps {
  label?: string;
  /** Helper copy under the control. */
  hint?: string;
  /** Replaces the hint and turns it red. */
  error?: string;
  required?: boolean;
  htmlFor?: string;
  children?: React.ReactNode;
  style?: React.CSSProperties;
}
export declare function Field(props: FieldProps): JSX.Element;
