/* @ds-bundle: {"format":4,"namespace":"GlycoBARDesignSystem_d44615","components":[{"name":"Badge","sourcePath":"components/core/Badge.jsx"},{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"Callout","sourcePath":"components/core/Callout.jsx"},{"name":"Card","sourcePath":"components/core/Card.jsx"},{"name":"Icon","sourcePath":"components/core/Icon.jsx"},{"name":"IconButton","sourcePath":"components/core/IconButton.jsx"},{"name":"Stat","sourcePath":"components/core/Stat.jsx"},{"name":"Tag","sourcePath":"components/core/Tag.jsx"},{"name":"Dialog","sourcePath":"components/feedback/Dialog.jsx"},{"name":"Toast","sourcePath":"components/feedback/Toast.jsx"},{"name":"Tooltip","sourcePath":"components/feedback/Tooltip.jsx"},{"name":"Checkbox","sourcePath":"components/forms/Checkbox.jsx"},{"name":"Field","sourcePath":"components/forms/Field.jsx"},{"name":"Input","sourcePath":"components/forms/Input.jsx"},{"name":"Radio","sourcePath":"components/forms/Radio.jsx"},{"name":"Select","sourcePath":"components/forms/Select.jsx"},{"name":"Switch","sourcePath":"components/forms/Switch.jsx"},{"name":"Textarea","sourcePath":"components/forms/Textarea.jsx"},{"name":"MediaSection","sourcePath":"components/layout/MediaSection.jsx"},{"name":"PageHero","sourcePath":"components/layout/PageHero.jsx"},{"name":"SectionHeader","sourcePath":"components/layout/SectionHeader.jsx"},{"name":"Footer","sourcePath":"components/navigation/Footer.jsx"},{"name":"NavBar","sourcePath":"components/navigation/NavBar.jsx"},{"name":"Tabs","sourcePath":"components/navigation/Tabs.jsx"},{"name":"Glycan","sourcePath":"components/science/Glycan.jsx"},{"name":"GLYCOBAR_A","sourcePath":"components/science/Glycan.jsx"},{"name":"GLYCOBAR_B","sourcePath":"components/science/Glycan.jsx"},{"name":"SNFG","sourcePath":"components/science/GlycanSymbol.jsx"},{"name":"GlycanSymbol","sourcePath":"components/science/GlycanSymbol.jsx"},{"name":"GlycanTrail","sourcePath":"components/science/GlycanTrail.jsx"}],"sourceHashes":{"components/core/Badge.jsx":"24df7b99be64","components/core/Button.jsx":"9598b5b2b4da","components/core/Callout.jsx":"cdfabb52d1ac","components/core/Card.jsx":"9e515f95e36a","components/core/Icon.jsx":"a0f608128f99","components/core/IconButton.jsx":"8af796f15305","components/core/Stat.jsx":"78b22da7a444","components/core/Tag.jsx":"7100c3481be2","components/feedback/Dialog.jsx":"780623cb50c4","components/feedback/Toast.jsx":"84261430624b","components/feedback/Tooltip.jsx":"67193d2a1fd8","components/forms/Checkbox.jsx":"a23153365a91","components/forms/Field.jsx":"fe4e9ba62ea2","components/forms/Input.jsx":"279a6611fd8e","components/forms/Radio.jsx":"de5df00971b8","components/forms/Select.jsx":"0ae813e19872","components/forms/Switch.jsx":"605df073027b","components/forms/Textarea.jsx":"8aa81b628aec","components/layout/MediaSection.jsx":"2ce909835836","components/layout/PageHero.jsx":"8cf88aed6f83","components/layout/SectionHeader.jsx":"a72ef2e17673","components/navigation/Footer.jsx":"5c50e73a46d7","components/navigation/NavBar.jsx":"38cf4889377d","components/navigation/Tabs.jsx":"47a4576740b8","components/science/Glycan.jsx":"a72adaab509e","components/science/GlycanSymbol.jsx":"59987943df7f","components/science/GlycanTrail.jsx":"1613b5e07482","ui_kits/website/About.jsx":"4f6a04caa573","ui_kits/website/Home.jsx":"b275f5114f12","ui_kits/website/Markets.jsx":"bf89d29f043a","ui_kits/website/Products.jsx":"620a3447539a","ui_kits/website/app.jsx":"3d36b7f5d58a","ui_kits/website/shared.jsx":"568f82938e94"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.GlycoBARDesignSystem_d44615 = window.GlycoBARDesignSystem_d44615 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/core/Badge.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const TONES = {
  brand: {
    background: "var(--clay-100)",
    color: "var(--clay-800)"
  },
  neutral: {
    background: "var(--stone-100)",
    color: "var(--stone-700)"
  },
  a: {
    background: "var(--antigen-a-soft)",
    color: "var(--antigen-a)"
  },
  b: {
    background: "var(--antigen-b-soft)",
    color: "var(--antigen-b)"
  },
  plasma: {
    background: "var(--plasma-soft)",
    color: "#8A6910"
  },
  universal: {
    background: "var(--universal-soft)",
    color: "var(--universal)"
  }
};
function Badge({
  children,
  tone = "brand",
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("span", _extends({}, rest, {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: "var(--space-2)",
      padding: "3px var(--space-4)",
      borderRadius: "var(--radius-pill)",
      font: "var(--weight-semibold) var(--text-2xs)/1.4 var(--font-body)",
      letterSpacing: "var(--tracking-wide)",
      textTransform: "uppercase",
      ...TONES[tone],
      ...style
    }
  }), children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Badge.jsx", error: String((e && e.message) || e) }); }

// components/core/Card.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Card({
  children,
  tone = "plain",
  interactive = false,
  padding = "var(--card-pad)",
  style,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const tones = {
    plain: {
      background: "var(--surface-card)",
      border: "1px solid var(--border-hairline)"
    },
    tint: {
      background: "var(--surface-alt)",
      border: "1px solid var(--clay-200)"
    },
    inverse: {
      background: "var(--surface-inverse)",
      border: "1px solid var(--clay-800)",
      color: "var(--clay-100)"
    }
  };
  return /*#__PURE__*/React.createElement("div", _extends({}, rest, {
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      borderRadius: "var(--radius-card)",
      padding,
      boxShadow: interactive && hover ? "var(--shadow-lg)" : "var(--shadow-sm)",
      transform: interactive && hover ? "var(--lift-hover)" : "none",
      transition: "var(--transition-lift)",
      cursor: interactive ? "pointer" : undefined,
      ...tones[tone],
      ...style
    }
  }), children);
}
Object.assign(__ds_scope, { Card });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Card.jsx", error: String((e && e.message) || e) }); }

// components/core/Icon.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const CDN = "https://unpkg.com/lucide-static@0.462.0/icons/";

/* Lucide is a documented substitution: GlycoBAR's site ships Elementor's
   inline Font Awesome SVGs, which are not redistributable here. Lucide's
   1.5px-stroke outline set is the closest free match. */
function Icon({
  name,
  size = 20,
  color = "currentColor",
  strokeAlign,
  style,
  ...rest
}) {
  const url = "url(" + CDN + name + ".svg)";
  return /*#__PURE__*/React.createElement("span", _extends({
    "aria-hidden": "true"
  }, rest, {
    style: {
      display: "inline-block",
      width: size,
      height: size,
      flex: "0 0 auto",
      backgroundColor: color,
      WebkitMaskImage: url,
      maskImage: url,
      WebkitMaskRepeat: "no-repeat",
      maskRepeat: "no-repeat",
      WebkitMaskSize: "contain",
      maskSize: "contain",
      WebkitMaskPosition: "center",
      maskPosition: "center",
      ...style
    }
  }));
}
Object.assign(__ds_scope, { Icon });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Icon.jsx", error: String((e && e.message) || e) }); }

// components/core/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const SIZES = {
  sm: {
    padding: "0 var(--space-5)",
    height: 34,
    font: "var(--type-small)",
    icon: 15
  },
  md: {
    padding: "0 var(--space-7)",
    height: 44,
    font: "var(--type-label)",
    icon: 17
  },
  lg: {
    padding: "0 var(--space-9)",
    height: 54,
    font: "var(--weight-medium) var(--text-md)/1.2 var(--font-body)",
    icon: 19
  }
};
const VARIANTS = {
  primary: {
    background: "var(--surface-brand)",
    color: "var(--text-onbrand)",
    border: "1px solid var(--clay-600)",
    boxShadow: "var(--shadow-brand)"
  },
  secondary: {
    background: "var(--stone-0)",
    color: "var(--clay-700)",
    border: "1px solid var(--border-brand)",
    boxShadow: "var(--shadow-xs)"
  },
  ghost: {
    background: "transparent",
    color: "var(--clay-700)",
    border: "1px solid transparent",
    boxShadow: "none"
  },
  inverse: {
    background: "var(--stone-0)",
    color: "var(--clay-800)",
    border: "1px solid transparent",
    boxShadow: "var(--shadow-md)"
  }
};
const HOVER = {
  primary: {
    background: "var(--clay-700)"
  },
  secondary: {
    background: "var(--clay-50)",
    borderColor: "var(--clay-400)"
  },
  ghost: {
    background: "var(--clay-100)"
  },
  inverse: {
    background: "var(--clay-50)"
  }
};
function Button({
  children,
  variant = "primary",
  size = "md",
  iconLeft,
  iconRight,
  fullWidth = false,
  disabled = false,
  href,
  onClick,
  type = "button",
  style,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const [press, setPress] = React.useState(false);
  const s = SIZES[size] || SIZES.md;
  const v = VARIANTS[variant] || VARIANTS.primary;
  const Tag = href ? "a" : "button";
  const css = {
    display: "inline-flex",
    alignItems: "center",
    justifyContent: "center",
    gap: "var(--space-4)",
    height: s.height,
    padding: s.padding,
    font: s.font,
    letterSpacing: "var(--tracking-wide)",
    textTransform: "uppercase",
    borderRadius: "var(--radius-control)",
    cursor: disabled ? "not-allowed" : "pointer",
    width: fullWidth ? "100%" : undefined,
    textDecoration: "none",
    transition: "var(--transition-control), transform var(--dur-fast) var(--ease-out)",
    opacity: disabled ? 0.45 : 1,
    transform: press && !disabled ? "scale(var(--press-scale))" : "none",
    ...v,
    ...(hover && !disabled ? HOVER[variant] : null),
    ...style
  };
  return /*#__PURE__*/React.createElement(Tag, _extends({}, rest, {
    type: href ? undefined : type,
    href: href,
    onClick: disabled ? undefined : onClick,
    disabled: href ? undefined : disabled,
    style: css,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => {
      setHover(false);
      setPress(false);
    },
    onMouseDown: () => setPress(true),
    onMouseUp: () => setPress(false)
  }), iconLeft ? /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: iconLeft,
    size: s.icon
  }) : null, children, iconRight ? /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: iconRight,
    size: s.icon
  }) : null);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/core/Callout.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const TONES = {
  info: {
    accent: "var(--info)",
    background: "var(--antigen-b-soft)",
    icon: "info"
  },
  note: {
    accent: "var(--clay-600)",
    background: "var(--clay-50)",
    icon: "flask-conical"
  },
  warning: {
    accent: "var(--warning)",
    background: "var(--plasma-soft)",
    icon: "triangle-alert"
  },
  danger: {
    accent: "var(--danger)",
    background: "var(--antigen-a-soft)",
    icon: "octagon-alert"
  }
};
function Callout({
  title,
  children,
  tone = "note",
  style,
  ...rest
}) {
  const t = TONES[tone] || TONES.note;
  return /*#__PURE__*/React.createElement("div", _extends({}, rest, {
    style: {
      display: "flex",
      gap: "var(--space-5)",
      padding: "var(--space-6) var(--space-7)",
      background: t.background,
      borderRadius: "var(--radius-card)",
      borderTop: "var(--rule-accent) solid " + t.accent,
      ...style
    }
  }), /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: t.icon,
    size: 20,
    color: t.accent,
    style: {
      marginTop: 2
    }
  }), /*#__PURE__*/React.createElement("div", null, title ? /*#__PURE__*/React.createElement("div", {
    style: {
      font: "var(--weight-semibold) var(--text-sm)/1.4 var(--font-body)",
      color: "var(--text-heading)",
      marginBottom: "var(--space-2)"
    }
  }, title) : null, /*#__PURE__*/React.createElement("div", {
    style: {
      font: "var(--type-small)",
      color: "var(--text-body)"
    }
  }, children)));
}
Object.assign(__ds_scope, { Callout });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Callout.jsx", error: String((e && e.message) || e) }); }

// components/core/IconButton.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const SIZES = {
  sm: 32,
  md: 40,
  lg: 48
};
function IconButton({
  icon,
  label,
  variant = "secondary",
  size = "md",
  disabled = false,
  onClick,
  href,
  style,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const d = SIZES[size] || SIZES.md;
  const solid = variant === "primary";
  const Tag = href ? "a" : "button";
  return /*#__PURE__*/React.createElement(Tag, _extends({}, rest, {
    href: href,
    "aria-label": label,
    title: label,
    disabled: href ? undefined : disabled,
    onClick: disabled ? undefined : onClick,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      width: d,
      height: d,
      borderRadius: "var(--radius-control)",
      cursor: disabled ? "not-allowed" : "pointer",
      border: solid ? "1px solid var(--clay-600)" : "1px solid " + (variant === "ghost" ? "transparent" : "var(--border-brand)"),
      background: solid ? hover ? "var(--clay-700)" : "var(--surface-brand)" : hover ? "var(--clay-100)" : variant === "ghost" ? "transparent" : "var(--stone-0)",
      color: solid ? "var(--text-onbrand)" : "var(--clay-700)",
      opacity: disabled ? 0.45 : 1,
      transition: "var(--transition-control)",
      ...style
    }
  }), /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: Math.round(d * 0.45)
  }));
}
Object.assign(__ds_scope, { IconButton });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/IconButton.jsx", error: String((e && e.message) || e) }); }

// components/core/Stat.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Stat({
  value,
  label,
  unit,
  tone = "brand",
  align = "left",
  style,
  ...rest
}) {
  const color = tone === "inverse" ? "var(--clay-200)" : "var(--brand)";
  return /*#__PURE__*/React.createElement("div", _extends({}, rest, {
    style: {
      textAlign: align,
      ...style
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      font: "var(--weight-light) var(--text-5xl)/1 var(--font-display)",
      color,
      letterSpacing: "var(--tracking-tight)"
    }
  }, value, unit ? /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: "var(--text-2xl)",
      marginLeft: 2
    }
  }, unit) : null), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: "var(--space-4)",
      font: "var(--type-eyebrow)",
      letterSpacing: "var(--tracking-label)",
      textTransform: "uppercase",
      color: tone === "inverse" ? "var(--clay-300)" : "var(--text-muted)"
    }
  }, label));
}
Object.assign(__ds_scope, { Stat });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Stat.jsx", error: String((e && e.message) || e) }); }

// components/core/Tag.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Tag({
  children,
  onRemove,
  selected = false,
  onClick,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("span", _extends({}, rest, {
    onClick: onClick,
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: "var(--space-3)",
      padding: "5px var(--space-5)",
      borderRadius: "var(--radius-control)",
      font: "var(--type-small)",
      background: selected ? "var(--clay-600)" : "var(--stone-0)",
      color: selected ? "var(--text-onbrand)" : "var(--stone-700)",
      border: "1px solid " + (selected ? "var(--clay-600)" : "var(--border-hairline)"),
      cursor: onClick ? "pointer" : "default",
      transition: "var(--transition-control)",
      ...style
    }
  }), children, onRemove ? /*#__PURE__*/React.createElement("button", {
    onClick: e => {
      e.stopPropagation();
      onRemove();
    },
    "aria-label": "Remove",
    style: {
      display: "inline-flex",
      border: 0,
      background: "transparent",
      padding: 0,
      cursor: "pointer",
      color: "inherit"
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "x",
    size: 13
  })) : null);
}
Object.assign(__ds_scope, { Tag });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Tag.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Dialog.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Dialog({
  open = false,
  title,
  children,
  footer,
  onClose,
  width = 520,
  style,
  ...rest
}) {
  if (!open) return null;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: "fixed",
      inset: 0,
      zIndex: 60,
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      padding: "var(--space-9)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    onClick: onClose,
    style: {
      position: "absolute",
      inset: 0,
      background: "var(--veil-dark)",
      backdropFilter: "var(--blur-veil)"
    }
  }), /*#__PURE__*/React.createElement("div", _extends({}, rest, {
    role: "dialog",
    "aria-modal": "true",
    style: {
      position: "relative",
      width: "100%",
      maxWidth: width,
      background: "var(--surface-card)",
      borderRadius: "var(--radius-card)",
      boxShadow: "var(--shadow-lg)",
      padding: "var(--card-pad-lg)",
      animation: "none",
      ...style
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "flex-start",
      justifyContent: "space-between",
      gap: "var(--space-6)"
    }
  }, /*#__PURE__*/React.createElement("h3", {
    style: {
      font: "var(--type-h3)",
      color: "var(--text-heading)"
    }
  }, title), /*#__PURE__*/React.createElement(__ds_scope.IconButton, {
    icon: "x",
    label: "Close",
    variant: "ghost",
    size: "sm",
    onClick: onClose
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: "var(--space-6)",
      font: "var(--type-body)",
      color: "var(--text-body)"
    }
  }, children), footer ? /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: "var(--space-9)",
      display: "flex",
      gap: "var(--space-5)",
      justifyContent: "flex-end"
    }
  }, footer) : null));
}
Object.assign(__ds_scope, { Dialog });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Dialog.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Toast.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const TONES = {
  success: {
    icon: "check",
    color: "var(--success)"
  },
  error: {
    icon: "octagon-alert",
    color: "var(--danger)"
  },
  info: {
    icon: "info",
    color: "var(--info)"
  }
};
function Toast({
  message,
  tone = "success",
  onDismiss,
  style,
  ...rest
}) {
  const t = TONES[tone] || TONES.info;
  return /*#__PURE__*/React.createElement("div", _extends({}, rest, {
    role: "status",
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: "var(--space-5)",
      background: "var(--surface-inverse)",
      color: "var(--clay-100)",
      padding: "var(--space-5) var(--space-7)",
      borderRadius: "var(--radius-control)",
      boxShadow: "var(--shadow-lg)",
      font: "var(--type-small)",
      ...style
    }
  }), /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: t.icon,
    size: 17,
    color: t.color
  }), /*#__PURE__*/React.createElement("span", null, message), onDismiss ? /*#__PURE__*/React.createElement("button", {
    onClick: onDismiss,
    "aria-label": "Dismiss",
    style: {
      background: "transparent",
      border: 0,
      cursor: "pointer",
      color: "var(--clay-400)",
      display: "inline-flex",
      padding: 0,
      marginLeft: "var(--space-4)"
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "x",
    size: 15
  })) : null);
}
Object.assign(__ds_scope, { Toast });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Toast.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Tooltip.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Tooltip({
  label,
  children,
  placement = "top",
  style,
  ...rest
}) {
  const [open, setOpen] = React.useState(false);
  const pos = placement === "bottom" ? {
    top: "calc(100% + 8px)",
    left: "50%",
    transform: "translateX(-50%)"
  } : {
    bottom: "calc(100% + 8px)",
    left: "50%",
    transform: "translateX(-50%)"
  };
  return /*#__PURE__*/React.createElement("span", _extends({}, rest, {
    onMouseEnter: () => setOpen(true),
    onMouseLeave: () => setOpen(false),
    style: {
      position: "relative",
      display: "inline-flex",
      ...style
    }
  }), children, open ? /*#__PURE__*/React.createElement("span", {
    role: "tooltip",
    style: {
      position: "absolute",
      ...pos,
      whiteSpace: "nowrap",
      zIndex: 40,
      background: "var(--clay-900)",
      color: "var(--clay-100)",
      font: "var(--weight-regular) var(--text-xs)/1.3 var(--font-body)",
      padding: "6px var(--space-5)",
      borderRadius: "var(--radius-xs)",
      boxShadow: "var(--shadow-md)"
    }
  }, label) : null);
}
Object.assign(__ds_scope, { Tooltip });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Tooltip.jsx", error: String((e && e.message) || e) }); }

// components/forms/Checkbox.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Checkbox({
  checked = false,
  onChange,
  label,
  disabled = false,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("label", _extends({}, rest, {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: "var(--space-4)",
      cursor: disabled ? "not-allowed" : "pointer",
      opacity: disabled ? 0.55 : 1,
      ...style
    }
  }), /*#__PURE__*/React.createElement("span", {
    onClick: () => !disabled && onChange && onChange(!checked),
    style: {
      width: 20,
      height: 20,
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      borderRadius: "var(--radius-xs)",
      flex: "0 0 auto",
      background: checked ? "var(--clay-600)" : "var(--stone-0)",
      border: "1px solid " + (checked ? "var(--clay-600)" : "var(--border-strong)"),
      transition: "var(--transition-control)"
    }
  }, checked ? /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "check",
    size: 14,
    color: "#fff"
  }) : null), label ? /*#__PURE__*/React.createElement("span", {
    style: {
      font: "var(--type-small)",
      color: "var(--text-body)"
    }
  }, label) : null);
}
Object.assign(__ds_scope, { Checkbox });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Checkbox.jsx", error: String((e && e.message) || e) }); }

// components/forms/Field.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Field({
  label,
  hint,
  error,
  required = false,
  htmlFor,
  children,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({}, rest, {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: "var(--space-3)",
      ...style
    }
  }), label ? /*#__PURE__*/React.createElement("label", {
    htmlFor: htmlFor,
    style: {
      font: "var(--type-label)",
      color: "var(--text-heading)"
    }
  }, label, required ? /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--danger)",
      marginLeft: 3
    }
  }, "*") : null) : null, children, error ? /*#__PURE__*/React.createElement("span", {
    style: {
      font: "var(--weight-regular) var(--text-xs)/1.4 var(--font-body)",
      color: "var(--danger)"
    }
  }, error) : hint ? /*#__PURE__*/React.createElement("span", {
    style: {
      font: "var(--weight-regular) var(--text-xs)/1.4 var(--font-body)",
      color: "var(--text-muted)"
    }
  }, hint) : null);
}
Object.assign(__ds_scope, { Field });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Field.jsx", error: String((e && e.message) || e) }); }

// components/forms/Input.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Input({
  value,
  onChange,
  placeholder,
  type = "text",
  icon,
  invalid = false,
  disabled = false,
  id,
  style,
  ...rest
}) {
  const [focus, setFocus] = React.useState(false);
  const box = {
    width: "100%",
    font: "var(--type-body)",
    color: "var(--text-body)",
    background: "var(--stone-0)",
    borderRadius: "var(--radius-control)",
    border: "1px solid " + (invalid ? "var(--danger)" : focus ? "var(--clay-500)" : "var(--border-strong)"),
    boxShadow: focus ? "0 0 0 3px rgba(140,97,56,.14)" : "none",
    outline: "none",
    transition: "var(--transition-control)",
    opacity: disabled ? 0.55 : 1
  };
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: "relative",
      display: "flex",
      alignItems: "center"
    }
  }, icon ? /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: 17,
    color: "var(--text-muted)",
    style: {
      position: "absolute",
      left: 12
    }
  }) : null, /*#__PURE__*/React.createElement("input", _extends({}, rest, {
    id: id,
    type: type,
    value: value,
    onChange: onChange,
    placeholder: placeholder,
    disabled: disabled,
    onFocus: () => setFocus(true),
    onBlur: () => setFocus(false),
    style: {
      ...box,
      height: 44,
      padding: icon ? "0 var(--space-5) 0 38px" : "0 var(--space-5)",
      ...style
    }
  })));
}
Object.assign(__ds_scope, { Input });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Input.jsx", error: String((e && e.message) || e) }); }

// components/forms/Radio.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Radio({
  checked = false,
  onChange,
  label,
  disabled = false,
  name,
  value,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("label", _extends({}, rest, {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: "var(--space-4)",
      cursor: disabled ? "not-allowed" : "pointer",
      opacity: disabled ? 0.55 : 1,
      ...style
    }
  }), /*#__PURE__*/React.createElement("span", {
    role: "radio",
    "aria-checked": checked,
    "data-name": name,
    "data-value": value,
    onClick: () => !disabled && onChange && onChange(value),
    style: {
      width: 20,
      height: 20,
      borderRadius: "var(--radius-round)",
      flex: "0 0 auto",
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      background: "var(--stone-0)",
      border: "1px solid " + (checked ? "var(--clay-600)" : "var(--border-strong)"),
      transition: "var(--transition-control)"
    }
  }, checked ? /*#__PURE__*/React.createElement("span", {
    style: {
      width: 10,
      height: 10,
      borderRadius: "var(--radius-round)",
      background: "var(--clay-600)"
    }
  }) : null), label ? /*#__PURE__*/React.createElement("span", {
    style: {
      font: "var(--type-small)",
      color: "var(--text-body)"
    }
  }, label) : null);
}
Object.assign(__ds_scope, { Radio });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Radio.jsx", error: String((e && e.message) || e) }); }

// components/forms/Select.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Select({
  value,
  onChange,
  options = [],
  placeholder,
  invalid = false,
  disabled = false,
  id,
  style,
  ...rest
}) {
  const [focus, setFocus] = React.useState(false);
  const box = {
    width: "100%",
    font: "var(--type-body)",
    color: "var(--text-body)",
    background: "var(--stone-0)",
    borderRadius: "var(--radius-control)",
    border: "1px solid " + (invalid ? "var(--danger)" : focus ? "var(--clay-500)" : "var(--border-strong)"),
    boxShadow: focus ? "0 0 0 3px rgba(140,97,56,.14)" : "none",
    outline: "none",
    transition: "var(--transition-control)",
    opacity: disabled ? 0.55 : 1
  };
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: "relative",
      display: "flex",
      alignItems: "center"
    }
  }, /*#__PURE__*/React.createElement("select", _extends({}, rest, {
    id: id,
    value: value,
    onChange: onChange,
    disabled: disabled,
    onFocus: () => setFocus(true),
    onBlur: () => setFocus(false),
    style: {
      ...box,
      height: 44,
      padding: "0 38px 0 var(--space-5)",
      appearance: "none",
      cursor: disabled ? "not-allowed" : "pointer",
      ...style
    }
  }), placeholder ? /*#__PURE__*/React.createElement("option", {
    value: ""
  }, placeholder) : null, options.map(o => {
    const val = typeof o === "string" ? o : o.value;
    const lab = typeof o === "string" ? o : o.label;
    return /*#__PURE__*/React.createElement("option", {
      key: val,
      value: val
    }, lab);
  })), /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "chevron-down",
    size: 16,
    color: "var(--clay-600)",
    style: {
      position: "absolute",
      right: 12,
      pointerEvents: "none"
    }
  }));
}
Object.assign(__ds_scope, { Select });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Select.jsx", error: String((e && e.message) || e) }); }

// components/forms/Switch.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Switch({
  checked = false,
  onChange,
  label,
  disabled = false,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("label", _extends({}, rest, {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: "var(--space-5)",
      cursor: disabled ? "not-allowed" : "pointer",
      opacity: disabled ? 0.55 : 1,
      ...style
    }
  }), /*#__PURE__*/React.createElement("span", {
    role: "switch",
    "aria-checked": checked,
    onClick: () => !disabled && onChange && onChange(!checked),
    style: {
      width: 42,
      height: 24,
      borderRadius: "var(--radius-pill)",
      padding: 2,
      flex: "0 0 auto",
      background: checked ? "var(--clay-600)" : "var(--stone-300)",
      transition: "background-color var(--dur-base) var(--ease-out)",
      display: "inline-flex",
      alignItems: "center"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 20,
      height: 20,
      borderRadius: "var(--radius-round)",
      background: "var(--stone-0)",
      boxShadow: "var(--shadow-xs)",
      transform: checked ? "translateX(18px)" : "translateX(0)",
      transition: "transform var(--dur-base) var(--ease-out)"
    }
  })), label ? /*#__PURE__*/React.createElement("span", {
    style: {
      font: "var(--type-small)",
      color: "var(--text-body)"
    }
  }, label) : null);
}
Object.assign(__ds_scope, { Switch });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Switch.jsx", error: String((e && e.message) || e) }); }

// components/forms/Textarea.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Textarea({
  value,
  onChange,
  placeholder,
  rows = 4,
  invalid = false,
  disabled = false,
  id,
  style,
  ...rest
}) {
  const [focus, setFocus] = React.useState(false);
  const box = {
    width: "100%",
    font: "var(--type-body)",
    color: "var(--text-body)",
    background: "var(--stone-0)",
    borderRadius: "var(--radius-control)",
    border: "1px solid " + (invalid ? "var(--danger)" : focus ? "var(--clay-500)" : "var(--border-strong)"),
    boxShadow: focus ? "0 0 0 3px rgba(140,97,56,.14)" : "none",
    outline: "none",
    transition: "var(--transition-control)",
    opacity: disabled ? 0.55 : 1
  };
  return /*#__PURE__*/React.createElement("textarea", _extends({}, rest, {
    id: id,
    rows: rows,
    value: value,
    onChange: onChange,
    placeholder: placeholder,
    disabled: disabled,
    onFocus: () => setFocus(true),
    onBlur: () => setFocus(false),
    style: {
      ...box,
      padding: "var(--space-5)",
      resize: "vertical",
      fontFamily: "var(--font-body)",
      ...style
    }
  }));
}
Object.assign(__ds_scope, { Textarea });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Textarea.jsx", error: String((e && e.message) || e) }); }

// components/layout/MediaSection.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function MediaSection({
  image,
  imageAlt = "",
  reverse = false,
  ratio = "1fr 1fr",
  tone = "page",
  children,
  style,
  ...rest
}) {
  const bg = tone === "alt" ? "var(--surface-alt)" : tone === "inverse" ? "var(--surface-inverse)" : "var(--surface-page)";
  return /*#__PURE__*/React.createElement("section", _extends({}, rest, {
    style: {
      background: bg,
      padding: "var(--section-y) 0",
      ...style
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: "var(--container-max)",
      margin: "0 auto",
      padding: "0 var(--gutter)",
      display: "grid",
      gridTemplateColumns: ratio,
      gap: "var(--space-12)",
      alignItems: "center"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      order: reverse ? 2 : 1
    }
  }, children), /*#__PURE__*/React.createElement("div", {
    style: {
      order: reverse ? 1 : 2
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: image,
    alt: imageAlt,
    style: {
      width: "100%",
      display: "block",
      borderRadius: "var(--radius-image)",
      boxShadow: "var(--shadow-md)",
      objectFit: "cover"
    }
  }))));
}
Object.assign(__ds_scope, { MediaSection });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/layout/MediaSection.jsx", error: String((e && e.message) || e) }); }

// components/layout/PageHero.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function PageHero({
  eyebrow,
  title,
  lead,
  image,
  imageAlt = "",
  height = 420,
  children,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("section", _extends({}, rest, {
    style: {
      position: "relative",
      minHeight: height,
      display: "flex",
      alignItems: "flex-end",
      background: "var(--clay-900)",
      overflow: "hidden",
      ...style
    }
  }), image ? /*#__PURE__*/React.createElement("img", {
    src: image,
    alt: imageAlt,
    style: {
      position: "absolute",
      inset: 0,
      width: "100%",
      height: "100%",
      objectFit: "cover",
      filter: "saturate(.92)"
    }
  }) : null, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      inset: 0,
      background: "var(--grad-protect)"
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "relative",
      maxWidth: "var(--container-max)",
      width: "100%",
      margin: "0 auto",
      padding: "var(--space-12) var(--gutter)"
    }
  }, eyebrow ? /*#__PURE__*/React.createElement("div", {
    style: {
      font: "var(--type-eyebrow)",
      letterSpacing: "var(--tracking-label)",
      textTransform: "uppercase",
      color: "var(--clay-300)"
    }
  }, eyebrow) : null, /*#__PURE__*/React.createElement("h1", {
    style: {
      marginTop: "var(--space-5)",
      font: "var(--weight-light) var(--text-6xl)/var(--leading-tight) var(--font-display)",
      color: "var(--stone-0)",
      letterSpacing: "var(--tracking-tight)",
      maxWidth: 900
    }
  }, title), lead ? /*#__PURE__*/React.createElement("p", {
    style: {
      marginTop: "var(--space-6)",
      font: "var(--type-lead)",
      color: "var(--clay-100)",
      maxWidth: 620
    }
  }, lead) : null, children ? /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: "var(--space-8)",
      display: "flex",
      gap: "var(--space-5)"
    }
  }, children) : null));
}
Object.assign(__ds_scope, { PageHero });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/layout/PageHero.jsx", error: String((e && e.message) || e) }); }

// components/layout/SectionHeader.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function SectionHeader({
  eyebrow,
  title,
  lead,
  align = "left",
  tone = "light",
  maxWidth = 640,
  children,
  style,
  ...rest
}) {
  const inverse = tone === "inverse";
  return /*#__PURE__*/React.createElement("div", _extends({}, rest, {
    style: {
      textAlign: align,
      maxWidth,
      marginLeft: align === "center" ? "auto" : 0,
      marginRight: align === "center" ? "auto" : 0,
      ...style
    }
  }), eyebrow ? /*#__PURE__*/React.createElement("div", {
    style: {
      font: "var(--type-eyebrow)",
      letterSpacing: "var(--tracking-label)",
      textTransform: "uppercase",
      color: inverse ? "var(--clay-400)" : "var(--brand)"
    }
  }, eyebrow) : null, title ? /*#__PURE__*/React.createElement("h2", {
    style: {
      marginTop: "var(--space-5)",
      font: "var(--type-h2)",
      color: inverse ? "var(--stone-0)" : "var(--text-heading)"
    }
  }, title) : null, lead ? /*#__PURE__*/React.createElement("p", {
    style: {
      marginTop: "var(--space-6)",
      font: "var(--type-lead)",
      color: inverse ? "var(--clay-200)" : "var(--text-body)"
    }
  }, lead) : null, children ? /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: "var(--space-7)"
    }
  }, children) : null);
}
Object.assign(__ds_scope, { SectionHeader });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/layout/SectionHeader.jsx", error: String((e && e.message) || e) }); }

// components/navigation/Footer.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Footer({
  columns = [],
  about,
  logoSrc,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("footer", _extends({}, rest, {
    style: {
      background: "var(--surface-inverse)",
      color: "var(--clay-200)",
      paddingTop: "var(--space-13)",
      ...style
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: "var(--container-max)",
      margin: "0 auto",
      padding: "0 var(--gutter)",
      display: "grid",
      gridTemplateColumns: "1.6fr repeat(2, .8fr) 1.2fr",
      gap: "var(--space-11)"
    }
  }, /*#__PURE__*/React.createElement("div", null, logoSrc ? /*#__PURE__*/React.createElement("img", {
    src: logoSrc,
    alt: "GlycoBAR",
    style: {
      height: 54,
      width: "auto",
      filter: "brightness(1.6)"
    }
  }) : /*#__PURE__*/React.createElement("div", {
    style: {
      font: "var(--weight-medium) var(--text-xl)/1 var(--font-display)",
      color: "var(--clay-300)"
    }
  }, "GlycoBAR"), /*#__PURE__*/React.createElement("p", {
    style: {
      marginTop: "var(--space-6)",
      font: "var(--type-small)",
      color: "var(--clay-300)",
      maxWidth: 300
    }
  }, about), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: "var(--space-6)",
      display: "flex",
      gap: "var(--space-5)"
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "linkedin",
    size: 18,
    color: "var(--clay-400)"
  }), /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "mail",
    size: 18,
    color: "var(--clay-400)"
  }), /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "phone",
    size: 18,
    color: "var(--clay-400)"
  }))), columns.map(col => /*#__PURE__*/React.createElement("div", {
    key: col.title
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      font: "var(--type-eyebrow)",
      letterSpacing: "var(--tracking-label)",
      textTransform: "uppercase",
      color: "var(--clay-400)"
    }
  }, col.title), /*#__PURE__*/React.createElement("ul", {
    style: {
      listStyle: "none",
      margin: "var(--space-6) 0 0",
      padding: 0,
      display: "flex",
      flexDirection: "column",
      gap: "var(--space-4)"
    }
  }, col.links.map(l => /*#__PURE__*/React.createElement("li", {
    key: l
  }, /*#__PURE__*/React.createElement("a", {
    href: "#",
    style: {
      font: "var(--type-small)",
      color: "var(--clay-200)",
      borderBottom: 0
    }
  }, l)))))), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      font: "var(--type-eyebrow)",
      letterSpacing: "var(--tracking-label)",
      textTransform: "uppercase",
      color: "var(--clay-400)"
    }
  }, "Newsletter"), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: "var(--space-6)",
      display: "flex",
      flexDirection: "column",
      gap: "var(--space-4)"
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Input, {
    placeholder: "E-mail",
    style: {
      background: "rgba(255,255,255,.06)",
      borderColor: "var(--clay-700)",
      color: "var(--clay-100)"
    }
  }), /*#__PURE__*/React.createElement(__ds_scope.Button, {
    size: "sm",
    variant: "secondary",
    iconRight: "send"
  }, "Envoyer")))), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: "var(--space-12)",
      borderTop: "1px solid var(--clay-800)",
      padding: "var(--space-6) var(--gutter)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: "var(--container-max)",
      margin: "0 auto",
      display: "flex",
      justifyContent: "space-between",
      font: "var(--weight-regular) var(--text-xs)/1.4 var(--font-body)",
      color: "var(--clay-400)"
    }
  }, /*#__PURE__*/React.createElement("span", null, "19 Rue Casimir Julhiet, 38420 Domene, France"), /*#__PURE__*/React.createElement("span", null, "\xA9 GlycoBAR"))));
}
Object.assign(__ds_scope, { Footer });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/Footer.jsx", error: String((e && e.message) || e) }); }

// components/navigation/NavBar.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Pass logoSrc (assets/glycobar-logo.png) from the consuming page; without it
 *  the wordmark is set in display type — never redraw the mark. */
function NavBar({
  items = [],
  active,
  onNavigate,
  logoSrc,
  welcome = "Welcome at GlycoBAR",
  cta = "Contact us",
  onCta,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("header", _extends({}, rest, {
    style: {
      background: "var(--stone-0)",
      borderBottom: "1px solid var(--border-hairline)",
      ...style
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      background: "var(--clay-800)",
      color: "var(--clay-200)",
      font: "var(--weight-regular) var(--text-xs)/1 var(--font-body)",
      letterSpacing: "var(--tracking-wide)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: "var(--container-max)",
      margin: "0 auto",
      padding: "10px var(--gutter)",
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: "var(--space-4)"
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "dna",
    size: 14,
    color: "var(--clay-400)"
  }), welcome), /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: "var(--space-6)"
    }
  }, /*#__PURE__*/React.createElement("a", {
    href: "mailto:contact@glycobar.com",
    style: {
      color: "var(--clay-200)",
      borderBottom: 0,
      display: "inline-flex",
      alignItems: "center",
      gap: 6
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "mail",
    size: 14
  }), "contact@glycobar.com"), /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "linkedin",
    size: 14,
    color: "var(--clay-300)"
  })))), /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: "var(--container-max)",
      margin: "0 auto",
      padding: "var(--space-5) var(--gutter)",
      display: "flex",
      alignItems: "center",
      gap: "var(--space-9)"
    }
  }, /*#__PURE__*/React.createElement("a", {
    href: "#",
    onClick: e => {
      e.preventDefault();
      onNavigate && onNavigate(items[0] && items[0].id);
    },
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: "var(--space-4)",
      borderBottom: 0
    }
  }, logoSrc ? /*#__PURE__*/React.createElement("img", {
    src: logoSrc,
    alt: "GlycoBAR",
    style: {
      height: 46,
      width: "auto",
      display: "block"
    }
  }) : /*#__PURE__*/React.createElement("span", {
    style: {
      font: "var(--weight-medium) var(--text-xl)/1 var(--font-display)",
      color: "var(--clay-600)",
      letterSpacing: "0.01em"
    }
  }, "GlycoBAR")), /*#__PURE__*/React.createElement("nav", {
    style: {
      display: "flex",
      gap: "var(--space-7)",
      marginLeft: "auto"
    }
  }, items.map(it => {
    const on = it.id === active;
    return /*#__PURE__*/React.createElement("a", {
      key: it.id,
      href: "#",
      onClick: e => {
        e.preventDefault();
        onNavigate && onNavigate(it.id);
      },
      style: {
        font: "var(--weight-medium) var(--text-sm)/1 var(--font-body)",
        letterSpacing: "var(--tracking-wide)",
        textTransform: "uppercase",
        color: on ? "var(--clay-800)" : "var(--stone-600)",
        borderBottom: "2px solid " + (on ? "var(--clay-600)" : "transparent"),
        paddingBottom: 4,
        transition: "var(--transition-control)"
      }
    }, it.label);
  })), /*#__PURE__*/React.createElement(__ds_scope.Button, {
    size: "sm",
    variant: "primary",
    onClick: onCta
  }, cta)));
}
Object.assign(__ds_scope, { NavBar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/NavBar.jsx", error: String((e && e.message) || e) }); }

// components/navigation/Tabs.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Tabs({
  items = [],
  active,
  onChange,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({}, rest, {
    role: "tablist",
    style: {
      display: "flex",
      gap: "var(--space-8)",
      borderBottom: "1px solid var(--border-hairline)",
      ...style
    }
  }), items.map(it => {
    const on = it.id === active;
    return /*#__PURE__*/React.createElement("button", {
      key: it.id,
      role: "tab",
      "aria-selected": on,
      onClick: () => onChange && onChange(it.id),
      style: {
        background: "transparent",
        border: 0,
        cursor: "pointer",
        padding: "0 0 var(--space-5)",
        font: "var(--weight-medium) var(--text-sm)/1 var(--font-body)",
        letterSpacing: "var(--tracking-wide)",
        textTransform: "uppercase",
        color: on ? "var(--clay-800)" : "var(--stone-500)",
        boxShadow: on ? "inset 0 -2px 0 var(--clay-600)" : "none",
        transition: "var(--transition-control)"
      }
    }, it.label);
  }));
}
Object.assign(__ds_scope, { Tabs });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/Tabs.jsx", error: String((e && e.message) || e) }); }

// components/science/GlycanSymbol.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** SNFG residue table: shape + fill. Outlines are cacao, never pure black. */
const SNFG = {
  Glc: {
    shape: "circle",
    fill: "var(--snfg-glc)"
  },
  Gal: {
    shape: "circle",
    fill: "var(--snfg-gal)"
  },
  Man: {
    shape: "circle",
    fill: "var(--snfg-man)"
  },
  GlcNAc: {
    shape: "square",
    fill: "var(--snfg-glcnac)"
  },
  GalNAc: {
    shape: "square",
    fill: "var(--snfg-galnac)"
  },
  Fuc: {
    shape: "triangle",
    fill: "var(--snfg-fuc)"
  },
  Neu5Ac: {
    shape: "diamond",
    fill: "var(--snfg-neu5ac)"
  },
  GlcA: {
    shape: "diamond",
    fill: "var(--snfg-glca)"
  },
  Xyl: {
    shape: "star",
    fill: "var(--snfg-xyl)"
  }
};
function shapePath(shape, s) {
  const h = s / 2;
  if (shape === "square") return {
    tag: "rect",
    props: {
      x: -h,
      y: -h,
      width: s,
      height: s
    }
  };
  if (shape === "triangle") return {
    tag: "polygon",
    props: {
      points: [0, -h, h, h, -h, h].join(" ")
    }
  };
  if (shape === "diamond") return {
    tag: "polygon",
    props: {
      points: [0, -h, h, 0, 0, h, -h, 0].join(" ")
    }
  };
  if (shape === "star") {
    const pts = [];
    for (let i = 0; i < 10; i++) {
      const r = i % 2 ? h * 0.45 : h;
      const a = Math.PI / 5 * i - Math.PI / 2;
      pts.push((Math.cos(a) * r).toFixed(2), (Math.sin(a) * r).toFixed(2));
    }
    return {
      tag: "polygon",
      props: {
        points: pts.join(" ")
      }
    };
  }
  return {
    tag: "circle",
    props: {
      r: h
    }
  };
}

/** One residue, drawn at the SVG origin. Use inside <Glycan>, or standalone. */
function GlycanSymbol({
  residue = "Gal",
  size = 22,
  tone = "colour",
  x = 0,
  y = 0,
  title
}) {
  const def = SNFG[residue] || SNFG.Gal;
  const {
    tag,
    props
  } = shapePath(def.shape, size);
  const El = tag;
  return /*#__PURE__*/React.createElement("g", {
    transform: "translate(" + x + "," + y + ")"
  }, title ? /*#__PURE__*/React.createElement("title", null, title || residue) : null, /*#__PURE__*/React.createElement(El, _extends({}, props, {
    fill: tone === "outline" ? "none" : def.fill,
    stroke: tone === "outline" ? "var(--snfg-connector)" : "var(--snfg-stroke)",
    strokeWidth: tone === "outline" ? 1.25 : 1.5,
    vectorEffect: "non-scaling-stroke"
  })));
}
Object.assign(__ds_scope, { SNFG, GlycanSymbol });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/science/GlycanSymbol.jsx", error: String((e && e.message) || e) }); }

// components/science/Glycan.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * SNFG glycan structure. Residues read left to right; the reducing end is the
 * last item, matching how the field draws sequences. A residue may carry a
 * `branch` (an array drawn above it, connected by a vertical link).
 * tone="outline" strips the colours and gives the brand's motif form.
 */
function Glycan({
  residues = [],
  size = 22,
  gap = 34,
  tone = "colour",
  showLinks = true,
  reducingEnd,
  style,
  ...rest
}) {
  const rowH = size + 26;
  const hasBranch = residues.some(r => r.branch && r.branch.length);
  const width = gap * Math.max(residues.length - 1, 0) + size + (reducingEnd ? 64 : 24) + 20;
  const height = hasBranch ? rowH * 2 + 12 : rowH + 8;
  const baseY = hasBranch ? rowH + 12 : rowH / 2 + 4;
  const x0 = size / 2 + 10;
  return /*#__PURE__*/React.createElement("svg", _extends({}, rest, {
    viewBox: "0 0 " + width + " " + height,
    width: "100%",
    height: height,
    style: {
      display: "block",
      overflow: "visible",
      ...style
    },
    role: "img"
  }), residues.map((r, i) => {
    const x = x0 + i * gap;
    const nextX = x0 + (i + 1) * gap;
    return /*#__PURE__*/React.createElement("g", {
      key: i
    }, i < residues.length - 1 ? /*#__PURE__*/React.createElement("line", {
      x1: x + size / 2,
      y1: baseY,
      x2: nextX - size / 2,
      y2: baseY,
      stroke: "var(--snfg-connector)",
      strokeWidth: "1.25"
    }) : null, showLinks && r.link && i < residues.length - 1 ? /*#__PURE__*/React.createElement("text", {
      x: (x + nextX) / 2,
      y: baseY - 8,
      textAnchor: "middle",
      style: {
        font: "var(--weight-regular) 9px/1 var(--font-mono)",
        fill: "var(--snfg-label)"
      }
    }, r.link) : null, r.branch && r.branch.length ? /*#__PURE__*/React.createElement("g", null, /*#__PURE__*/React.createElement("line", {
      x1: x,
      y1: baseY - size / 2,
      x2: x,
      y2: baseY - rowH + size / 2,
      stroke: "var(--snfg-connector)",
      strokeWidth: "1.25"
    }), r.branchLink ? /*#__PURE__*/React.createElement("text", {
      x: x + 7,
      y: baseY - rowH / 2 - 2,
      style: {
        font: "var(--weight-regular) 9px/1 var(--font-mono)",
        fill: "var(--snfg-label)"
      }
    }, r.branchLink) : null, r.branch.map((b, j) => /*#__PURE__*/React.createElement(__ds_scope.GlycanSymbol, {
      key: j,
      residue: b.residue,
      size: size,
      tone: tone,
      x: x - j * gap,
      y: baseY - rowH,
      title: b.residue
    }))) : null, /*#__PURE__*/React.createElement(__ds_scope.GlycanSymbol, {
      residue: r.residue,
      size: size,
      tone: tone,
      x: x,
      y: baseY,
      title: r.residue
    }));
  }), reducingEnd ? /*#__PURE__*/React.createElement("g", null, /*#__PURE__*/React.createElement("line", {
    x1: x0 + (residues.length - 1) * gap + size / 2,
    y1: baseY,
    x2: x0 + (residues.length - 1) * gap + size / 2 + 18,
    y2: baseY,
    stroke: "var(--snfg-connector)",
    strokeWidth: "1.25",
    strokeDasharray: "3 3"
  }), /*#__PURE__*/React.createElement("text", {
    x: x0 + (residues.length - 1) * gap + size / 2 + 24,
    y: baseY + 4,
    style: {
      font: "var(--weight-regular) 11px/1 var(--font-mono)",
      fill: "var(--text-muted)"
    }
  }, reducingEnd)) : null);
}

/** The two GlycoBAR core products, as SNFG. */
const GLYCOBAR_A = [{
  residue: "GalNAc",
  link: "α1-3",
  branch: [{
    residue: "Fuc"
  }],
  branchLink: "α1-2"
}, {
  residue: "Gal",
  link: "β1-4"
}, {
  residue: "GlcNAc"
}];
const GLYCOBAR_B = [{
  residue: "Gal",
  link: "α1-3",
  branch: [{
    residue: "Fuc"
  }],
  branchLink: "α1-2"
}, {
  residue: "Gal",
  link: "β1-4"
}, {
  residue: "GlcNAc"
}];
Object.assign(__ds_scope, { Glycan, GLYCOBAR_A, GLYCOBAR_B });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/science/Glycan.jsx", error: String((e && e.message) || e) }); }

// components/science/GlycanTrail.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * The motif form of SNFG: an outlined residue trail used as a rule, a section
 * divider or a milestone track. Carries no scientific claim — geometry only,
 * which is why it is always tone="outline" and never coloured.
 */
function GlycanTrail({
  shapes = ["circle", "square", "circle", "diamond"],
  size = 14,
  gap = 28,
  active = -1,
  labels,
  vertical = false,
  style,
  ...rest
}) {
  const RES = {
    circle: "Glc",
    square: "GlcNAc",
    triangle: "Fuc",
    diamond: "Neu5Ac"
  };
  const n = shapes.length;
  const len = gap * (n - 1) + size + 4;
  const w = vertical ? size + 4 : len;
  const h = vertical ? len : size + (labels ? 24 : 4);
  return /*#__PURE__*/React.createElement("svg", _extends({}, rest, {
    viewBox: "0 0 " + w + " " + h,
    width: vertical ? size + 4 : "100%",
    height: h,
    style: {
      display: "block",
      overflow: "visible",
      ...style
    },
    "aria-hidden": "true"
  }), shapes.map((s, i) => {
    const c = size / 2 + 2 + i * gap;
    const x = vertical ? size / 2 + 2 : c;
    const y = vertical ? c : size / 2 + 2;
    const nx = vertical ? x : size / 2 + 2 + (i + 1) * gap;
    const ny = vertical ? size / 2 + 2 + (i + 1) * gap : y;
    return /*#__PURE__*/React.createElement("g", {
      key: i
    }, i < n - 1 ? /*#__PURE__*/React.createElement("line", {
      x1: vertical ? x : x + size / 2,
      y1: vertical ? y + size / 2 : y,
      x2: vertical ? nx : nx - size / 2,
      y2: vertical ? ny - size / 2 : ny,
      stroke: "var(--snfg-connector)",
      strokeWidth: "1.25",
      opacity: i < active ? 1 : 0.4
    }) : null, /*#__PURE__*/React.createElement("g", {
      opacity: active < 0 || i <= active ? 1 : 0.4
    }, /*#__PURE__*/React.createElement(__ds_scope.GlycanSymbol, {
      residue: RES[s] || "Glc",
      size: size,
      tone: i === active ? "colour" : "outline",
      x: x,
      y: y
    })), labels && labels[i] ? /*#__PURE__*/React.createElement("text", {
      x: x,
      y: size + 18,
      textAnchor: "middle",
      style: {
        font: "var(--weight-medium) 9px/1 var(--font-body)",
        letterSpacing: ".1em",
        textTransform: "uppercase",
        fill: i <= active ? "var(--brand)" : "var(--text-faint)"
      }
    }, labels[i]) : null);
  }));
}
Object.assign(__ds_scope, { GlycanTrail });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/science/GlycanTrail.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/About.jsx
try { (() => {
function About({
  onQuote
}) {
  const team = [{
    n: "Henri SORS",
    r: "“The Seasoned Entrepreneur”",
    d: "He is the co-founder and CEO. Background of EE engineering + MBA. 25 years with Hewlett-Packard."
  }, {
    n: "Bernard MANDRAND",
    r: "“The Idea Wrangler”",
    d: "He is co-founder and scientific manager; 33 years at bioMerieux and 7 years at Lyonbiopole head of research programs."
  }, {
    n: "Vivien DELOULE",
    r: "“The multitasking specialist”",
    d: "He is the operations manager. Engineering degree and Ph. Balances lab logistics, supply chain nightmares, and frantic grant deadlines without breaking a sweat."
  }, {
    n: "Ludovic BASTIDE",
    r: "“The Bacteria Whisperer”",
    d: "He is the technical manager. PhD in microbiology. Transforms biology madness into structured workflows while keeping everyone (mostly) sane."
  }, {
    n: "Jacqueline HUET",
    r: "“The Compliance Gatekeeper”",
    d: "She is our quality manager."
  }, {
    n: "David CUCCOLO",
    r: "“The Human Calculator”",
    d: "He is our financial manager. Speaks fluent Excel, sees the future in cash flow, and ensures the company doesn't go broke."
  }];
  return /*#__PURE__*/React.createElement("main", null, /*#__PURE__*/React.createElement("section", {
    className: "gb-sect"
  }, /*#__PURE__*/React.createElement(Container, null, /*#__PURE__*/React.createElement("div", {
    className: "gb-grid-2",
    style: {
      alignItems: "start"
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(SectionHeader, {
    eyebrow: "About Us",
    title: "Our vision"
  }), /*#__PURE__*/React.createElement("p", {
    style: {
      marginTop: "var(--space-8)",
      font: "var(--weight-medium) var(--text-2xl)/1.3 var(--font-display)",
      color: "var(--brand)"
    }
  }, "A world with no blood group antibodies !"), /*#__PURE__*/React.createElement("p", {
    style: {
      marginTop: "var(--space-7)",
      font: "var(--type-body)",
      color: "var(--text-body)"
    }
  }, "Blood barriers have protected individuals from potentially pathogenic exogenous organisms for thousands of years, but today they greatly complicate our modern health system where products are shared between individuals."), /*#__PURE__*/React.createElement("p", {
    style: {
      marginTop: "var(--space-6)",
      font: "var(--weight-regular) var(--text-md)/1.6 var(--font-body)",
      fontStyle: "italic",
      color: "var(--text-heading)"
    }
  }, "The future of health involves the elimination of blood groups."), /*#__PURE__*/React.createElement(DiamondBullets, {
    style: {
      marginTop: "var(--space-8)"
    },
    items: ["Plasma can be transfused regardless of donor and recipient respective blood group thanks to generalized universal plasma", "The issue of short-lived platelets is highly simplified because there is only one type of platelets: universal platelets", "Organ transplants can be done irrespective of donors & recipients blood group", "IVIG market is become much safer because those plasma derivative products do not contain isoagglutinins any more"]
  })), /*#__PURE__*/React.createElement(Figure, {
    caption: "wp-content/uploads/2025/03/DALL\xB7E-2025-03-03-scientist-holographic-projection.webp (asset not available)",
    height: 460
  })))), /*#__PURE__*/React.createElement("section", {
    className: "gb-sect-tight",
    style: {
      background: "var(--surface-alt)"
    }
  }, /*#__PURE__*/React.createElement(Container, null, /*#__PURE__*/React.createElement(SectionHeader, {
    eyebrow: "Our Team",
    title: "Six people, one barrier to remove",
    maxWidth: 640
  }), /*#__PURE__*/React.createElement("div", {
    className: "gb-grid-3",
    style: {
      marginTop: "var(--space-10)"
    }
  }, team.map(m => /*#__PURE__*/React.createElement(Card, {
    key: m.n
  }, /*#__PURE__*/React.createElement(Figure, {
    caption: "portrait (asset not available)",
    height: 180
  }), /*#__PURE__*/React.createElement("h3", {
    style: {
      marginTop: "var(--space-6)",
      font: "var(--type-h3)"
    }
  }, m.n), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: "var(--space-3)",
      font: "var(--type-small)",
      color: "var(--brand)"
    }
  }, m.r), /*#__PURE__*/React.createElement("p", {
    style: {
      marginTop: "var(--space-5)",
      font: "var(--type-small)",
      color: "var(--text-body)"
    }
  }, m.d)))))), /*#__PURE__*/React.createElement(MediaSection, {
    image: PLANT,
    imageAlt: "GlycoBAR site in Dom\xE8ne"
  }, /*#__PURE__*/React.createElement(SectionHeader, {
    eyebrow: "Our History",
    title: "We created GlycoBAR in 2015, in the heart of one of the biggest glycoscience clusters in the world, Grenoble in France.",
    lead: "Nourished by the ecosystem of innovation where world-class research laboratories rub shoulders with cutting-edge industries in medical technologies, nanotechnologies, semiconductors and life sciences."
  }, /*#__PURE__*/React.createElement("p", {
    style: {
      font: "var(--type-body)",
      color: "var(--text-body)"
    }
  }, "GlycoBAR is growing to become a leader in glycoscience serving human health."))), /*#__PURE__*/React.createElement(ContactBand, {
    onQuote: onQuote
  }));
}
window.About = About;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/About.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/Home.jsx
try { (() => {
function Home({
  onQuote,
  onNavigate
}) {
  const steps = [{
    t: "Selection and Cultivation of Bacteria",
    d: "The biofermentation process begins with the design of appropriate bacterial strains..."
  }, {
    t: "Regulation and Optimization",
    d: "The biofermentation process is closely monitored and regulated to ensure optimal glycan production..."
  }, {
    t: "Harvesting and Purification",
    d: "After a period of biofermentation, during which the bacteria have produced the desired glycans..."
  }];
  const cards = [{
    eyebrow: "Impacts",
    title: "Leading innovation",
    body: "By leading innovation to expand access to life-saving medical products and support the work of healthcare professionals, GlycoBAR contributes to the achievement of the United Nations Sustainable Development Goals (SDGs).",
    link: "Read More",
    to: "impacts"
  }, {
    eyebrow: "Biofermentation process",
    title: "GlycoBAR production process",
    body: "Our proprietary biofermentation process sets us apart. By harnessing the natural capabilities of bacteria used as cell factories, we produce highly specific blood group antigen ligands...",
    link: "Read More",
    to: "process"
  }, {
    eyebrow: "Blood antigens market",
    title: "Universal plasma",
    body: "Thanks to the availability of GlycoBAR low-cost antigen ligands, universal plasma will shortly become a reality. Our blood group antigen ligands grafted on a cellulosic support (we have a proof of concept for this)",
    link: "Read More",
    to: "markets"
  }];
  return /*#__PURE__*/React.createElement("main", null, /*#__PURE__*/React.createElement(PageHero, {
    eyebrow: "Innovative",
    title: "Blood goup antigens ligands for an ABO antibody-free World",
    lead: "Glycosciences serving medical innovation. Glycans, such as antigens, are omnipresent in biology and their control is essential to maintain and improve human health\u2026",
    image: PLANT,
    imageAlt: "GlycoBAR production plant, Dom\xE8ne",
    height: 520
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "inverse",
    iconRight: "arrow-right",
    onClick: () => onNavigate("about")
  }, "Discover More")), /*#__PURE__*/React.createElement("section", {
    className: "gb-sect"
  }, /*#__PURE__*/React.createElement(Container, null, /*#__PURE__*/React.createElement("div", {
    className: "gb-grid-3"
  }, cards.map(c => /*#__PURE__*/React.createElement(Card, {
    key: c.title,
    interactive: true,
    padding: "var(--card-pad-lg)",
    onClick: () => onNavigate(c.to)
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      font: "var(--type-eyebrow)",
      letterSpacing: "var(--tracking-label)",
      textTransform: "uppercase",
      color: "var(--brand)"
    }
  }, c.eyebrow), /*#__PURE__*/React.createElement("h3", {
    style: {
      marginTop: "var(--space-5)",
      font: "var(--type-h3)"
    }
  }, c.title), /*#__PURE__*/React.createElement("p", {
    style: {
      marginTop: "var(--space-6)",
      font: "var(--type-small)",
      color: "var(--text-body)"
    }
  }, c.body), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: "var(--space-7)",
      display: "inline-flex",
      alignItems: "center",
      gap: "var(--space-4)",
      font: "var(--weight-medium) var(--text-sm)/1 var(--font-body)",
      letterSpacing: "var(--tracking-wide)",
      textTransform: "uppercase",
      color: "var(--brand)"
    }
  }, c.link, /*#__PURE__*/React.createElement(Icon, {
    name: "arrow-right",
    size: 15
  }))))))), /*#__PURE__*/React.createElement(MediaSection, {
    image: PLANT,
    imageAlt: "GlycoBAR industrial demonstrator",
    tone: "alt",
    reverse: true
  }, /*#__PURE__*/React.createElement(SectionHeader, {
    eyebrow: "About GlycoBar",
    title: "Essential or even vital health products should be accessible for everybody",
    lead: "Transforming this idea into a reality stirs us up every day and drives us to develop a technology to make antigens ligands economically compatible with the blood market. Our ligands are the most affordable ones on the market \u2013 by far, with uncompromised quality. For the first time, universal blood components have become economically viable!"
  }, /*#__PURE__*/React.createElement("p", {
    style: {
      font: "var(--type-body)",
      color: "var(--text-body)"
    }
  }, "Second major advantage, GlycoBAR's technology enables scalable production capacity to meet global needs. Come and see our industrial demonstrator which already supplies international customers."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: "var(--space-11)",
      margin: "var(--space-9) 0"
    }
  }, /*#__PURE__*/React.createElement(Stat, {
    value: "220",
    unit: "m\xB2",
    label: "Production floor"
  }), /*#__PURE__*/React.createElement(Stat, {
    value: "2015",
    label: "Founded in Grenoble"
  })), /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    iconRight: "arrow-right",
    onClick: () => onNavigate("about")
  }, "More About"))), /*#__PURE__*/React.createElement("section", {
    className: "gb-sect"
  }, /*#__PURE__*/React.createElement(Container, null, /*#__PURE__*/React.createElement(SectionHeader, {
    eyebrow: "Process",
    title: "We follow some easy steps to develop Our Project",
    align: "center",
    maxWidth: 820,
    lead: "Optimization of hospitals logistics, simplification of caregivers' tasks, improvement of the safety of medical and pharmaceutical products, and above all, innovative and better-quality treatments for patients; the benefits are countless, let's discover them!"
  }), /*#__PURE__*/React.createElement(GlycanTrail, {
    style: {
      margin: "var(--space-11) auto 0",
      maxWidth: 820
    },
    size: 18,
    gap: 260,
    active: 1,
    shapes: ["square", "circle", "circle", "diamond"],
    labels: ["Strain design", "Fermentation", "Purification", "Release"]
  }), /*#__PURE__*/React.createElement("div", {
    className: "gb-grid-3",
    style: {
      marginTop: "var(--space-9)"
    }
  }, steps.map((s, i) => /*#__PURE__*/React.createElement(Card, {
    key: s.t,
    padding: "var(--card-pad-lg)"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: "var(--space-5)"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 34,
      height: 34,
      background: "var(--clay-100)",
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      transform: "rotate(45deg)"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      transform: "rotate(-45deg)",
      font: "var(--type-mono)",
      color: "var(--clay-700)"
    }
  }, i + 1)), /*#__PURE__*/React.createElement(Badge, {
    tone: "neutral"
  }, "Step ", i + 1)), /*#__PURE__*/React.createElement("h3", {
    style: {
      marginTop: "var(--space-7)",
      font: "var(--type-h3)"
    }
  }, s.t), /*#__PURE__*/React.createElement("p", {
    style: {
      marginTop: "var(--space-5)",
      font: "var(--type-small)",
      color: "var(--text-body)"
    }
  }, s.d)))))), /*#__PURE__*/React.createElement("section", {
    className: "gb-sect",
    style: {
      background: "var(--surface-inverse)"
    }
  }, /*#__PURE__*/React.createElement(Container, null, /*#__PURE__*/React.createElement("div", {
    className: "gb-grid-2",
    style: {
      alignItems: "center"
    }
  }, /*#__PURE__*/React.createElement(SectionHeader, {
    tone: "inverse",
    eyebrow: "Why Choose Us?",
    title: "How do we revolutionize blood and plasma therapies?",
    lead: "Through our unique bio fermentation technology which produces antigen ligands to remove blood group antibodies from plasma."
  }, /*#__PURE__*/React.createElement("p", {
    style: {
      font: "var(--weight-medium) var(--text-lg)/1.5 var(--font-body)",
      color: "#fff",
      marginBottom: "var(--space-8)"
    }
  }, "Our vision? No more blood group barrier thanks to a world free of blood group antibodies."), /*#__PURE__*/React.createElement("ul", {
    style: {
      listStyle: "none",
      margin: 0,
      padding: 0,
      display: "flex",
      flexDirection: "column",
      gap: "var(--space-5)"
    }
  }, ["Universal plasma", "Universal platelets", "Organ transplants over the blood group barrier", "New and safer IVIG"].map(t => /*#__PURE__*/React.createElement("li", {
    key: t,
    style: {
      display: "flex",
      gap: "var(--space-5)",
      alignItems: "center"
    }
  }, /*#__PURE__*/React.createElement("svg", {
    width: "12",
    height: "12",
    viewBox: "0 0 12 12",
    "aria-hidden": "true"
  }, /*#__PURE__*/React.createElement("circle", {
    cx: "6",
    cy: "6",
    r: "5",
    fill: "none",
    stroke: "var(--clay-400)",
    strokeWidth: "1.25"
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      font: "var(--type-body)",
      color: "var(--clay-100)"
    }
  }, t))))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: "var(--space-8)"
    }
  }, [{
    n: "Blood group A tetraose",
    r: GLYCOBAR_A
  }, {
    n: "Blood group B tetraose",
    r: GLYCOBAR_B
  }].map(g => /*#__PURE__*/React.createElement("div", {
    key: g.n,
    style: {
      padding: "var(--space-8)",
      border: "1px solid var(--clay-800)",
      borderRadius: "var(--radius-card)",
      background: "rgba(255,255,255,.04)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      font: "var(--type-eyebrow)",
      letterSpacing: "var(--tracking-label)",
      textTransform: "uppercase",
      color: "var(--clay-400)",
      marginBottom: "var(--space-6)"
    }
  }, g.n), /*#__PURE__*/React.createElement(Glycan, {
    residues: g.r,
    reducingEnd: "NH\u2082"
  }))))))), /*#__PURE__*/React.createElement(ContactBand, {
    onQuote: onQuote
  }));
}
window.Home = Home;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/Home.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/Markets.jsx
try { (() => {
function Markets({
  onQuote
}) {
  const [market, setMarket] = React.useState("plasma");
  const benefits = [{
    t: "Streamlined Inventory Management",
    d: "Hospitals and blood banks can maintain a single type of plasma, reducing the complexity and costs associated with storing multiple blood group plasmas."
  }, {
    t: "Immediate Availability",
    d: "In emergencies, universal plasma can be readily available for transfusions without the need for blood type matching, speeding up treatment and potentially saving lives."
  }, {
    t: "Reduced Risk of Transfusion Reactions",
    d: "By removing blood group antibodies, universal plasma minimizes the risk of hemolytic reactions, enhancing patient safety."
  }, {
    t: "Increased Efficiency",
    d: "Simplifying the transfusion process allows healthcare providers to focus more on patient care and less on logistical challenges."
  }];
  const tabs = [{
    id: "plasma",
    label: "Universal plasma"
  }, {
    id: "platelets",
    label: "Universal platelets"
  }, {
    id: "organs",
    label: "Organ transplants"
  }, {
    id: "ivig",
    label: "IVIG purification"
  }];
  return /*#__PURE__*/React.createElement("main", null, /*#__PURE__*/React.createElement("section", {
    className: "gb-sect-tight"
  }, /*#__PURE__*/React.createElement(Container, null, /*#__PURE__*/React.createElement(SectionHeader, {
    eyebrow: "Blood Antigens Markets",
    title: "Four markets, one mechanism",
    maxWidth: 700,
    lead: "Removing blood group antibodies simplifies every product that is shared between individuals."
  }), /*#__PURE__*/React.createElement(Tabs, {
    style: {
      marginTop: "var(--space-9)"
    },
    active: market,
    onChange: setMarket,
    items: tabs
  }), market === "plasma" ? /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: "var(--space-10)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "gb-grid-2",
    style: {
      alignItems: "start"
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h2", {
    style: {
      font: "var(--type-h2)"
    }
  }, "Universal Plasma"), /*#__PURE__*/React.createElement("p", {
    style: {
      marginTop: "var(--space-6)",
      font: "var(--type-lead)",
      fontStyle: "italic",
      color: "var(--text-body)"
    }
  }, "Thanks to the availability of GlycoBAR low-cost antigen ligands, universal plasma will shortly become a reality."), /*#__PURE__*/React.createElement("p", {
    style: {
      marginTop: "var(--space-6)",
      font: "var(--type-body)",
      color: "var(--text-body)"
    }
  }, "Our blood group antigen ligands grafted on a cellulosic support (we have a proof of concept for this) are forming an affordable solution that can be used either in an individual plasma bag to make it universal or on plasma pools."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: "var(--space-11)",
      marginTop: "var(--space-9)"
    }
  }, /*#__PURE__*/React.createElement(Stat, {
    value: "1",
    label: "Plasma inventory to manage"
  }), /*#__PURE__*/React.createElement(Stat, {
    value: "AB",
    label: "Equivalent plasma grade"
  }))), /*#__PURE__*/React.createElement(Figure, {
    caption: "wp-content/uploads/2025/02/3.jpg \u2014 plasma bags (asset not available)",
    height: 320
  })), /*#__PURE__*/React.createElement("div", {
    className: "gb-grid-2",
    style: {
      marginTop: "var(--space-11)"
    }
  }, benefits.map(b => /*#__PURE__*/React.createElement(Card, {
    key: b.t,
    padding: "var(--card-pad-lg)"
  }, /*#__PURE__*/React.createElement(Badge, {
    tone: "universal"
  }, "Benefit"), /*#__PURE__*/React.createElement("h3", {
    style: {
      marginTop: "var(--space-5)",
      font: "var(--type-h3)"
    }
  }, b.t), /*#__PURE__*/React.createElement("p", {
    style: {
      marginTop: "var(--space-5)",
      font: "var(--type-small)",
      color: "var(--text-body)"
    }
  }, b.d)))), /*#__PURE__*/React.createElement(Callout, {
    tone: "note",
    style: {
      marginTop: "var(--space-9)"
    }
  }, "These improvements can lead to better resource allocation, reduced waste, and overall enhanced efficiency in medical facilities.")) : null, market === "platelets" ? /*#__PURE__*/React.createElement("div", {
    className: "gb-grid-2",
    style: {
      marginTop: "var(--space-10)",
      alignItems: "center"
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h2", {
    style: {
      font: "var(--type-h2)"
    }
  }, "Universal Platelets"), /*#__PURE__*/React.createElement(DiamondBullets, {
    style: {
      marginTop: "var(--space-7)"
    },
    items: ["The same benefits apply to platelets to an even greater extent.", "Platelets are very short-lived blood components, lasting only a few days.", "Being able to manage a single inventory of platelets would bring significant benefits to the health system."]
  })), /*#__PURE__*/React.createElement(Figure, {
    caption: "wp-content/uploads/2025/02/1.jpg \u2014 platelet unit (asset not available)",
    height: 300
  })) : null, market === "organs" ? /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: "var(--space-10)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "gb-grid-2",
    style: {
      alignItems: "start"
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h2", {
    style: {
      font: "var(--type-h2)"
    }
  }, "Organ Transplants"), /*#__PURE__*/React.createElement("p", {
    style: {
      marginTop: "var(--space-6)",
      font: "var(--type-lead)",
      fontStyle: "italic",
      color: "var(--text-body)"
    }
  }, "A recipient can accept only transplanted organs compatible with his ABO blood group otherwise his ABO antibodies will kill the transplanted organ."), /*#__PURE__*/React.createElement("p", {
    style: {
      marginTop: "var(--space-6)",
      font: "var(--type-body)",
      color: "var(--text-body)"
    }
  }, "As a result of the limited donors-recipient compatibility matrix, there is currently a huge shortage of available organs for transplant. Blood group mismatch is a big issue and therefore providing a product allowing to resolve that issue is utmost important for saving lives.")), /*#__PURE__*/React.createElement(Figure, {
    caption: "wp-content/uploads/2025/03/19.jpg \u2014 transplant surgery (asset not available)",
    height: 280
  })), /*#__PURE__*/React.createElement("h3", {
    style: {
      marginTop: "var(--space-11)",
      font: "var(--type-h3)"
    }
  }, "Solution"), /*#__PURE__*/React.createElement("p", {
    style: {
      marginTop: "var(--space-5)",
      font: "var(--type-body)",
      fontStyle: "italic",
      color: "var(--text-body)",
      maxWidth: 860
    }
  }, "GlycoBAR partners develop extra corporal devices that filter the recipient blood so that blood group antibodies are eliminated from plasma."), /*#__PURE__*/React.createElement(GlycanTrail, {
    style: {
      margin: "var(--space-9) auto var(--space-8)",
      maxWidth: 760
    },
    size: 16,
    gap: 340,
    active: 2,
    shapes: ["circle", "square", "diamond"],
    labels: ["Plasmapheresis", "Ligand filtration", "Reinjection"]
  }), /*#__PURE__*/React.createElement("div", {
    className: "gb-grid-3"
  }, ["The recipient patient's blood is derived in an external circuitry where it is centrifugated with a plasmapheresis machine.", "The plasma is purified from blood group antibodies thanks to a proprietary medical device using GlycoBAR ligands and all the blood components are then reinjected in the patient's blood system.", "After a few days of this treatment, the patient is ready to receive an organ of any blood group."].map((s, i) => /*#__PURE__*/React.createElement(Card, {
    key: i,
    tone: "tint",
    padding: "var(--card-pad-lg)"
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: "var(--type-mono)",
      color: "var(--brand)"
    }
  }, "0", i + 1), /*#__PURE__*/React.createElement("p", {
    style: {
      marginTop: "var(--space-5)",
      font: "var(--type-small)",
      color: "var(--text-body)"
    }
  }, s))))) : null, market === "ivig" ? /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: "var(--space-10)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "gb-grid-2",
    style: {
      alignItems: "start"
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h2", {
    style: {
      font: "var(--type-h2)"
    }
  }, "IVIG Purification"), /*#__PURE__*/React.createElement("p", {
    style: {
      marginTop: "var(--space-6)",
      font: "var(--type-body)",
      color: "var(--text-body)"
    }
  }, "The plasma fractionation industry producing so called IVIG products (Intra Venous Immunoglobulin type G) is facing a serious challenge: as of today, for obvious logistic reasons and also because IgG blood group antibodies are not highly hemolytic, the plasma used in fractionation factories is not grouped (this is a mix of plasma of all groups). Consequently, IVIG products contain isoagglutinins."), /*#__PURE__*/React.createElement(Callout, {
    tone: "danger",
    title: "FDA, 2015",
    style: {
      marginTop: "var(--space-7)"
    }
  }, "The FDA raised concerns about this issue and encouraged IVIG suppliers to remove isoagglutinins from their products. However, due to the high cost and production challenges of blood group antigen ligands at the time, few suppliers complied with these recommendations.")), /*#__PURE__*/React.createElement(Figure, {
    caption: "wp-content/uploads/2025/03/pediatric-doctor\u2026jpg \u2014 paediatric care (asset not available)",
    height: 300
  })), /*#__PURE__*/React.createElement("h3", {
    style: {
      marginTop: "var(--space-11)",
      font: "var(--type-h3)"
    }
  }, "There are two ways to remove isoagglutinins from IVIG"), /*#__PURE__*/React.createElement("div", {
    className: "gb-grid-2",
    style: {
      marginTop: "var(--space-8)"
    }
  }, /*#__PURE__*/React.createElement(Card, {
    padding: "var(--card-pad-lg)"
  }, /*#__PURE__*/React.createElement(Badge, {
    tone: "brand"
  }, "Route one"), /*#__PURE__*/React.createElement("h3", {
    style: {
      marginTop: "var(--space-5)",
      font: "var(--type-h3)"
    }
  }, "Chromatographic column with a GlycoBAR-grafted resin"), /*#__PURE__*/React.createElement("p", {
    style: {
      marginTop: "var(--space-5)",
      font: "var(--type-small)",
      color: "var(--text-body)"
    }
  }, "By adding a very simple and well-known affinity purification step in their IVIG production process, IVIG suppliers can now eliminate completely isoagglutinins from their products. GlycoBAR has a partnership with a leading chromatographic resin supplier which is taking care of the grafting process and offers a turn-key solution.")), /*#__PURE__*/React.createElement(Card, {
    padding: "var(--card-pad-lg)"
  }, /*#__PURE__*/React.createElement(Badge, {
    tone: "brand"
  }, "Route two"), /*#__PURE__*/React.createElement("h3", {
    style: {
      marginTop: "var(--space-5)",
      font: "var(--type-h3)"
    }
  }, "Low-cost antibody titer measurement"), /*#__PURE__*/React.createElement("p", {
    style: {
      marginTop: "var(--space-5)",
      font: "var(--type-small)",
      color: "var(--text-body)"
    }
  }, "GlycoBAR is developing a low-cost device aimed at measuring the antibody titer of each plasma bag, both IgG and IgM, A and B. Fully compatible with any Elisa plate reader, it will flag any high titer plasma, which can then be rerouted to an antibody removal step using a filter GlycoBAR can provide through one of its partners.")))) : null)), /*#__PURE__*/React.createElement(ContactBand, {
    onQuote: onQuote
  }));
}
window.Markets = Markets;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/Markets.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/Products.jsx
try { (() => {
function Products({
  onQuote
}) {
  const [tab, setTab] = React.useState("core");
  const [selected, setSelected] = React.useState("A tetraose");
  const groups = [{
    g: "A",
    tone: "a",
    antigen: "Antigen A only",
    plasma: "anti-B antibodies"
  }, {
    g: "B",
    tone: "b",
    antigen: "Antigen B only",
    plasma: "anti-A antibodies"
  }, {
    g: "AB",
    tone: "universal",
    antigen: "Antigens A and B",
    plasma: "neither anti-A nor anti-B"
  }, {
    g: "O",
    tone: "neutral",
    antigen: "Neither antigen",
    plasma: "both anti-A and anti-B"
  }];
  const others = ["Blood group A tri-saccharide antigen", "Blood group B tri-saccharide antigen", "Blood group A hexa-saccharide antigen (bare sugar version; amine termination also available)", "Blood group B hexa-saccharide antigen (bare sugar version; amine termination also available)"];
  return /*#__PURE__*/React.createElement("main", null, /*#__PURE__*/React.createElement("section", {
    className: "gb-sect-tight"
  }, /*#__PURE__*/React.createElement(Container, null, /*#__PURE__*/React.createElement(SectionHeader, {
    eyebrow: "Commercial Antigens Products",
    title: "Introduction to blood group antigens",
    lead: "Human red blood cells are covered with blood group antigens.",
    maxWidth: 760
  }), /*#__PURE__*/React.createElement("div", {
    className: "gb-grid-2",
    style: {
      marginTop: "var(--space-10)",
      alignItems: "start"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: "var(--space-5)"
    }
  }, groups.map(g => /*#__PURE__*/React.createElement(Card, {
    key: g.g,
    style: {
      display: "flex",
      alignItems: "center",
      gap: "var(--space-7)"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: "var(--weight-medium) var(--text-2xl)/1 var(--font-display)",
      color: "var(--text-heading)",
      width: 44
    }
  }, g.g), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      font: "var(--type-label)",
      color: "var(--text-heading)"
    }
  }, g.antigen), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: "var(--space-2)",
      font: "var(--type-small)",
      color: "var(--text-muted)"
    }
  }, "Plasma contains ", g.plasma)), /*#__PURE__*/React.createElement(Badge, {
    tone: g.tone
  }, "Group ", g.g))), /*#__PURE__*/React.createElement(Callout, {
    tone: "warning",
    title: "Hemolysis"
  }, "If plasma containing specific antibodies contacts red blood cells with the corresponding antigens, it can destroy the red blood cells, potentially triggering hemolysis."), /*#__PURE__*/React.createElement(Callout, {
    tone: "info",
    title: "Universal blood components"
  }, "With universal blood components, blood group antibodies are removed, allowing safe mixing of any blood components, regardless of the donor's and recipient's blood groups.")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: "var(--space-7)"
    }
  }, /*#__PURE__*/React.createElement(Figure, {
    caption: "wp-content/uploads/2025/03/iStock-2135107973-1.jpg \u2014 the four blood groups (asset not available)",
    height: 300
  }), /*#__PURE__*/React.createElement(Figure, {
    caption: "wp-content/uploads/2025/02/Image16.png \u2014 antibodies present in plasma (asset not available)",
    height: 200
  }))))), /*#__PURE__*/React.createElement("section", {
    className: "gb-sect-tight",
    style: {
      background: "var(--surface-alt)"
    }
  }, /*#__PURE__*/React.createElement(Container, null, /*#__PURE__*/React.createElement(SectionHeader, {
    eyebrow: "Core products",
    title: "A and B Blood group antigens tetraose sugars",
    lead: "Those are the core products proposed by GlycoBAR. The standard form is with an amine termination and a linker arm giving to the molecule approximately the same length as the hexa-saccharide blood group antigen sugars corresponding to the natural antigens attached to erythrocytes.",
    maxWidth: 860
  }), /*#__PURE__*/React.createElement(Tabs, {
    style: {
      marginTop: "var(--space-9)"
    },
    active: tab,
    onChange: setTab,
    items: [{
      id: "core",
      label: "Core tetraoses"
    }, {
      id: "other",
      label: "Other blood group sugars"
    }]
  }), tab === "core" ? /*#__PURE__*/React.createElement("div", {
    className: "gb-grid-2",
    style: {
      marginTop: "var(--space-9)"
    }
  }, [{
    n: "Blood Group A antigen ligand",
    tone: "a",
    f: "GalNAc(α1-3)[Fuc(α1-2)]Gal(β1-4)GlcNAc-NH₂"
  }, {
    n: "Blood Group B antigen ligand",
    tone: "b",
    f: "Gal(α1-3)[Fuc(α1-2)]Gal(β1-4)GlcNAc-NH₂"
  }].map(p => /*#__PURE__*/React.createElement(Card, {
    key: p.n,
    padding: "var(--card-pad-lg)",
    interactive: true,
    onClick: () => setSelected(p.n)
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center"
    }
  }, /*#__PURE__*/React.createElement(Badge, {
    tone: p.tone
  }, p.tone === "a" ? "Antigen A" : "Antigen B"), /*#__PURE__*/React.createElement(Tooltip, {
    label: "Tetrasaccharide with amine termination and linker arm"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "info",
    size: 17,
    color: "var(--text-muted)"
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: "var(--space-7)",
      padding: "var(--space-7) var(--space-5)",
      background: "var(--surface-page)",
      border: "1px solid var(--border-hairline)",
      borderRadius: "var(--radius-image)"
    }
  }, /*#__PURE__*/React.createElement(Glycan, {
    residues: p.tone === "a" ? GLYCOBAR_A : GLYCOBAR_B,
    reducingEnd: "NH\u2082 linker arm"
  })), /*#__PURE__*/React.createElement("h3", {
    style: {
      marginTop: "var(--space-7)",
      font: "var(--type-h3)"
    }
  }, p.n), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: "var(--space-4)",
      font: "var(--type-mono)",
      color: "var(--text-muted)"
    }
  }, p.f), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: "var(--space-7)",
      display: "flex",
      gap: "var(--space-5)"
    }
  }, /*#__PURE__*/React.createElement(Button, {
    size: "sm",
    onClick: onQuote
  }, "Request a quote"), /*#__PURE__*/React.createElement(Button, {
    size: "sm",
    variant: "ghost",
    iconLeft: "download"
  }, "Datasheet"))))) : /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: "var(--space-9)",
      display: "flex",
      flexDirection: "column",
      gap: "var(--space-5)"
    }
  }, /*#__PURE__*/React.createElement("p", {
    style: {
      font: "var(--type-body)",
      color: "var(--text-body)"
    }
  }, "GlycoBAR is also able to propose a lot of other blood group antigen sugars."), others.map(o => /*#__PURE__*/React.createElement(Card, {
    key: o,
    style: {
      display: "flex",
      alignItems: "center",
      gap: "var(--space-7)"
    }
  }, /*#__PURE__*/React.createElement("svg", {
    width: "12",
    height: "12",
    viewBox: "0 0 12 12",
    style: {
      flex: "0 0 auto"
    },
    "aria-hidden": "true"
  }, /*#__PURE__*/React.createElement("rect", {
    x: "1",
    y: "1",
    width: "10",
    height: "10",
    fill: "none",
    stroke: "var(--snfg-connector)",
    strokeWidth: "1.25"
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1,
      font: "var(--type-body)",
      color: "var(--text-body)",
      fontStyle: "italic"
    }
  }, o), /*#__PURE__*/React.createElement(Button, {
    size: "sm",
    variant: "secondary",
    onClick: onQuote
  }, "Enquire")))), /*#__PURE__*/React.createElement("p", {
    style: {
      marginTop: "var(--space-9)",
      font: "var(--type-small)",
      color: "var(--text-muted)",
      maxWidth: 760
    }
  }, "Our two core products are available in any quantity at a price that is a small fraction of the competition price for a tri-saccharide. Selected: ", selected, "."))), /*#__PURE__*/React.createElement(ContactBand, {
    onQuote: onQuote
  }));
}
window.Products = Products;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/Products.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/app.jsx
try { (() => {
function Placeholder({
  title
}) {
  return /*#__PURE__*/React.createElement("main", {
    className: "gb-sect"
  }, /*#__PURE__*/React.createElement(Container, null, /*#__PURE__*/React.createElement(SectionHeader, {
    eyebrow: title,
    title: title + " page",
    lead: "This page exists on glycobar.com but was not recreated in this kit. Nothing here is invented \u2014 see readme.md."
  })));
}
function Site() {
  const [page, setPage] = React.useState("home");
  const [quote, setQuote] = React.useState(false);
  const [toast, setToast] = React.useState(false);
  const [email, setEmail] = React.useState("");
  const [product, setProduct] = React.useState("");
  const [agree, setAgree] = React.useState(true);
  React.useEffect(() => {
    window.scrollTo(0, 0);
  }, [page]);
  React.useEffect(() => {
    if (!toast) return;
    const t = setTimeout(() => setToast(false), 3200);
    return () => clearTimeout(t);
  }, [toast]);
  const openQuote = () => setQuote(true);
  const send = () => {
    setQuote(false);
    setToast(true);
  };
  const pages = {
    home: /*#__PURE__*/React.createElement(Home, {
      onQuote: openQuote,
      onNavigate: setPage
    }),
    about: /*#__PURE__*/React.createElement(About, {
      onQuote: openQuote
    }),
    products: /*#__PURE__*/React.createElement(Products, {
      onQuote: openQuote
    }),
    markets: /*#__PURE__*/React.createElement(Markets, {
      onQuote: openQuote
    })
  };
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(NavBar, {
    logoSrc: LOGO,
    items: NAV,
    active: page,
    onNavigate: setPage,
    onCta: openQuote
  }), pages[page] || /*#__PURE__*/React.createElement(Placeholder, {
    title: (NAV.find(n => n.id === page) || {}).label || page
  }), /*#__PURE__*/React.createElement(Footer, {
    logoSrc: LOGO,
    about: "Glycosciences serving medical innovation. Glycans, such as antigens, are omnipresent in biology and their control is essential to maintain and improve human health.",
    columns: [{
      title: "Company",
      links: ["Home", "About Us", "Contact Us", "Legals"]
    }, {
      title: "Services",
      links: ["Impacts", "Process", "Products", "R&D", "Markets"]
    }]
  }), /*#__PURE__*/React.createElement(Dialog, {
    open: quote,
    title: "Request a quote",
    onClose: () => setQuote(false),
    width: 560,
    footer: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Button, {
      variant: "ghost",
      onClick: () => setQuote(false)
    }, "Cancel"), /*#__PURE__*/React.createElement(Button, {
      onClick: send,
      iconRight: "send"
    }, "Send request"))
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: "var(--space-7)"
    }
  }, /*#__PURE__*/React.createElement("p", {
    style: {
      font: "var(--type-small)",
      color: "var(--text-muted)"
    }
  }, "Willing to collaborate, discover our solutions or discuss blood group antigen applications? You've come to the right place!"), /*#__PURE__*/React.createElement(Field, {
    label: "Work email",
    required: true,
    htmlFor: "q-email"
  }, /*#__PURE__*/React.createElement(Input, {
    id: "q-email",
    icon: "mail",
    placeholder: "you@lab.org",
    value: email,
    onChange: e => setEmail(e.target.value)
  })), /*#__PURE__*/React.createElement(Field, {
    label: "Product",
    htmlFor: "q-prod",
    hint: "Any quantity, from milligrams to kilos."
  }, /*#__PURE__*/React.createElement(Select, {
    id: "q-prod",
    value: product,
    onChange: e => setProduct(e.target.value),
    placeholder: "Choose a product",
    options: ["Blood Group A antigen ligand", "Blood Group B antigen ligand", "A tri-saccharide", "B tri-saccharide", "A hexa-saccharide", "B hexa-saccharide"]
  })), /*#__PURE__*/React.createElement(Field, {
    label: "Application",
    htmlFor: "q-app"
  }, /*#__PURE__*/React.createElement(Textarea, {
    id: "q-app",
    rows: 3,
    placeholder: "Describe your application"
  })), /*#__PURE__*/React.createElement(Checkbox, {
    checked: agree,
    onChange: setAgree,
    label: "A scientist may contact me directly"
  }))), toast ? /*#__PURE__*/React.createElement("div", {
    style: {
      position: "fixed",
      left: 0,
      right: 0,
      bottom: 28,
      display: "flex",
      justifyContent: "center",
      zIndex: 80
    }
  }, /*#__PURE__*/React.createElement(Toast, {
    tone: "success",
    message: "Your request has been sent. A scientist answers every request.",
    onDismiss: () => setToast(false)
  })) : null);
}
ReactDOM.createRoot(document.getElementById("root")).render(/*#__PURE__*/React.createElement(Site, null));
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/app.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/shared.jsx
try { (() => {
const DS = window.GlycoBARDesignSystem_d44615;
const {
  Button,
  IconButton,
  Icon,
  Card,
  Badge,
  Tag,
  Callout,
  Stat,
  Field,
  Input,
  Textarea,
  Select,
  Checkbox,
  Radio,
  Switch,
  NavBar,
  Footer,
  Tabs,
  Dialog,
  Toast,
  Tooltip,
  PageHero,
  SectionHeader,
  MediaSection,
  Glycan,
  GlycanSymbol,
  GlycanTrail,
  GLYCOBAR_A,
  GLYCOBAR_B
} = DS;
const LOGO = "../../assets/glycobar-logo.png";
const PLANT = "../../assets/photography/plant-exterior.png";
const NAV = [{
  id: "home",
  label: "Home"
}, {
  id: "about",
  label: "About Us"
}, {
  id: "impacts",
  label: "Impacts"
}, {
  id: "process",
  label: "Process"
}, {
  id: "products",
  label: "Products"
}, {
  id: "rd",
  label: "R&D"
}, {
  id: "markets",
  label: "Markets"
}];

/** Marks where a figure from glycobar.com belongs. The originals could not be
 *  downloaded, so they are labelled rather than invented. */
function Figure({
  src,
  alt,
  caption,
  height = 260,
  style
}) {
  if (src) return /*#__PURE__*/React.createElement("figure", {
    style: {
      margin: 0,
      ...style
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: src,
    alt: alt,
    style: {
      width: "100%",
      height,
      objectFit: "cover",
      display: "block",
      borderRadius: "var(--radius-image)",
      boxShadow: "var(--shadow-md)"
    }
  }), caption ? /*#__PURE__*/React.createElement("figcaption", {
    style: {
      marginTop: "var(--space-4)",
      font: "var(--weight-regular) var(--text-xs)/1.5 var(--font-body)",
      color: "var(--text-muted)"
    }
  }, caption) : null);
  return /*#__PURE__*/React.createElement("div", {
    className: "gb-figure",
    style: {
      height,
      ...style
    }
  }, caption || alt);
}
function Container({
  children,
  style
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: "var(--container-max)",
      margin: "0 auto",
      padding: "0 var(--gutter)",
      ...style
    }
  }, children);
}
function DiamondBullets({
  items,
  style
}) {
  return /*#__PURE__*/React.createElement("ul", {
    style: {
      listStyle: "none",
      margin: 0,
      padding: 0,
      display: "flex",
      flexDirection: "column",
      gap: "var(--space-5)",
      ...style
    }
  }, items.map(t => /*#__PURE__*/React.createElement("li", {
    key: t,
    style: {
      display: "flex",
      gap: "var(--space-5)",
      alignItems: "flex-start"
    }
  }, /*#__PURE__*/React.createElement("svg", {
    width: "11",
    height: "11",
    viewBox: "0 0 12 12",
    style: {
      flex: "0 0 auto",
      marginTop: 8
    },
    "aria-hidden": "true"
  }, /*#__PURE__*/React.createElement("circle", {
    cx: "6",
    cy: "6",
    r: "5",
    fill: "none",
    stroke: "var(--snfg-connector)",
    strokeWidth: "1.25"
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      font: "var(--type-body)",
      color: "var(--text-body)"
    }
  }, t))));
}

/** The site's repeated "Quotation / Technical Questions" band. */
function ContactBand({
  onQuote
}) {
  return /*#__PURE__*/React.createElement("section", {
    style: {
      background: "var(--surface-brand)",
      padding: "var(--section-y-tight) 0"
    }
  }, /*#__PURE__*/React.createElement(Container, {
    style: {
      display: "flex",
      gap: "var(--space-12)",
      alignItems: "center",
      justifyContent: "space-between"
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      font: "var(--type-eyebrow)",
      letterSpacing: "var(--tracking-label)",
      textTransform: "uppercase",
      color: "var(--clay-200)"
    }
  }, "Quotation"), /*#__PURE__*/React.createElement("div", {
    style: {
      font: "var(--weight-light) var(--text-3xl)/1.2 var(--font-display)",
      color: "#fff",
      marginTop: "var(--space-4)"
    }
  }, "Interested in our solution?")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: "var(--space-5)"
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "inverse",
    onClick: onQuote
  }, "Request a quote"), /*#__PURE__*/React.createElement(Button, {
    variant: "ghost",
    style: {
      color: "#fff",
      border: "1px solid rgba(255,255,255,.5)"
    },
    onClick: onQuote
  }, "Ask a scientist"))));
}
Object.assign(window, {
  DS,
  Button,
  IconButton,
  Icon,
  Card,
  Badge,
  Tag,
  Callout,
  Stat,
  Field,
  Input,
  Textarea,
  Select,
  Checkbox,
  Radio,
  Switch,
  NavBar,
  Footer,
  Tabs,
  Dialog,
  Toast,
  Tooltip,
  PageHero,
  SectionHeader,
  MediaSection,
  Glycan,
  GlycanSymbol,
  GlycanTrail,
  GLYCOBAR_A,
  GLYCOBAR_B,
  LOGO,
  PLANT,
  NAV,
  Figure,
  Container,
  DiamondBullets,
  ContactBand
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/shared.jsx", error: String((e && e.message) || e) }); }

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Callout = __ds_scope.Callout;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.Icon = __ds_scope.Icon;

__ds_ns.IconButton = __ds_scope.IconButton;

__ds_ns.Stat = __ds_scope.Stat;

__ds_ns.Tag = __ds_scope.Tag;

__ds_ns.Dialog = __ds_scope.Dialog;

__ds_ns.Toast = __ds_scope.Toast;

__ds_ns.Tooltip = __ds_scope.Tooltip;

__ds_ns.Checkbox = __ds_scope.Checkbox;

__ds_ns.Field = __ds_scope.Field;

__ds_ns.Input = __ds_scope.Input;

__ds_ns.Radio = __ds_scope.Radio;

__ds_ns.Select = __ds_scope.Select;

__ds_ns.Switch = __ds_scope.Switch;

__ds_ns.Textarea = __ds_scope.Textarea;

__ds_ns.MediaSection = __ds_scope.MediaSection;

__ds_ns.PageHero = __ds_scope.PageHero;

__ds_ns.SectionHeader = __ds_scope.SectionHeader;

__ds_ns.Footer = __ds_scope.Footer;

__ds_ns.NavBar = __ds_scope.NavBar;

__ds_ns.Tabs = __ds_scope.Tabs;

__ds_ns.Glycan = __ds_scope.Glycan;

__ds_ns.GLYCOBAR_A = __ds_scope.GLYCOBAR_A;

__ds_ns.GLYCOBAR_B = __ds_scope.GLYCOBAR_B;

__ds_ns.SNFG = __ds_scope.SNFG;

__ds_ns.GlycanSymbol = __ds_scope.GlycanSymbol;

__ds_ns.GlycanTrail = __ds_scope.GlycanTrail;

})();
