function Home({ onQuote, onNavigate }) {
  const steps = [
    { t: "Selection and Cultivation of Bacteria", d: "The biofermentation process begins with the design of appropriate bacterial strains..." },
    { t: "Regulation and Optimization", d: "The biofermentation process is closely monitored and regulated to ensure optimal glycan production..." },
    { t: "Harvesting and Purification", d: "After a period of biofermentation, during which the bacteria have produced the desired glycans..." },
  ];
  const cards = [
    { eyebrow: "Impacts", title: "Leading innovation", body: "By leading innovation to expand access to life-saving medical products and support the work of healthcare professionals, GlycoBAR contributes to the achievement of the United Nations Sustainable Development Goals (SDGs).", link: "Read More", to: "impacts" },
    { eyebrow: "Biofermentation process", title: "GlycoBAR production process", body: "Our proprietary biofermentation process sets us apart. By harnessing the natural capabilities of bacteria used as cell factories, we produce highly specific blood group antigen ligands...", link: "Read More", to: "process" },
    { eyebrow: "Blood antigens market", title: "Universal plasma", body: "Thanks to the availability of GlycoBAR low-cost antigen ligands, universal plasma will shortly become a reality. Our blood group antigen ligands grafted on a cellulosic support (we have a proof of concept for this)", link: "Read More", to: "markets" },
  ];
  return (
    <main>
      <PageHero eyebrow="Innovative"
        title="Blood goup antigens ligands for an ABO antibody-free World"
        lead="Glycosciences serving medical innovation. Glycans, such as antigens, are omnipresent in biology and their control is essential to maintain and improve human health…"
        image={PLANT} imageAlt="GlycoBAR production plant, Domène" height={520}>
        <Button variant="inverse" iconRight="arrow-right" onClick={() => onNavigate("about")}>Discover More</Button>
      </PageHero>

      <section className="gb-sect">
        <Container>
          <div className="gb-grid-3">
            {cards.map((c) => (
              <Card key={c.title} interactive padding="var(--card-pad-lg)" onClick={() => onNavigate(c.to)}>
                <div style={{ font: "var(--type-eyebrow)", letterSpacing: "var(--tracking-label)", textTransform: "uppercase", color: "var(--brand)" }}>{c.eyebrow}</div>
                <h3 style={{ marginTop: "var(--space-5)", font: "var(--type-h3)" }}>{c.title}</h3>
                <p style={{ marginTop: "var(--space-6)", font: "var(--type-small)", color: "var(--text-body)" }}>{c.body}</p>
                <div style={{ marginTop: "var(--space-7)", display: "inline-flex", alignItems: "center", gap: "var(--space-4)", font: "var(--weight-medium) var(--text-sm)/1 var(--font-body)", letterSpacing: "var(--tracking-wide)", textTransform: "uppercase", color: "var(--brand)" }}>
                  {c.link}<Icon name="arrow-right" size={15} />
                </div>
              </Card>
            ))}
          </div>
        </Container>
      </section>

      <MediaSection image={PLANT} imageAlt="GlycoBAR industrial demonstrator" tone="alt" reverse>
        <SectionHeader eyebrow="About GlycoBar" title="Essential or even vital health products should be accessible for everybody"
          lead="Transforming this idea into a reality stirs us up every day and drives us to develop a technology to make antigens ligands economically compatible with the blood market. Our ligands are the most affordable ones on the market – by far, with uncompromised quality. For the first time, universal blood components have become economically viable!">
          <p style={{ font: "var(--type-body)", color: "var(--text-body)" }}>Second major advantage, GlycoBAR's technology enables scalable production capacity to meet global needs. Come and see our industrial demonstrator which already supplies international customers.</p>
          <div style={{ display: "flex", gap: "var(--space-11)", margin: "var(--space-9) 0" }}>
            <Stat value="220" unit="m²" label="Production floor" />
            <Stat value="2015" label="Founded in Grenoble" />
          </div>
          <Button variant="secondary" iconRight="arrow-right" onClick={() => onNavigate("about")}>More About</Button>
        </SectionHeader>
      </MediaSection>

      <section className="gb-sect">
        <Container>
          <SectionHeader eyebrow="Process" title="We follow some easy steps to develop Our Project" align="center" maxWidth={820}
            lead="Optimization of hospitals logistics, simplification of caregivers' tasks, improvement of the safety of medical and pharmaceutical products, and above all, innovative and better-quality treatments for patients; the benefits are countless, let's discover them!" />
          <GlycanTrail style={{ margin: "var(--space-11) auto 0", maxWidth: 820 }} size={18} gap={260} active={1}
            shapes={["square", "circle", "circle", "diamond"]}
            labels={["Strain design", "Fermentation", "Purification", "Release"]} />
          <div className="gb-grid-3" style={{ marginTop: "var(--space-9)" }}>
            {steps.map((s, i) => (
              <Card key={s.t} padding="var(--card-pad-lg)">
                <div style={{ display: "flex", alignItems: "center", gap: "var(--space-5)" }}>
                  <span style={{ width: 34, height: 34, background: "var(--clay-100)", display: "inline-flex", alignItems: "center", justifyContent: "center", transform: "rotate(45deg)" }}>
                    <span style={{ transform: "rotate(-45deg)", font: "var(--type-mono)", color: "var(--clay-700)" }}>{i + 1}</span>
                  </span>
                  <Badge tone="neutral">Step {i + 1}</Badge>
                </div>
                <h3 style={{ marginTop: "var(--space-7)", font: "var(--type-h3)" }}>{s.t}</h3>
                <p style={{ marginTop: "var(--space-5)", font: "var(--type-small)", color: "var(--text-body)" }}>{s.d}</p>
              </Card>
            ))}
          </div>
        </Container>
      </section>

      <section className="gb-sect" style={{ background: "var(--surface-inverse)" }}>
        <Container>
          <div className="gb-grid-2" style={{ alignItems: "center" }}>
            <SectionHeader tone="inverse" eyebrow="Why Choose Us?" title="How do we revolutionize blood and plasma therapies?"
              lead="Through our unique bio fermentation technology which produces antigen ligands to remove blood group antibodies from plasma.">
              <p style={{ font: "var(--weight-medium) var(--text-lg)/1.5 var(--font-body)", color: "#fff", marginBottom: "var(--space-8)" }}>Our vision? No more blood group barrier thanks to a world free of blood group antibodies.</p>
              <ul style={{ listStyle: "none", margin: 0, padding: 0, display: "flex", flexDirection: "column", gap: "var(--space-5)" }}>
                {["Universal plasma", "Universal platelets", "Organ transplants over the blood group barrier", "New and safer IVIG"].map((t) => (
                  <li key={t} style={{ display: "flex", gap: "var(--space-5)", alignItems: "center" }}>
                    <svg width="12" height="12" viewBox="0 0 12 12" aria-hidden="true"><circle cx="6" cy="6" r="5" fill="none" stroke="var(--clay-400)" strokeWidth="1.25" /></svg>
                    <span style={{ font: "var(--type-body)", color: "var(--clay-100)" }}>{t}</span>
                  </li>
                ))}
              </ul>
            </SectionHeader>
            <div style={{ display: "flex", flexDirection: "column", gap: "var(--space-8)" }}>
              {[{ n: "Blood group A tetraose", r: GLYCOBAR_A }, { n: "Blood group B tetraose", r: GLYCOBAR_B }].map((g) => (
                <div key={g.n} style={{ padding: "var(--space-8)", border: "1px solid var(--clay-800)", borderRadius: "var(--radius-card)", background: "rgba(255,255,255,.04)" }}>
                  <div style={{ font: "var(--type-eyebrow)", letterSpacing: "var(--tracking-label)", textTransform: "uppercase", color: "var(--clay-400)", marginBottom: "var(--space-6)" }}>{g.n}</div>
                  <Glycan residues={g.r} reducingEnd="NH₂" />
                </div>
              ))}
            </div>
          </div>
        </Container>
      </section>

      <ContactBand onQuote={onQuote} />
    </main>
  );
}
window.Home = Home;
