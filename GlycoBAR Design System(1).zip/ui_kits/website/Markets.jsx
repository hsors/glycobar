function Markets({ onQuote }) {
  const [market, setMarket] = React.useState("plasma");
  const benefits = [
    { t: "Streamlined Inventory Management", d: "Hospitals and blood banks can maintain a single type of plasma, reducing the complexity and costs associated with storing multiple blood group plasmas." },
    { t: "Immediate Availability", d: "In emergencies, universal plasma can be readily available for transfusions without the need for blood type matching, speeding up treatment and potentially saving lives." },
    { t: "Reduced Risk of Transfusion Reactions", d: "By removing blood group antibodies, universal plasma minimizes the risk of hemolytic reactions, enhancing patient safety." },
    { t: "Increased Efficiency", d: "Simplifying the transfusion process allows healthcare providers to focus more on patient care and less on logistical challenges." },
  ];
  const tabs = [
    { id: "plasma", label: "Universal plasma" },
    { id: "platelets", label: "Universal platelets" },
    { id: "organs", label: "Organ transplants" },
    { id: "ivig", label: "IVIG purification" },
  ];
  return (
    <main>
      <section className="gb-sect-tight">
        <Container>
          <SectionHeader eyebrow="Blood Antigens Markets" title="Four markets, one mechanism" maxWidth={700}
            lead="Removing blood group antibodies simplifies every product that is shared between individuals." />
          <Tabs style={{ marginTop: "var(--space-9)" }} active={market} onChange={setMarket} items={tabs} />

          {market === "plasma" ? (
            <div style={{ marginTop: "var(--space-10)" }}>
              <div className="gb-grid-2" style={{ alignItems: "start" }}>
                <div>
                  <h2 style={{ font: "var(--type-h2)" }}>Universal Plasma</h2>
                  <p style={{ marginTop: "var(--space-6)", font: "var(--type-lead)", fontStyle: "italic", color: "var(--text-body)" }}>Thanks to the availability of GlycoBAR low-cost antigen ligands, universal plasma will shortly become a reality.</p>
                  <p style={{ marginTop: "var(--space-6)", font: "var(--type-body)", color: "var(--text-body)" }}>Our blood group antigen ligands grafted on a cellulosic support (we have a proof of concept for this) are forming an affordable solution that can be used either in an individual plasma bag to make it universal or on plasma pools.</p>
                  <div style={{ display: "flex", gap: "var(--space-11)", marginTop: "var(--space-9)" }}>
                    <Stat value="1" label="Plasma inventory to manage" />
                    <Stat value="AB" label="Equivalent plasma grade" />
                  </div>
                </div>
                <Figure caption="wp-content/uploads/2025/02/3.jpg — plasma bags (asset not available)" height={320} />
              </div>
              <div className="gb-grid-2" style={{ marginTop: "var(--space-11)" }}>
                {benefits.map((b) => (
                  <Card key={b.t} padding="var(--card-pad-lg)">
                    <Badge tone="universal">Benefit</Badge>
                    <h3 style={{ marginTop: "var(--space-5)", font: "var(--type-h3)" }}>{b.t}</h3>
                    <p style={{ marginTop: "var(--space-5)", font: "var(--type-small)", color: "var(--text-body)" }}>{b.d}</p>
                  </Card>
                ))}
              </div>
              <Callout tone="note" style={{ marginTop: "var(--space-9)" }}>These improvements can lead to better resource allocation, reduced waste, and overall enhanced efficiency in medical facilities.</Callout>
            </div>
          ) : null}

          {market === "platelets" ? (
            <div className="gb-grid-2" style={{ marginTop: "var(--space-10)", alignItems: "center" }}>
              <div>
                <h2 style={{ font: "var(--type-h2)" }}>Universal Platelets</h2>
                <DiamondBullets style={{ marginTop: "var(--space-7)" }} items={[
                  "The same benefits apply to platelets to an even greater extent.",
                  "Platelets are very short-lived blood components, lasting only a few days.",
                  "Being able to manage a single inventory of platelets would bring significant benefits to the health system.",
                ]} />
              </div>
              <Figure caption="wp-content/uploads/2025/02/1.jpg — platelet unit (asset not available)" height={300} />
            </div>
          ) : null}

          {market === "organs" ? (
            <div style={{ marginTop: "var(--space-10)" }}>
              <div className="gb-grid-2" style={{ alignItems: "start" }}>
                <div>
                  <h2 style={{ font: "var(--type-h2)" }}>Organ Transplants</h2>
                  <p style={{ marginTop: "var(--space-6)", font: "var(--type-lead)", fontStyle: "italic", color: "var(--text-body)" }}>A recipient can accept only transplanted organs compatible with his ABO blood group otherwise his ABO antibodies will kill the transplanted organ.</p>
                  <p style={{ marginTop: "var(--space-6)", font: "var(--type-body)", color: "var(--text-body)" }}>As a result of the limited donors-recipient compatibility matrix, there is currently a huge shortage of available organs for transplant. Blood group mismatch is a big issue and therefore providing a product allowing to resolve that issue is utmost important for saving lives.</p>
                </div>
                <Figure caption="wp-content/uploads/2025/03/19.jpg — transplant surgery (asset not available)" height={280} />
              </div>
              <h3 style={{ marginTop: "var(--space-11)", font: "var(--type-h3)" }}>Solution</h3>
              <p style={{ marginTop: "var(--space-5)", font: "var(--type-body)", fontStyle: "italic", color: "var(--text-body)", maxWidth: 860 }}>GlycoBAR partners develop extra corporal devices that filter the recipient blood so that blood group antibodies are eliminated from plasma.</p>
              <GlycanTrail style={{ margin: "var(--space-9) auto var(--space-8)", maxWidth: 760 }} size={16} gap={340} active={2}
                shapes={["circle", "square", "diamond"]} labels={["Plasmapheresis", "Ligand filtration", "Reinjection"]} />
              <div className="gb-grid-3">
                {["The recipient patient's blood is derived in an external circuitry where it is centrifugated with a plasmapheresis machine.",
                  "The plasma is purified from blood group antibodies thanks to a proprietary medical device using GlycoBAR ligands and all the blood components are then reinjected in the patient's blood system.",
                  "After a few days of this treatment, the patient is ready to receive an organ of any blood group."].map((s, i) => (
                  <Card key={i} tone="tint" padding="var(--card-pad-lg)">
                    <span style={{ font: "var(--type-mono)", color: "var(--brand)" }}>0{i + 1}</span>
                    <p style={{ marginTop: "var(--space-5)", font: "var(--type-small)", color: "var(--text-body)" }}>{s}</p>
                  </Card>
                ))}
              </div>
            </div>
          ) : null}

          {market === "ivig" ? (
            <div style={{ marginTop: "var(--space-10)" }}>
              <div className="gb-grid-2" style={{ alignItems: "start" }}>
                <div>
                  <h2 style={{ font: "var(--type-h2)" }}>IVIG Purification</h2>
                  <p style={{ marginTop: "var(--space-6)", font: "var(--type-body)", color: "var(--text-body)" }}>The plasma fractionation industry producing so called IVIG products (Intra Venous Immunoglobulin type G) is facing a serious challenge: as of today, for obvious logistic reasons and also because IgG blood group antibodies are not highly hemolytic, the plasma used in fractionation factories is not grouped (this is a mix of plasma of all groups). Consequently, IVIG products contain isoagglutinins.</p>
                  <Callout tone="danger" title="FDA, 2015" style={{ marginTop: "var(--space-7)" }}>The FDA raised concerns about this issue and encouraged IVIG suppliers to remove isoagglutinins from their products. However, due to the high cost and production challenges of blood group antigen ligands at the time, few suppliers complied with these recommendations.</Callout>
                </div>
                <Figure caption="wp-content/uploads/2025/03/pediatric-doctor…jpg — paediatric care (asset not available)" height={300} />
              </div>
              <h3 style={{ marginTop: "var(--space-11)", font: "var(--type-h3)" }}>There are two ways to remove isoagglutinins from IVIG</h3>
              <div className="gb-grid-2" style={{ marginTop: "var(--space-8)" }}>
                <Card padding="var(--card-pad-lg)">
                  <Badge tone="brand">Route one</Badge>
                  <h3 style={{ marginTop: "var(--space-5)", font: "var(--type-h3)" }}>Chromatographic column with a GlycoBAR-grafted resin</h3>
                  <p style={{ marginTop: "var(--space-5)", font: "var(--type-small)", color: "var(--text-body)" }}>By adding a very simple and well-known affinity purification step in their IVIG production process, IVIG suppliers can now eliminate completely isoagglutinins from their products. GlycoBAR has a partnership with a leading chromatographic resin supplier which is taking care of the grafting process and offers a turn-key solution.</p>
                </Card>
                <Card padding="var(--card-pad-lg)">
                  <Badge tone="brand">Route two</Badge>
                  <h3 style={{ marginTop: "var(--space-5)", font: "var(--type-h3)" }}>Low-cost antibody titer measurement</h3>
                  <p style={{ marginTop: "var(--space-5)", font: "var(--type-small)", color: "var(--text-body)" }}>GlycoBAR is developing a low-cost device aimed at measuring the antibody titer of each plasma bag, both IgG and IgM, A and B. Fully compatible with any Elisa plate reader, it will flag any high titer plasma, which can then be rerouted to an antibody removal step using a filter GlycoBAR can provide through one of its partners.</p>
                </Card>
              </div>
            </div>
          ) : null}
        </Container>
      </section>
      <ContactBand onQuote={onQuote} />
    </main>
  );
}
window.Markets = Markets;
