function Products({ onQuote }) {
  const [tab, setTab] = React.useState("core");
  const [selected, setSelected] = React.useState("A tetraose");
  const groups = [
    { g: "A", tone: "a", antigen: "Antigen A only", plasma: "anti-B antibodies" },
    { g: "B", tone: "b", antigen: "Antigen B only", plasma: "anti-A antibodies" },
    { g: "AB", tone: "universal", antigen: "Antigens A and B", plasma: "neither anti-A nor anti-B" },
    { g: "O", tone: "neutral", antigen: "Neither antigen", plasma: "both anti-A and anti-B" },
  ];
  const others = [
    "Blood group A tri-saccharide antigen",
    "Blood group B tri-saccharide antigen",
    "Blood group A hexa-saccharide antigen (bare sugar version; amine termination also available)",
    "Blood group B hexa-saccharide antigen (bare sugar version; amine termination also available)",
  ];
  return (
    <main>
      <section className="gb-sect-tight">
        <Container>
          <SectionHeader eyebrow="Commercial Antigens Products" title="Introduction to blood group antigens"
            lead="Human red blood cells are covered with blood group antigens." maxWidth={760} />
          <div className="gb-grid-2" style={{ marginTop: "var(--space-10)", alignItems: "start" }}>
            <div style={{ display: "flex", flexDirection: "column", gap: "var(--space-5)" }}>
              {groups.map((g) => (
                <Card key={g.g} style={{ display: "flex", alignItems: "center", gap: "var(--space-7)" }}>
                  <span style={{ font: "var(--weight-medium) var(--text-2xl)/1 var(--font-display)", color: "var(--text-heading)", width: 44 }}>{g.g}</span>
                  <div style={{ flex: 1 }}>
                    <div style={{ font: "var(--type-label)", color: "var(--text-heading)" }}>{g.antigen}</div>
                    <div style={{ marginTop: "var(--space-2)", font: "var(--type-small)", color: "var(--text-muted)" }}>Plasma contains {g.plasma}</div>
                  </div>
                  <Badge tone={g.tone}>Group {g.g}</Badge>
                </Card>
              ))}
              <Callout tone="warning" title="Hemolysis">If plasma containing specific antibodies contacts red blood cells with the corresponding antigens, it can destroy the red blood cells, potentially triggering hemolysis.</Callout>
              <Callout tone="info" title="Universal blood components">With universal blood components, blood group antibodies are removed, allowing safe mixing of any blood components, regardless of the donor's and recipient's blood groups.</Callout>
            </div>
            <div style={{ display: "flex", flexDirection: "column", gap: "var(--space-7)" }}>
              <Figure caption="wp-content/uploads/2025/03/iStock-2135107973-1.jpg — the four blood groups (asset not available)" height={300} />
              <Figure caption="wp-content/uploads/2025/02/Image16.png — antibodies present in plasma (asset not available)" height={200} />
            </div>
          </div>
        </Container>
      </section>

      <section className="gb-sect-tight" style={{ background: "var(--surface-alt)" }}>
        <Container>
          <SectionHeader eyebrow="Core products" title="A and B Blood group antigens tetraose sugars"
            lead="Those are the core products proposed by GlycoBAR. The standard form is with an amine termination and a linker arm giving to the molecule approximately the same length as the hexa-saccharide blood group antigen sugars corresponding to the natural antigens attached to erythrocytes." maxWidth={860} />
          <Tabs style={{ marginTop: "var(--space-9)" }} active={tab} onChange={setTab}
            items={[{ id: "core", label: "Core tetraoses" }, { id: "other", label: "Other blood group sugars" }]} />
          {tab === "core" ? (
            <div className="gb-grid-2" style={{ marginTop: "var(--space-9)" }}>
              {[{ n: "Blood Group A antigen ligand", tone: "a", f: "GalNAc(α1-3)[Fuc(α1-2)]Gal(β1-4)GlcNAc-NH₂" },
                { n: "Blood Group B antigen ligand", tone: "b", f: "Gal(α1-3)[Fuc(α1-2)]Gal(β1-4)GlcNAc-NH₂" }].map((p) => (
                <Card key={p.n} padding="var(--card-pad-lg)" interactive onClick={() => setSelected(p.n)}>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                    <Badge tone={p.tone}>{p.tone === "a" ? "Antigen A" : "Antigen B"}</Badge>
                    <Tooltip label="Tetrasaccharide with amine termination and linker arm"><Icon name="info" size={17} color="var(--text-muted)" /></Tooltip>
                  </div>
                  <div style={{ marginTop: "var(--space-7)", padding: "var(--space-7) var(--space-5)", background: "var(--surface-page)", border: "1px solid var(--border-hairline)", borderRadius: "var(--radius-image)" }}>
                    <Glycan residues={p.tone === "a" ? GLYCOBAR_A : GLYCOBAR_B} reducingEnd="NH₂ linker arm" />
                  </div>
                  <h3 style={{ marginTop: "var(--space-7)", font: "var(--type-h3)" }}>{p.n}</h3>
                  <div style={{ marginTop: "var(--space-4)", font: "var(--type-mono)", color: "var(--text-muted)" }}>{p.f}</div>
                  <div style={{ marginTop: "var(--space-7)", display: "flex", gap: "var(--space-5)" }}>
                    <Button size="sm" onClick={onQuote}>Request a quote</Button>
                    <Button size="sm" variant="ghost" iconLeft="download">Datasheet</Button>
                  </div>
                </Card>
              ))}
            </div>
          ) : (
            <div style={{ marginTop: "var(--space-9)", display: "flex", flexDirection: "column", gap: "var(--space-5)" }}>
              <p style={{ font: "var(--type-body)", color: "var(--text-body)" }}>GlycoBAR is also able to propose a lot of other blood group antigen sugars.</p>
              {others.map((o) => (
                <Card key={o} style={{ display: "flex", alignItems: "center", gap: "var(--space-7)" }}>
                  <svg width="12" height="12" viewBox="0 0 12 12" style={{ flex: "0 0 auto" }} aria-hidden="true"><rect x="1" y="1" width="10" height="10" fill="none" stroke="var(--snfg-connector)" strokeWidth="1.25" /></svg>
                  <span style={{ flex: 1, font: "var(--type-body)", color: "var(--text-body)", fontStyle: "italic" }}>{o}</span>
                  <Button size="sm" variant="secondary" onClick={onQuote}>Enquire</Button>
                </Card>
              ))}
            </div>
          )}
          <p style={{ marginTop: "var(--space-9)", font: "var(--type-small)", color: "var(--text-muted)", maxWidth: 760 }}>Our two core products are available in any quantity at a price that is a small fraction of the competition price for a tri-saccharide. Selected: {selected}.</p>
        </Container>
      </section>

      <ContactBand onQuote={onQuote} />
    </main>
  );
}
window.Products = Products;
