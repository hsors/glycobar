function Placeholder({ title }) {
  return (
    <main className="gb-sect">
      <Container>
        <SectionHeader eyebrow={title} title={title + " page"} lead="This page exists on glycobar.com but was not recreated in this kit. Nothing here is invented — see readme.md." />
      </Container>
    </main>
  );
}

function Site() {
  const [page, setPage] = React.useState("home");
  const [quote, setQuote] = React.useState(false);
  const [toast, setToast] = React.useState(false);
  const [email, setEmail] = React.useState("");
  const [product, setProduct] = React.useState("");
  const [agree, setAgree] = React.useState(true);

  React.useEffect(() => { window.scrollTo(0, 0); }, [page]);
  React.useEffect(() => { if (!toast) return; const t = setTimeout(() => setToast(false), 3200); return () => clearTimeout(t); }, [toast]);

  const openQuote = () => setQuote(true);
  const send = () => { setQuote(false); setToast(true); };

  const pages = {
    home: <Home onQuote={openQuote} onNavigate={setPage} />,
    about: <About onQuote={openQuote} />,
    products: <Products onQuote={openQuote} />,
    markets: <Markets onQuote={openQuote} />,
  };

  return (
    <React.Fragment>
      <NavBar logoSrc={LOGO} items={NAV} active={page} onNavigate={setPage} onCta={openQuote} />
      {pages[page] || <Placeholder title={(NAV.find((n) => n.id === page) || {}).label || page} />}
      <Footer logoSrc={LOGO}
        about="Glycosciences serving medical innovation. Glycans, such as antigens, are omnipresent in biology and their control is essential to maintain and improve human health."
        columns={[{ title: "Company", links: ["Home", "About Us", "Contact Us", "Legals"] },
                  { title: "Services", links: ["Impacts", "Process", "Products", "R&D", "Markets"] }]} />

      <Dialog open={quote} title="Request a quote" onClose={() => setQuote(false)} width={560}
        footer={<React.Fragment><Button variant="ghost" onClick={() => setQuote(false)}>Cancel</Button><Button onClick={send} iconRight="send">Send request</Button></React.Fragment>}>
        <div style={{ display: "flex", flexDirection: "column", gap: "var(--space-7)" }}>
          <p style={{ font: "var(--type-small)", color: "var(--text-muted)" }}>Willing to collaborate, discover our solutions or discuss blood group antigen applications? You've come to the right place!</p>
          <Field label="Work email" required htmlFor="q-email"><Input id="q-email" icon="mail" placeholder="you@lab.org" value={email} onChange={(e) => setEmail(e.target.value)} /></Field>
          <Field label="Product" htmlFor="q-prod" hint="Any quantity, from milligrams to kilos.">
            <Select id="q-prod" value={product} onChange={(e) => setProduct(e.target.value)} placeholder="Choose a product"
              options={["Blood Group A antigen ligand", "Blood Group B antigen ligand", "A tri-saccharide", "B tri-saccharide", "A hexa-saccharide", "B hexa-saccharide"]} />
          </Field>
          <Field label="Application" htmlFor="q-app"><Textarea id="q-app" rows={3} placeholder="Describe your application" /></Field>
          <Checkbox checked={agree} onChange={setAgree} label="A scientist may contact me directly" />
        </div>
      </Dialog>

      {toast ? (
        <div style={{ position: "fixed", left: 0, right: 0, bottom: 28, display: "flex", justifyContent: "center", zIndex: 80 }}>
          <Toast tone="success" message="Your request has been sent. A scientist answers every request." onDismiss={() => setToast(false)} />
        </div>
      ) : null}
    </React.Fragment>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<Site />);
