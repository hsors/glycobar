# UI kit — glycobar.com (marketing website)

A click-through recreation of GlycoBAR's only product surface. Built from the live pages at \`https://glycobar.com/\` (Home, About Us, Products, Markets), read as HTML — no codebase or Figma file was available, so the layout follows the rendered pages and the values come from this design system's tokens rather than the Elementor theme.

## Files

- \`index.html\` — mounts the kit; loads \`styles.css\` and \`_ds_bundle.js\`.
- \`shared.jsx\` — namespace unpacking, asset paths, nav model, \`Container\`, \`Figure\`, \`DiamondBullets\`, \`ContactBand\`.
- \`Home.jsx\` — photographic hero, three teaser cards, about band with stats, three process steps, dark "Why choose us" band.
- \`About.jsx\` — vision, six-person team grid, history band.
- \`Products.jsx\` — ABO explainer with the four groups, tabbed core tetraoses vs other sugars.
- \`Markets.jsx\` — four markets behind tabs: universal plasma, platelets, organ transplants, IVIG.
- \`app.jsx\` — router, quote Dialog, success Toast. Impacts / Process / R&D resolve to an honest placeholder.

## What works

Nav switching, product tabs, market tabs, tag selection, the quote dialog (email / product / application / consent) and the confirmation toast.

## Known gaps

Every image on the real site except the plant photograph is unavailable. Those positions render as labelled dashed placeholders naming the original \`wp-content\` path — including the ABO table, the molecular structure diagrams and the team portraits. Nothing was substituted or redrawn.
