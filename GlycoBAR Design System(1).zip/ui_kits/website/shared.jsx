const DS = window.GlycoBARDesignSystem_d44615;
const { Button, IconButton, Icon, Card, Badge, Tag, Callout, Stat,
        Field, Input, Textarea, Select, Checkbox, Radio, Switch,
        NavBar, Footer, Tabs, Dialog, Toast, Tooltip,
        PageHero, SectionHeader, MediaSection,
        Glycan, GlycanSymbol, GlycanTrail, GLYCOBAR_A, GLYCOBAR_B } = DS;

const LOGO = "../../assets/glycobar-logo.png";
const PLANT = "../../assets/photography/plant-exterior.png";

const NAV = [
  { id: "home", label: "Home" },
  { id: "about", label: "About Us" },
  { id: "impacts", label: "Impacts" },
  { id: "process", label: "Process" },
  { id: "products", label: "Products" },
  { id: "rd", label: "R&D" },
  { id: "markets", label: "Markets" },
];

/** Marks where a figure from glycobar.com belongs. The originals could not be
 *  downloaded, so they are labelled rather than invented. */
function Figure({ src, alt, caption, height = 260, style }) {
  if (src) return (
    <figure style={{ margin: 0, ...style }}>
      <img src={src} alt={alt} style={{ width: "100%", height, objectFit: "cover", display: "block", borderRadius: "var(--radius-image)", boxShadow: "var(--shadow-md)" }} />
      {caption ? <figcaption style={{ marginTop: "var(--space-4)", font: "var(--weight-regular) var(--text-xs)/1.5 var(--font-body)", color: "var(--text-muted)" }}>{caption}</figcaption> : null}
    </figure>
  );
  return <div className="gb-figure" style={{ height, ...style }}>{caption || alt}</div>;
}

function Container({ children, style }) {
  return <div style={{ maxWidth: "var(--container-max)", margin: "0 auto", padding: "0 var(--gutter)", ...style }}>{children}</div>;
}

function DiamondBullets({ items, style }) {
  return (
    <ul style={{ listStyle: "none", margin: 0, padding: 0, display: "flex", flexDirection: "column", gap: "var(--space-5)", ...style }}>
      {items.map((t) => (
        <li key={t} style={{ display: "flex", gap: "var(--space-5)", alignItems: "flex-start" }}>
          <svg width="11" height="11" viewBox="0 0 12 12" style={{ flex: "0 0 auto", marginTop: 8 }} aria-hidden="true">
            <circle cx="6" cy="6" r="5" fill="none" stroke="var(--snfg-connector)" strokeWidth="1.25" />
          </svg>
          <span style={{ font: "var(--type-body)", color: "var(--text-body)" }}>{t}</span>
        </li>
      ))}
    </ul>
  );
}

/** The site's repeated "Quotation / Technical Questions" band. */
function ContactBand({ onQuote }) {
  return (
    <section style={{ background: "var(--surface-brand)", padding: "var(--section-y-tight) 0" }}>
      <Container style={{ display: "flex", gap: "var(--space-12)", alignItems: "center", justifyContent: "space-between" }}>
        <div>
          <div style={{ font: "var(--type-eyebrow)", letterSpacing: "var(--tracking-label)", textTransform: "uppercase", color: "var(--clay-200)" }}>Quotation</div>
          <div style={{ font: "var(--weight-light) var(--text-3xl)/1.2 var(--font-display)", color: "#fff", marginTop: "var(--space-4)" }}>Interested in our solution?</div>
        </div>
        <div style={{ display: "flex", gap: "var(--space-5)" }}>
          <Button variant="inverse" onClick={onQuote}>Request a quote</Button>
          <Button variant="ghost" style={{ color: "#fff", border: "1px solid rgba(255,255,255,.5)" }} onClick={onQuote}>Ask a scientist</Button>
        </div>
      </Container>
    </section>
  );
}

Object.assign(window, { DS, Button, IconButton, Icon, Card, Badge, Tag, Callout, Stat, Field, Input, Textarea, Select, Checkbox, Radio, Switch, NavBar, Footer, Tabs, Dialog, Toast, Tooltip, PageHero, SectionHeader, MediaSection, Glycan, GlycanSymbol, GlycanTrail, GLYCOBAR_A, GLYCOBAR_B, LOGO, PLANT, NAV, Figure, Container, DiamondBullets, ContactBand });
