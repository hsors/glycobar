function About({ onQuote }) {
  const team = [
    { n: "Henri SORS", r: "“The Seasoned Entrepreneur”", d: "He is the co-founder and CEO. Background of EE engineering + MBA. 25 years with Hewlett-Packard." },
    { n: "Bernard MANDRAND", r: "“The Idea Wrangler”", d: "He is co-founder and scientific manager; 33 years at bioMerieux and 7 years at Lyonbiopole head of research programs." },
    { n: "Vivien DELOULE", r: "“The multitasking specialist”", d: "He is the operations manager. Engineering degree and Ph. Balances lab logistics, supply chain nightmares, and frantic grant deadlines without breaking a sweat." },
    { n: "Ludovic BASTIDE", r: "“The Bacteria Whisperer”", d: "He is the technical manager. PhD in microbiology. Transforms biology madness into structured workflows while keeping everyone (mostly) sane." },
    { n: "Jacqueline HUET", r: "“The Compliance Gatekeeper”", d: "She is our quality manager." },
    { n: "David CUCCOLO", r: "“The Human Calculator”", d: "He is our financial manager. Speaks fluent Excel, sees the future in cash flow, and ensures the company doesn't go broke." },
  ];
  return (
    <main>
      <section className="gb-sect">
        <Container>
          <div className="gb-grid-2" style={{ alignItems: "start" }}>
            <div>
              <SectionHeader eyebrow="About Us" title="Our vision" />
              <p style={{ marginTop: "var(--space-8)", font: "var(--weight-medium) var(--text-2xl)/1.3 var(--font-display)", color: "var(--brand)" }}>A world with no blood group antibodies !</p>
              <p style={{ marginTop: "var(--space-7)", font: "var(--type-body)", color: "var(--text-body)" }}>Blood barriers have protected individuals from potentially pathogenic exogenous organisms for thousands of years, but today they greatly complicate our modern health system where products are shared between individuals.</p>
              <p style={{ marginTop: "var(--space-6)", font: "var(--weight-regular) var(--text-md)/1.6 var(--font-body)", fontStyle: "italic", color: "var(--text-heading)" }}>The future of health involves the elimination of blood groups.</p>
              <DiamondBullets style={{ marginTop: "var(--space-8)" }} items={[
                "Plasma can be transfused regardless of donor and recipient respective blood group thanks to generalized universal plasma",
                "The issue of short-lived platelets is highly simplified because there is only one type of platelets: universal platelets",
                "Organ transplants can be done irrespective of donors & recipients blood group",
                "IVIG market is become much safer because those plasma derivative products do not contain isoagglutinins any more",
              ]} />
            </div>
            <Figure caption="wp-content/uploads/2025/03/DALL·E-2025-03-03-scientist-holographic-projection.webp (asset not available)" height={460} />
          </div>
        </Container>
      </section>

      <section className="gb-sect-tight" style={{ background: "var(--surface-alt)" }}>
        <Container>
          <SectionHeader eyebrow="Our Team" title="Six people, one barrier to remove" maxWidth={640} />
          <div className="gb-grid-3" style={{ marginTop: "var(--space-10)" }}>
            {team.map((m) => (
              <Card key={m.n}>
                <Figure caption="portrait (asset not available)" height={180} />
                <h3 style={{ marginTop: "var(--space-6)", font: "var(--type-h3)" }}>{m.n}</h3>
                <div style={{ marginTop: "var(--space-3)", font: "var(--type-small)", color: "var(--brand)" }}>{m.r}</div>
                <p style={{ marginTop: "var(--space-5)", font: "var(--type-small)", color: "var(--text-body)" }}>{m.d}</p>
              </Card>
            ))}
          </div>
        </Container>
      </section>

      <MediaSection image={PLANT} imageAlt="GlycoBAR site in Domène">
        <SectionHeader eyebrow="Our History" title="We created GlycoBAR in 2015, in the heart of one of the biggest glycoscience clusters in the world, Grenoble in France."
          lead="Nourished by the ecosystem of innovation where world-class research laboratories rub shoulders with cutting-edge industries in medical technologies, nanotechnologies, semiconductors and life sciences.">
          <p style={{ font: "var(--type-body)", color: "var(--text-body)" }}>GlycoBAR is growing to become a leader in glycoscience serving human health.</p>
        </SectionHeader>
      </MediaSection>

      <ContactBand onQuote={onQuote} />
    </main>
  );
}
window.About = About;
