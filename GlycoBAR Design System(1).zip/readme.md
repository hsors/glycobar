# GlycoBAR Design System

GlycoBAR is a Grenoble-area (Domène, France) glycoscience company founded in 2015. It produces blood group antigen ligands by bacterial biofermentation, at a price point intended to make universal blood components economically viable for the first time.

**Positioning line, verbatim from the site:** "Blood goup antigens ligands for an ABO antibody-free World" (the typo is theirs; keep it verbatim only when quoting the site).

**Vision:** "A world with no blood group antibodies!" Four consequences the company names: universal plasma, universal platelets, organ transplants across the blood group barrier, and safer IVIG (free of isoagglutinins).

## Sources used

| Source | What was taken |
| --- | --- |
| `https://glycobar.com/` (Home, About Us, Products, Markets) | All product and vision copy, page structure, navigation labels, footer structure, contact details |
| Logo PNG supplied by the user in chat | `assets/glycobar-logo.png`, plus derived crops `glycobar-mark.png` and `glycobar-wordmark.png`; the whole colour system is sampled from it |
| Photograph of the production plant supplied by the user in chat | `assets/photography/plant-exterior.png` ("front of our production plant >220m², hundreds of kilos of capacity") |

**No codebase, Figma file or brand book was provided.** The site runs on WordPress + Elementor 3.33.3 with Google Fonts enabled; its stylesheets were not readable, so type and spacing here are a reconstruction from the rendered pages and the logo, not extracted values. Treat the tokens as a proposal until someone confirms them against the real theme.

Products represented: one surface only — the **marketing website** (`ui_kits/website/`). There is no app, dashboard or docs site. A quote-request and "ask a scientist" contact flow is the only interactive part of the product.

## Content fundamentals

- **Register: scientific, plain, slightly unpolished.** The site explains mechanisms before benefits — "If plasma containing specific antibodies contacts red blood cells with the corresponding antigens, it can destroy the red blood cells, potentially triggering hemolysis." Do not simplify past the biology.
- **"We" for the company, "you" rarely.** Direct address appears only at contact points: "Willing to collaborate, discover our solutions or discuss blood group antigen applications? You've come to the right place!"
- **Claims are concrete and comparative, never superlative fluff.** "Our ligands are the most affordable ones on the market – by far, with uncompromised quality." "Available in any quantity at a price that is a small fraction of the competition price for a tri-saccharide."
- **Invitations are physical.** "Come and see our industrial demonstrator which already supplies international customers."
- **Sentence case for headings, with occasional French-style space before punctuation** ("A world with no blood group antibodies !", "Universal Plasma :"). Normalise this in new work — no space before `!` or `:` — but leave existing quotes alone.
- **Eyebrow + heading pairs open every section.** Eyebrow is a bare noun phrase ("Impacts", "Biofermentation process", "Blood antigens market"); the heading below is the claim ("Leading innovation", "Universal plasma").
- **Section headings are short; body carries the argument.** Two to four sentences per block, then a link: "Read More", "Discover More", "More About".
- **Italics carry emphasis on scientific statements**, bold carries the takeaway. The site over-italicises; use it once per block at most.
- **Team voice is warmly self-deprecating** — the only place humour appears: "The Bacteria Whisperer", "The Idea Wrangler", "Speaks fluent Excel". Keep this tone for team and culture content only.
- **No emoji anywhere.** Never introduce them.
- **Bilingual residue is authentic**: the newsletter button reads "Envoyer". Keep French for form actions if reproducing the site; use English everywhere else.
- **Vocabulary to keep exact:** antigen ligand, tetraose / tri-saccharide / hexa-saccharide, amine termination, linker arm, isoagglutinin, plasmapheresis, biofermentation, universal plasma, IVIG.

## Visual foundations

**Colour.** Everything derives from three colours measured in the logo: sand `#C5996B`, bronze `#8C6138`, cacao `#5E3817`. Those are `--clay-400 / 600 / 800`; the rest of the ramp is interpolated. Bronze is the action colour, cacao is the dark surface (footer, contact bar, modal veil), sand is for large flat areas and diagram fills. Neutrals are **warm** (`--stone-*`, all slightly brown-shifted) — never a blue-grey. Four domain accents (antigen A red, antigen B blue, plasma straw, universal green) exist for blood-group figures and status only; they never become interface chrome. Maximum two background colours per page: white and `--clay-50`, plus cacao for the footer.

**Type.** Display and headings in **Jost** (geometric, Futura-genre, light 300 for hero display, medium 500 for headings, `-0.02em`). Body in **IBM Plex Sans**, 16/1.65, with a light 19px lead paragraph. Technical shorthand and quantities in **IBM Plex Mono**. Eyebrows are 13px, 600, uppercase, `0.14em` tracking, bronze — the single most recognisable typographic move in the system. Buttons are uppercase with `0.04em` tracking.

**Layout.** 1180px container, 24px gutter, 96px vertical section padding (64px tight). Bands alternate: white, then `--clay-50`, then a two-column text/photo band with the image side swapped each time. Nothing is fixed or sticky except the header on scroll. Content columns cap at 640–760px for readability.

**Backgrounds and imagery.** Flat colour, not gradients. Only two gradients are sanctioned: `--grad-mark` (the mark's own bronze fade) and `--grad-protect` (transparent → 72% cacao, bottom-up) which is the *only* way type is placed over a photograph. No patterns, no textures, no grain, no hand-drawn illustration. Photography is real, daylit, undramatised — the plant exterior, lab benches, hospital and paediatric care. Colour vibe: cool grey industrial surfaces with warm brown accents, mild saturation (`saturate(.92)`), never teal-and-orange graded. Scientific figures (molecular structures, the ABO table) are flat diagrams on white; keep them as supplied bitmaps, do not redraw.

**Corners, borders, cards.** Restrained radii because the mark is built from 45° squares: 6px controls, 10px images, 12px cards, pill only for badges. Cards are white on a hairline `--stone-200` border with `--shadow-sm`, 24px padding (32px on feature cards). No card carries a coloured left border; the one accent rule in the system is the 3px **top** rule on `Callout`.

**Shadows and depth.** All shadows are cacao-tinted (`rgba(61,36,16,…)`), never neutral black, and stay soft: `--shadow-xs` through `--shadow-lg`, plus `--shadow-brand` for the primary button. Transparency and blur appear in exactly two places: the modal veil (62% cacao + 10px blur) and the white veil used when the logo must sit over a photograph.

**Motion.** Short and unshowy. 140ms on hover/focus colour changes, 220ms on card lift and switch travel, 360ms on modal and section reveals, all on `cubic-bezier(.2,.7,.3,1)`. Cards lift `-2px`; nothing bounces, nothing springs, nothing parallaxes. `prefers-reduced-motion` is honoured globally in `tokens/base.css`.

**States.** Hover darkens by one clay step (never lightens, never changes opacity); secondary and ghost buttons gain a `--clay-50`/`--clay-100` wash. Press scales to `0.985` — no colour change on press. Focus is a 2px `--clay-500` outline at 2px offset; form controls additionally get a 3px 14%-bronze ring. Disabled is 45% opacity plus `not-allowed`. Links are bronze with a `--clay-300` underline that darkens on hover.

## SNFG as the brand's graphic system

The Symbol Nomenclature for Glycans (SNFG) is the field's standard notation — a glycoscientist reads it instantly. GlycoBAR uses it two ways, and the distinction is strict:

1. **As figure, in colour.** Whenever a drawing states a real structure, use the published SNFG fills exactly (`tokens/snfg.css`): Gal yellow circle, GalNAc yellow square, GlcNAc blue square, Fuc red triangle, Neu5Ac purple diamond, and so on. `components/science/Glycan.jsx` renders these, and exports `GLYCOBAR_A` / `GLYCOBAR_B` — the two core tetraoses — so nobody hand-draws them. Colour here is a claim; it must be correct.
2. **As motif, outlined.** The *geometry* is the brand pattern: trees, connectors, bullets, dividers, milestone tracks. Always `tone="outline"`, no fills — `components/science/GlycanTrail.jsx`. Colouring a motif would imply a structure that isn't there.

**Outlines are cacao (`--snfg-stroke`, `--clay-900`), never pure black**, so the galactose yellow never reads as brand sand. Linkage labels sit on the connectors in IBM Plex Mono at 9px.

Where the mark's own four diamonds and SNFG overlap, prefer SNFG: an outlined circle or square is the list bullet, an outlined trail is the section divider. The rotated-square bullet from the logo remains valid on brand pages that carry no science.

**Grounds stay light.** SNFG geometry is drawn on white or `--clay-50`. Cacao is a footer, a contact bar and a modal veil — not a page background. Full-page dark-brown treatments are explicitly out.

## Iconography

- **No icon set was supplied.** The live site relies on Elementor's inline Font Awesome SVGs, which are not redistributable here.
- **Substitution (flagged):** [Lucide](https://lucide.dev) 0.462.0, loaded per-glyph from `unpkg` and recoloured by CSS mask inside `components/core/Icon.jsx`. Its 2px outline, rounded-cap style is the nearest free match to the thin outline glyphs on the site. Swap `CDN` in `Icon.jsx` if the real set turns up.
- Icons are outline only, `currentColor`, 14–20px, and always paired with a label. Sizes: 14px in the contact bar, 17px in buttons and inputs, 20px in callouts, 18px for social.
- Glyphs in regular use: `arrow-right` (all "read more" links), `mail`, `phone`, `linkedin`, `search`, `menu`, `x`, `chevron-down`, `check`, `download`, `send`, `info`, `triangle-alert`, `octagon-alert`, `flask-conical`, `dna`.
- **No emoji, ever.** No unicode characters used as icons. The one non-Lucide graphic device is the brand's own diamond: a 10px square rotated 45° used as a list bullet (see `guidelines/brand-motif.html`).
- The logo is a supplied bitmap and is never redrawn, recoloured or reconstructed in code. Where a vector mark is needed, ask GlycoBAR for the original file.

## Components

Nothing in the sources defines a component inventory, so this is a standard set sized to the site's needs.

**Science** (`components/science/`) — `Glycan`, `GlycanSymbol`, `GlycanTrail`
**Core** (`components/core/`) — `Button`, `IconButton`, `Icon`, `Card`, `Badge`, `Tag`, `Callout`, `Stat`
**Forms** (`components/forms/`) — `Field`, `Input`, `Textarea`, `Select`, `Checkbox`, `Radio`, `Switch`
**Navigation** (`components/navigation/`) — `NavBar`, `Footer`, `Tabs`
**Feedback** (`components/feedback/`) — `Dialog`, `Toast`, `Tooltip`
**Layout** (`components/layout/`) — `PageHero`, `SectionHeader`, `MediaSection`

### Intentional additions

- `Glycan`, `GlycanSymbol`, `GlycanTrail` — SNFG is the one graphic system a generalist competitor cannot fake, and it removes any need to redraw structures by hand.
- `Icon` — a wrapper is required because the glyph set is a flagged substitution; centralising it makes the swap one edit.
- `Stat`, `Callout` — the Markets and Products pages lean on figures and scientific asides.
- `PageHero`, `SectionHeader`, `MediaSection` — these three are literally the page grammar of glycobar.com (eyebrow/heading/lead, alternating photo bands, photographic hero). Without them every screen re-implements the same layout.

## Index

- `styles.css` — the single entry point consumers link. `@import` lines only.
- `tokens/` — `fonts.css`, `colors.css`, `snfg.css`, `typography.css`, `spacing.css`, `radius.css`, `elevation.css`, `motion.css`, `base.css`.
- `assets/` — `glycobar-logo.png` (full lockup), `glycobar-mark.png`, `glycobar-wordmark.png`, `photography/plant-exterior.png`.
- `components/<group>/` — one `.jsx` + `.d.ts` + `.prompt.md` per component, plus a `*.card.html` specimen per group.
- `guidelines/` — 21 foundation specimen cards (Colors, Type, Spacing, Foundations, Brand).
- `ui_kits/website/` — click-through recreation of glycobar.com: `index.html`, `Home.jsx`, `About.jsx`, `Products.jsx`, `Markets.jsx`, `README.md`.
- `thumbnail.html` — homepage tile.
- `SKILL.md` — Agent-Skills entry point.

## Open questions

1. Real font files. Jost and IBM Plex Sans are substitutions; the wordmark's actual typeface is unknown.
2. Vector logo (SVG or AI) and the clear-space rule from the real brand guide.
3. The site's scientific figures (ABO table, molecular structures, market photos) could not be downloaded; the UI kit marks their positions with labelled placeholders.
